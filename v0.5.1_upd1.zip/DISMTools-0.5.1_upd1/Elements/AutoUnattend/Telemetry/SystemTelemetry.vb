﻿Namespace Elements

    Public Class SystemTelemetry

        ''' <summary>
        ''' Determines whether to enable or disable system telemetry
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Property Enabled As Boolean = False

    End Class

End Namespace
