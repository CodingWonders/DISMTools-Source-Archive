﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class DTSettingForm
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.OK_Button = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.RichTextBox1 = New System.Windows.Forms.RichTextBox()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.RichTextBox17 = New System.Windows.Forms.RichTextBox()
        Me.RichTextBox16 = New System.Windows.Forms.RichTextBox()
        Me.RichTextBox15 = New System.Windows.Forms.RichTextBox()
        Me.RichTextBox14 = New System.Windows.Forms.RichTextBox()
        Me.RichTextBox13 = New System.Windows.Forms.RichTextBox()
        Me.RichTextBox12 = New System.Windows.Forms.RichTextBox()
        Me.RichTextBox11 = New System.Windows.Forms.RichTextBox()
        Me.RichTextBox10 = New System.Windows.Forms.RichTextBox()
        Me.RichTextBox9 = New System.Windows.Forms.RichTextBox()
        Me.RichTextBox8 = New System.Windows.Forms.RichTextBox()
        Me.RichTextBox7 = New System.Windows.Forms.RichTextBox()
        Me.RichTextBox6 = New System.Windows.Forms.RichTextBox()
        Me.RichTextBox5 = New System.Windows.Forms.RichTextBox()
        Me.RichTextBox4 = New System.Windows.Forms.RichTextBox()
        Me.RichTextBox3 = New System.Windows.Forms.RichTextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.RichTextBox2 = New System.Windows.Forms.RichTextBox()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'OK_Button
        '
        Me.OK_Button.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.OK_Button.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.OK_Button.Location = New System.Drawing.Point(929, 526)
        Me.OK_Button.Name = "OK_Button"
        Me.OK_Button.Size = New System.Drawing.Size(67, 23)
        Me.OK_Button.TabIndex = 1
        Me.OK_Button.Text = "OK"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(13, 13)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(107, 13)
        Me.Label1.TabIndex = 2
        Me.Label1.Text = "Old ""settings.ini"" file:"
        '
        'RichTextBox1
        '
        Me.RichTextBox1.Location = New System.Drawing.Point(16, 29)
        Me.RichTextBox1.Name = "RichTextBox1"
        Me.RichTextBox1.ReadOnly = True
        Me.RichTextBox1.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.ForcedBoth
        Me.RichTextBox1.Size = New System.Drawing.Size(296, 248)
        Me.RichTextBox1.TabIndex = 3
        Me.RichTextBox1.Text = ""
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.Label17)
        Me.GroupBox1.Controls.Add(Me.Label16)
        Me.GroupBox1.Controls.Add(Me.Label15)
        Me.GroupBox1.Controls.Add(Me.Label14)
        Me.GroupBox1.Controls.Add(Me.Label13)
        Me.GroupBox1.Controls.Add(Me.Label12)
        Me.GroupBox1.Controls.Add(Me.Label11)
        Me.GroupBox1.Controls.Add(Me.Label10)
        Me.GroupBox1.Controls.Add(Me.Label9)
        Me.GroupBox1.Controls.Add(Me.Label8)
        Me.GroupBox1.Controls.Add(Me.Label7)
        Me.GroupBox1.Controls.Add(Me.Label6)
        Me.GroupBox1.Controls.Add(Me.Label5)
        Me.GroupBox1.Controls.Add(Me.Label4)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.RichTextBox17)
        Me.GroupBox1.Controls.Add(Me.RichTextBox16)
        Me.GroupBox1.Controls.Add(Me.RichTextBox15)
        Me.GroupBox1.Controls.Add(Me.RichTextBox14)
        Me.GroupBox1.Controls.Add(Me.RichTextBox13)
        Me.GroupBox1.Controls.Add(Me.RichTextBox12)
        Me.GroupBox1.Controls.Add(Me.RichTextBox11)
        Me.GroupBox1.Controls.Add(Me.RichTextBox10)
        Me.GroupBox1.Controls.Add(Me.RichTextBox9)
        Me.GroupBox1.Controls.Add(Me.RichTextBox8)
        Me.GroupBox1.Controls.Add(Me.RichTextBox7)
        Me.GroupBox1.Controls.Add(Me.RichTextBox6)
        Me.GroupBox1.Controls.Add(Me.RichTextBox5)
        Me.GroupBox1.Controls.Add(Me.RichTextBox4)
        Me.GroupBox1.Controls.Add(Me.RichTextBox3)
        Me.GroupBox1.Location = New System.Drawing.Point(318, 13)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(678, 507)
        Me.GroupBox1.TabIndex = 4
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Independent values"
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Location = New System.Drawing.Point(24, 451)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(69, 13)
        Me.Label17.TabIndex = 2
        Me.Label17.Text = "Report view:"
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Location = New System.Drawing.Point(24, 421)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(131, 13)
        Me.Label16.TabIndex = 2
        Me.Label16.Text = "Display reports in English?"
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(24, 391)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(133, 13)
        Me.Label15.TabIndex = 2
        Me.Label15.Text = "Scratch directory location:"
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(24, 361)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(114, 13)
        Me.Label14.TabIndex = 2
        Me.Label14.Text = "Use scratch directory?"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(24, 331)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(104, 13)
        Me.Label13.TabIndex = 2
        Me.Label13.Text = "Skip system restart?"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(24, 301)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(126, 13)
        Me.Label12.TabIndex = 2
        Me.Label12.Text = "Perform settings quietly?"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(24, 271)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(119, 13)
        Me.Label11.TabIndex = 2
        Me.Label11.Text = "Image operation mode:"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(24, 241)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(70, 13)
        Me.Label10.TabIndex = 2
        Me.Label10.Text = "Log file level:"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(24, 211)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(70, 13)
        Me.Label9.TabIndex = 2
        Me.Label9.Text = "Log file path:"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(24, 181)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(51, 13)
        Me.Label8.TabIndex = 2
        Me.Label8.Text = "Log font:"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(24, 151)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(58, 13)
        Me.Label7.TabIndex = 2
        Me.Label7.Text = "Language:"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(24, 121)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(65, 13)
        Me.Label6.TabIndex = 2
        Me.Label6.Text = "Color mode:"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(24, 91)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(74, 13)
        Me.Label5.TabIndex = 2
        Me.Label5.Text = "Volatile mode:"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(24, 61)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(110, 13)
        Me.Label4.TabIndex = 2
        Me.Label4.Text = "Save settings on INI?"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(24, 31)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(92, 13)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "DISM executable:"
        '
        'RichTextBox17
        '
        Me.RichTextBox17.Location = New System.Drawing.Point(163, 446)
        Me.RichTextBox17.Multiline = False
        Me.RichTextBox17.Name = "RichTextBox17"
        Me.RichTextBox17.ReadOnly = True
        Me.RichTextBox17.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.ForcedBoth
        Me.RichTextBox17.Size = New System.Drawing.Size(482, 24)
        Me.RichTextBox17.TabIndex = 3
        Me.RichTextBox17.Text = ""
        '
        'RichTextBox16
        '
        Me.RichTextBox16.Location = New System.Drawing.Point(163, 416)
        Me.RichTextBox16.Multiline = False
        Me.RichTextBox16.Name = "RichTextBox16"
        Me.RichTextBox16.ReadOnly = True
        Me.RichTextBox16.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.ForcedBoth
        Me.RichTextBox16.Size = New System.Drawing.Size(482, 24)
        Me.RichTextBox16.TabIndex = 3
        Me.RichTextBox16.Text = ""
        '
        'RichTextBox15
        '
        Me.RichTextBox15.Location = New System.Drawing.Point(163, 386)
        Me.RichTextBox15.Multiline = False
        Me.RichTextBox15.Name = "RichTextBox15"
        Me.RichTextBox15.ReadOnly = True
        Me.RichTextBox15.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.ForcedBoth
        Me.RichTextBox15.Size = New System.Drawing.Size(482, 24)
        Me.RichTextBox15.TabIndex = 3
        Me.RichTextBox15.Text = ""
        '
        'RichTextBox14
        '
        Me.RichTextBox14.Location = New System.Drawing.Point(163, 356)
        Me.RichTextBox14.Multiline = False
        Me.RichTextBox14.Name = "RichTextBox14"
        Me.RichTextBox14.ReadOnly = True
        Me.RichTextBox14.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.ForcedBoth
        Me.RichTextBox14.Size = New System.Drawing.Size(482, 24)
        Me.RichTextBox14.TabIndex = 3
        Me.RichTextBox14.Text = ""
        '
        'RichTextBox13
        '
        Me.RichTextBox13.Location = New System.Drawing.Point(163, 326)
        Me.RichTextBox13.Multiline = False
        Me.RichTextBox13.Name = "RichTextBox13"
        Me.RichTextBox13.ReadOnly = True
        Me.RichTextBox13.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.ForcedBoth
        Me.RichTextBox13.Size = New System.Drawing.Size(482, 24)
        Me.RichTextBox13.TabIndex = 3
        Me.RichTextBox13.Text = ""
        '
        'RichTextBox12
        '
        Me.RichTextBox12.Location = New System.Drawing.Point(163, 296)
        Me.RichTextBox12.Multiline = False
        Me.RichTextBox12.Name = "RichTextBox12"
        Me.RichTextBox12.ReadOnly = True
        Me.RichTextBox12.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.ForcedBoth
        Me.RichTextBox12.Size = New System.Drawing.Size(482, 24)
        Me.RichTextBox12.TabIndex = 3
        Me.RichTextBox12.Text = ""
        '
        'RichTextBox11
        '
        Me.RichTextBox11.Location = New System.Drawing.Point(163, 266)
        Me.RichTextBox11.Multiline = False
        Me.RichTextBox11.Name = "RichTextBox11"
        Me.RichTextBox11.ReadOnly = True
        Me.RichTextBox11.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.ForcedBoth
        Me.RichTextBox11.Size = New System.Drawing.Size(482, 24)
        Me.RichTextBox11.TabIndex = 3
        Me.RichTextBox11.Text = ""
        '
        'RichTextBox10
        '
        Me.RichTextBox10.Location = New System.Drawing.Point(163, 236)
        Me.RichTextBox10.Multiline = False
        Me.RichTextBox10.Name = "RichTextBox10"
        Me.RichTextBox10.ReadOnly = True
        Me.RichTextBox10.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.ForcedBoth
        Me.RichTextBox10.Size = New System.Drawing.Size(482, 24)
        Me.RichTextBox10.TabIndex = 3
        Me.RichTextBox10.Text = ""
        '
        'RichTextBox9
        '
        Me.RichTextBox9.Location = New System.Drawing.Point(163, 206)
        Me.RichTextBox9.Multiline = False
        Me.RichTextBox9.Name = "RichTextBox9"
        Me.RichTextBox9.ReadOnly = True
        Me.RichTextBox9.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.ForcedBoth
        Me.RichTextBox9.Size = New System.Drawing.Size(482, 24)
        Me.RichTextBox9.TabIndex = 3
        Me.RichTextBox9.Text = ""
        '
        'RichTextBox8
        '
        Me.RichTextBox8.Location = New System.Drawing.Point(163, 176)
        Me.RichTextBox8.Multiline = False
        Me.RichTextBox8.Name = "RichTextBox8"
        Me.RichTextBox8.ReadOnly = True
        Me.RichTextBox8.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.ForcedBoth
        Me.RichTextBox8.Size = New System.Drawing.Size(482, 24)
        Me.RichTextBox8.TabIndex = 3
        Me.RichTextBox8.Text = ""
        '
        'RichTextBox7
        '
        Me.RichTextBox7.Location = New System.Drawing.Point(163, 146)
        Me.RichTextBox7.Multiline = False
        Me.RichTextBox7.Name = "RichTextBox7"
        Me.RichTextBox7.ReadOnly = True
        Me.RichTextBox7.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.ForcedBoth
        Me.RichTextBox7.Size = New System.Drawing.Size(482, 24)
        Me.RichTextBox7.TabIndex = 3
        Me.RichTextBox7.Text = ""
        '
        'RichTextBox6
        '
        Me.RichTextBox6.Location = New System.Drawing.Point(163, 116)
        Me.RichTextBox6.Multiline = False
        Me.RichTextBox6.Name = "RichTextBox6"
        Me.RichTextBox6.ReadOnly = True
        Me.RichTextBox6.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.ForcedBoth
        Me.RichTextBox6.Size = New System.Drawing.Size(482, 24)
        Me.RichTextBox6.TabIndex = 3
        Me.RichTextBox6.Text = ""
        '
        'RichTextBox5
        '
        Me.RichTextBox5.Location = New System.Drawing.Point(163, 86)
        Me.RichTextBox5.Multiline = False
        Me.RichTextBox5.Name = "RichTextBox5"
        Me.RichTextBox5.ReadOnly = True
        Me.RichTextBox5.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.ForcedBoth
        Me.RichTextBox5.Size = New System.Drawing.Size(482, 24)
        Me.RichTextBox5.TabIndex = 3
        Me.RichTextBox5.Text = ""
        '
        'RichTextBox4
        '
        Me.RichTextBox4.Location = New System.Drawing.Point(163, 56)
        Me.RichTextBox4.Multiline = False
        Me.RichTextBox4.Name = "RichTextBox4"
        Me.RichTextBox4.ReadOnly = True
        Me.RichTextBox4.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.ForcedBoth
        Me.RichTextBox4.Size = New System.Drawing.Size(482, 24)
        Me.RichTextBox4.TabIndex = 3
        Me.RichTextBox4.Text = ""
        '
        'RichTextBox3
        '
        Me.RichTextBox3.Location = New System.Drawing.Point(163, 26)
        Me.RichTextBox3.Multiline = False
        Me.RichTextBox3.Name = "RichTextBox3"
        Me.RichTextBox3.ReadOnly = True
        Me.RichTextBox3.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.ForcedBoth
        Me.RichTextBox3.Size = New System.Drawing.Size(482, 24)
        Me.RichTextBox3.TabIndex = 3
        Me.RichTextBox3.Text = ""
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(13, 285)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(112, 13)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "New ""settings.ini"" file:"
        '
        'RichTextBox2
        '
        Me.RichTextBox2.Location = New System.Drawing.Point(16, 301)
        Me.RichTextBox2.Name = "RichTextBox2"
        Me.RichTextBox2.ReadOnly = True
        Me.RichTextBox2.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.ForcedBoth
        Me.RichTextBox2.Size = New System.Drawing.Size(296, 248)
        Me.RichTextBox2.TabIndex = 3
        Me.RichTextBox2.Text = ""
        '
        'DTSettingForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1008, 561)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.RichTextBox2)
        Me.Controls.Add(Me.RichTextBox1)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.OK_Button)
        Me.Font = New System.Drawing.Font("Tahoma", 8.25!)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "DTSettingForm"
        Me.ShowIcon = False
        Me.Text = "Program settings"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents OK_Button As System.Windows.Forms.Button
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents RichTextBox1 As System.Windows.Forms.RichTextBox
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents RichTextBox3 As System.Windows.Forms.RichTextBox
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents RichTextBox17 As System.Windows.Forms.RichTextBox
    Friend WithEvents RichTextBox16 As System.Windows.Forms.RichTextBox
    Friend WithEvents RichTextBox15 As System.Windows.Forms.RichTextBox
    Friend WithEvents RichTextBox14 As System.Windows.Forms.RichTextBox
    Friend WithEvents RichTextBox13 As System.Windows.Forms.RichTextBox
    Friend WithEvents RichTextBox12 As System.Windows.Forms.RichTextBox
    Friend WithEvents RichTextBox11 As System.Windows.Forms.RichTextBox
    Friend WithEvents RichTextBox10 As System.Windows.Forms.RichTextBox
    Friend WithEvents RichTextBox9 As System.Windows.Forms.RichTextBox
    Friend WithEvents RichTextBox8 As System.Windows.Forms.RichTextBox
    Friend WithEvents RichTextBox7 As System.Windows.Forms.RichTextBox
    Friend WithEvents RichTextBox6 As System.Windows.Forms.RichTextBox
    Friend WithEvents RichTextBox5 As System.Windows.Forms.RichTextBox
    Friend WithEvents RichTextBox4 As System.Windows.Forms.RichTextBox
    Friend WithEvents RichTextBox2 As System.Windows.Forms.RichTextBox
End Class
