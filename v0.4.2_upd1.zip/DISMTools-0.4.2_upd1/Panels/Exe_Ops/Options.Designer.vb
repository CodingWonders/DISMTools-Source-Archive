﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Options
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Options))
        Me.TableLayoutPanel1 = New System.Windows.Forms.TableLayoutPanel()
        Me.OK_Button = New System.Windows.Forms.Button()
        Me.Cancel_Button = New System.Windows.Forms.Button()
        Me.Win10Title = New System.Windows.Forms.Panel()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.DismOFD = New System.Windows.Forms.OpenFileDialog()
        Me.ScratchFBD = New System.Windows.Forms.FolderBrowserDialog()
        Me.CheckBox13 = New System.Windows.Forms.CheckBox()
        Me.CheckBox12 = New System.Windows.Forms.CheckBox()
        Me.Label43 = New System.Windows.Forms.Label()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.Label46 = New System.Windows.Forms.Label()
        Me.PictureBox8 = New System.Windows.Forms.PictureBox()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.GroupBox5 = New System.Windows.Forms.GroupBox()
        Me.CheckBox11 = New System.Windows.Forms.CheckBox()
        Me.Button9 = New System.Windows.Forms.Button()
        Me.Label41 = New System.Windows.Forms.Label()
        Me.Label42 = New System.Windows.Forms.Label()
        Me.Label40 = New System.Windows.Forms.Label()
        Me.Label39 = New System.Windows.Forms.Label()
        Me.Button8 = New System.Windows.Forms.Button()
        Me.Label38 = New System.Windows.Forms.Label()
        Me.Label37 = New System.Windows.Forms.Label()
        Me.Label36 = New System.Windows.Forms.Label()
        Me.CheckBox8 = New System.Windows.Forms.CheckBox()
        Me.Label35 = New System.Windows.Forms.Label()
        Me.Button10 = New System.Windows.Forms.Button()
        Me.LinkLabel2 = New System.Windows.Forms.LinkLabel()
        Me.Label29 = New System.Windows.Forms.Label()
        Me.ComboBox6 = New System.Windows.Forms.ComboBox()
        Me.Label28 = New System.Windows.Forms.Label()
        Me.CheckBox6 = New System.Windows.Forms.CheckBox()
        Me.PictureBox7 = New System.Windows.Forms.PictureBox()
        Me.Label27 = New System.Windows.Forms.Label()
        Me.TextBox4 = New System.Windows.Forms.TextBox()
        Me.ComboBox5 = New System.Windows.Forms.ComboBox()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.CheckBox5 = New System.Windows.Forms.CheckBox()
        Me.PictureBox6 = New System.Windows.Forms.PictureBox()
        Me.RadioButton4 = New System.Windows.Forms.RadioButton()
        Me.RadioButton3 = New System.Windows.Forms.RadioButton()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.TextBox3 = New System.Windows.Forms.TextBox()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.Label44 = New System.Windows.Forms.Label()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.CheckBox4 = New System.Windows.Forms.CheckBox()
        Me.PictureBox5 = New System.Windows.Forms.PictureBox()
        Me.CheckBox14 = New System.Windows.Forms.CheckBox()
        Me.Label48 = New System.Windows.Forms.Label()
        Me.TableLayoutPanel2 = New System.Windows.Forms.TableLayoutPanel()
        Me.CheckBox15 = New System.Windows.Forms.CheckBox()
        Me.CheckBox19 = New System.Windows.Forms.CheckBox()
        Me.CheckBox18 = New System.Windows.Forms.CheckBox()
        Me.CheckBox16 = New System.Windows.Forms.CheckBox()
        Me.CheckBox17 = New System.Windows.Forms.CheckBox()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.CheckBox3 = New System.Windows.Forms.CheckBox()
        Me.CheckBox2 = New System.Windows.Forms.CheckBox()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.TrackBar1 = New System.Windows.Forms.TrackBar()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.TextBox2 = New System.Windows.Forms.TextBox()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.CheckBox10 = New System.Windows.Forms.CheckBox()
        Me.PictureBox4 = New System.Windows.Forms.PictureBox()
        Me.CheckBox20 = New System.Windows.Forms.CheckBox()
        Me.SecProgressStylePreview = New System.Windows.Forms.PictureBox()
        Me.RadioButton6 = New System.Windows.Forms.RadioButton()
        Me.RadioButton5 = New System.Windows.Forms.RadioButton()
        Me.Label45 = New System.Windows.Forms.Label()
        Me.Panel4 = New System.Windows.Forms.Panel()
        Me.Label47 = New System.Windows.Forms.Label()
        Me.PictureBox9 = New System.Windows.Forms.PictureBox()
        Me.Toggle1 = New System.Windows.Forms.CheckBox()
        Me.NumericUpDown1 = New System.Windows.Forms.NumericUpDown()
        Me.LogPreview = New System.Windows.Forms.TextBox()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.ComboBox4 = New System.Windows.Forms.ComboBox()
        Me.CheckBox9 = New System.Windows.Forms.CheckBox()
        Me.ComboBox3 = New System.Windows.Forms.ComboBox()
        Me.ComboBox2 = New System.Windows.Forms.ComboBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.CheckBox1 = New System.Windows.Forms.CheckBox()
        Me.ComboBox1 = New System.Windows.Forms.ComboBox()
        Me.PictureBox3 = New System.Windows.Forms.PictureBox()
        Me.LinkLabel1 = New System.Windows.Forms.LinkLabel()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.PrefReset = New System.Windows.Forms.Button()
        Me.LogSFD = New System.Windows.Forms.SaveFileDialog()
        Me.btnPanel = New System.Windows.Forms.Panel()
        Me.OptionContainer = New System.Windows.Forms.Panel()
        Me.SplitContainer1 = New System.Windows.Forms.SplitContainer()
        Me.FlowLayoutPanel1 = New System.Windows.Forms.FlowLayoutPanel()
        Me.ProgramSectionBtn = New System.Windows.Forms.Panel()
        Me.PictureBox10 = New System.Windows.Forms.PictureBox()
        Me.Label49 = New System.Windows.Forms.Label()
        Me.PersonalizationSectionBtn = New System.Windows.Forms.Panel()
        Me.PictureBox11 = New System.Windows.Forms.PictureBox()
        Me.Label50 = New System.Windows.Forms.Label()
        Me.LogSectionBtn = New System.Windows.Forms.Panel()
        Me.PictureBox12 = New System.Windows.Forms.PictureBox()
        Me.Label51 = New System.Windows.Forms.Label()
        Me.ImgOpsSectionBtn = New System.Windows.Forms.Panel()
        Me.PictureBox13 = New System.Windows.Forms.PictureBox()
        Me.Label52 = New System.Windows.Forms.Label()
        Me.ScDirSectionBtn = New System.Windows.Forms.Panel()
        Me.PictureBox14 = New System.Windows.Forms.PictureBox()
        Me.Label53 = New System.Windows.Forms.Label()
        Me.OutputSectionBtn = New System.Windows.Forms.Panel()
        Me.PictureBox15 = New System.Windows.Forms.PictureBox()
        Me.Label54 = New System.Windows.Forms.Label()
        Me.BgProcsSectionBtn = New System.Windows.Forms.Panel()
        Me.PictureBox16 = New System.Windows.Forms.PictureBox()
        Me.Label55 = New System.Windows.Forms.Label()
        Me.ImgDetectSectionBtn = New System.Windows.Forms.Panel()
        Me.PictureBox17 = New System.Windows.Forms.PictureBox()
        Me.Label56 = New System.Windows.Forms.Label()
        Me.AssocsSectionBtn = New System.Windows.Forms.Panel()
        Me.PictureBox18 = New System.Windows.Forms.PictureBox()
        Me.Label57 = New System.Windows.Forms.Label()
        Me.StartupSectionBtn = New System.Windows.Forms.Panel()
        Me.PictureBox19 = New System.Windows.Forms.PictureBox()
        Me.Label58 = New System.Windows.Forms.Label()
        Me.ValueContainer = New System.Windows.Forms.Panel()
        Me.Options_Program = New System.Windows.Forms.Panel()
        Me.FlowLayoutPanel2 = New System.Windows.Forms.FlowLayoutPanel()
        Me.Panel14 = New System.Windows.Forms.Panel()
        Me.Panel15 = New System.Windows.Forms.Panel()
        Me.Options_Personalization = New System.Windows.Forms.Panel()
        Me.FlowLayoutPanel3 = New System.Windows.Forms.FlowLayoutPanel()
        Me.Panel16 = New System.Windows.Forms.Panel()
        Me.Panel17 = New System.Windows.Forms.Panel()
        Me.Label59 = New System.Windows.Forms.Label()
        Me.Panel18 = New System.Windows.Forms.Panel()
        Me.Options_Logs = New System.Windows.Forms.Panel()
        Me.FlowLayoutPanel4 = New System.Windows.Forms.FlowLayoutPanel()
        Me.Panel5 = New System.Windows.Forms.Panel()
        Me.Panel19 = New System.Windows.Forms.Panel()
        Me.Options_ImgOps = New System.Windows.Forms.Panel()
        Me.FlowLayoutPanel5 = New System.Windows.Forms.FlowLayoutPanel()
        Me.Panel6 = New System.Windows.Forms.Panel()
        Me.Panel7 = New System.Windows.Forms.Panel()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Options_Scratch = New System.Windows.Forms.Panel()
        Me.FlowLayoutPanel6 = New System.Windows.Forms.FlowLayoutPanel()
        Me.Panel8 = New System.Windows.Forms.Panel()
        Me.Options_Output = New System.Windows.Forms.Panel()
        Me.FlowLayoutPanel7 = New System.Windows.Forms.FlowLayoutPanel()
        Me.Panel9 = New System.Windows.Forms.Panel()
        Me.Panel10 = New System.Windows.Forms.Panel()
        Me.Options_BgProcs = New System.Windows.Forms.Panel()
        Me.FlowLayoutPanel8 = New System.Windows.Forms.FlowLayoutPanel()
        Me.Panel11 = New System.Windows.Forms.Panel()
        Me.Panel12 = New System.Windows.Forms.Panel()
        Me.Options_ImgDetection = New System.Windows.Forms.Panel()
        Me.FlowLayoutPanel9 = New System.Windows.Forms.FlowLayoutPanel()
        Me.Panel13 = New System.Windows.Forms.Panel()
        Me.Options_FileAssocs = New System.Windows.Forms.Panel()
        Me.FlowLayoutPanel10 = New System.Windows.Forms.FlowLayoutPanel()
        Me.Options_Startup = New System.Windows.Forms.Panel()
        Me.FlowLayoutPanel11 = New System.Windows.Forms.FlowLayoutPanel()
        Me.Panel20 = New System.Windows.Forms.Panel()
        Me.TableLayoutPanel1.SuspendLayout()
        Me.Win10Title.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel3.SuspendLayout()
        CType(Me.PictureBox8, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel2.SuspendLayout()
        Me.GroupBox5.SuspendLayout()
        CType(Me.PictureBox7, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox6, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox5, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TableLayoutPanel2.SuspendLayout()
        Me.Panel1.SuspendLayout()
        CType(Me.TrackBar1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.SecProgressStylePreview, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel4.SuspendLayout()
        CType(Me.PictureBox9, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.btnPanel.SuspendLayout()
        Me.OptionContainer.SuspendLayout()
        CType(Me.SplitContainer1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SplitContainer1.Panel1.SuspendLayout()
        Me.SplitContainer1.Panel2.SuspendLayout()
        Me.SplitContainer1.SuspendLayout()
        Me.FlowLayoutPanel1.SuspendLayout()
        Me.ProgramSectionBtn.SuspendLayout()
        CType(Me.PictureBox10, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.PersonalizationSectionBtn.SuspendLayout()
        CType(Me.PictureBox11, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.LogSectionBtn.SuspendLayout()
        CType(Me.PictureBox12, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.ImgOpsSectionBtn.SuspendLayout()
        CType(Me.PictureBox13, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.ScDirSectionBtn.SuspendLayout()
        CType(Me.PictureBox14, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.OutputSectionBtn.SuspendLayout()
        CType(Me.PictureBox15, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.BgProcsSectionBtn.SuspendLayout()
        CType(Me.PictureBox16, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.ImgDetectSectionBtn.SuspendLayout()
        CType(Me.PictureBox17, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.AssocsSectionBtn.SuspendLayout()
        CType(Me.PictureBox18, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.StartupSectionBtn.SuspendLayout()
        CType(Me.PictureBox19, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.ValueContainer.SuspendLayout()
        Me.Options_Program.SuspendLayout()
        Me.FlowLayoutPanel2.SuspendLayout()
        Me.Panel14.SuspendLayout()
        Me.Panel15.SuspendLayout()
        Me.Options_Personalization.SuspendLayout()
        Me.FlowLayoutPanel3.SuspendLayout()
        Me.Panel16.SuspendLayout()
        Me.Panel17.SuspendLayout()
        Me.Panel18.SuspendLayout()
        Me.Options_Logs.SuspendLayout()
        Me.FlowLayoutPanel4.SuspendLayout()
        Me.Panel5.SuspendLayout()
        Me.Panel19.SuspendLayout()
        Me.Options_ImgOps.SuspendLayout()
        Me.FlowLayoutPanel5.SuspendLayout()
        Me.Panel6.SuspendLayout()
        Me.Panel7.SuspendLayout()
        Me.Options_Scratch.SuspendLayout()
        Me.FlowLayoutPanel6.SuspendLayout()
        Me.Panel8.SuspendLayout()
        Me.Options_Output.SuspendLayout()
        Me.FlowLayoutPanel7.SuspendLayout()
        Me.Panel9.SuspendLayout()
        Me.Panel10.SuspendLayout()
        Me.Options_BgProcs.SuspendLayout()
        Me.FlowLayoutPanel8.SuspendLayout()
        Me.Panel11.SuspendLayout()
        Me.Panel12.SuspendLayout()
        Me.Options_ImgDetection.SuspendLayout()
        Me.FlowLayoutPanel9.SuspendLayout()
        Me.Panel13.SuspendLayout()
        Me.Options_FileAssocs.SuspendLayout()
        Me.FlowLayoutPanel10.SuspendLayout()
        Me.Options_Startup.SuspendLayout()
        Me.FlowLayoutPanel11.SuspendLayout()
        Me.Panel20.SuspendLayout()
        Me.SuspendLayout()
        '
        'TableLayoutPanel1
        '
        Me.TableLayoutPanel1.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TableLayoutPanel1.ColumnCount = 2
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel1.Controls.Add(Me.OK_Button, 0, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.Cancel_Button, 1, 0)
        Me.TableLayoutPanel1.Location = New System.Drawing.Point(850, 10)
        Me.TableLayoutPanel1.Name = "TableLayoutPanel1"
        Me.TableLayoutPanel1.RowCount = 1
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel1.Size = New System.Drawing.Size(146, 29)
        Me.TableLayoutPanel1.TabIndex = 0
        '
        'OK_Button
        '
        Me.OK_Button.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.OK_Button.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.OK_Button.Location = New System.Drawing.Point(3, 3)
        Me.OK_Button.Name = "OK_Button"
        Me.OK_Button.Size = New System.Drawing.Size(67, 23)
        Me.OK_Button.TabIndex = 0
        Me.OK_Button.Text = "OK"
        '
        'Cancel_Button
        '
        Me.Cancel_Button.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Cancel_Button.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.Cancel_Button.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.Cancel_Button.Location = New System.Drawing.Point(76, 3)
        Me.Cancel_Button.Name = "Cancel_Button"
        Me.Cancel_Button.Size = New System.Drawing.Size(67, 23)
        Me.Cancel_Button.TabIndex = 1
        Me.Cancel_Button.Text = "Cancel"
        '
        'Win10Title
        '
        Me.Win10Title.BackColor = System.Drawing.Color.White
        Me.Win10Title.Controls.Add(Me.PictureBox1)
        Me.Win10Title.Controls.Add(Me.Label1)
        Me.Win10Title.Dock = System.Windows.Forms.DockStyle.Top
        Me.Win10Title.Location = New System.Drawing.Point(0, 0)
        Me.Win10Title.Name = "Win10Title"
        Me.Win10Title.Size = New System.Drawing.Size(1008, 48)
        Me.Win10Title.TabIndex = 2
        Me.Win10Title.Visible = False
        '
        'PictureBox1
        '
        Me.PictureBox1.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.PictureBox1.Image = Global.DISMTools.My.Resources.Resources.settings
        Me.PictureBox1.Location = New System.Drawing.Point(964, 8)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(32, 32)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.PictureBox1.TabIndex = 1
        Me.PictureBox1.TabStop = False
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Segoe UI", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(12, 9)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(86, 30)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Options"
        '
        'DismOFD
        '
        Me.DismOFD.FileName = "dism.exe"
        Me.DismOFD.Filter = "DISM executable|dism.exe"
        Me.DismOFD.Title = "Specify the DISM executable to use"
        '
        'ScratchFBD
        '
        Me.ScratchFBD.Description = "Specify the scratch directory the program should use:"
        Me.ScratchFBD.RootFolder = System.Environment.SpecialFolder.MyComputer
        '
        'CheckBox13
        '
        Me.CheckBox13.AutoSize = True
        Me.CheckBox13.Location = New System.Drawing.Point(56, 76)
        Me.CheckBox13.Name = "CheckBox13"
        Me.CheckBox13.Size = New System.Drawing.Size(122, 19)
        Me.CheckBox13.TabIndex = 2
        Me.CheckBox13.Text = "Check for updates"
        Me.CheckBox13.UseVisualStyleBackColor = True
        '
        'CheckBox12
        '
        Me.CheckBox12.AutoSize = True
        Me.CheckBox12.Location = New System.Drawing.Point(56, 53)
        Me.CheckBox12.Name = "CheckBox12"
        Me.CheckBox12.Size = New System.Drawing.Size(360, 19)
        Me.CheckBox12.TabIndex = 2
        Me.CheckBox12.Text = "Remount mounted images in need of a servicing session reload"
        Me.CheckBox12.UseVisualStyleBackColor = True
        '
        'Label43
        '
        Me.Label43.AutoSize = True
        Me.Label43.Location = New System.Drawing.Point(22, 19)
        Me.Label43.Name = "Label43"
        Me.Label43.Size = New System.Drawing.Size(358, 15)
        Me.Label43.TabIndex = 1
        Me.Label43.Text = "Set options you would like to perform when the program starts up:"
        '
        'Panel3
        '
        Me.Panel3.Controls.Add(Me.Label46)
        Me.Panel3.Controls.Add(Me.PictureBox8)
        Me.Panel3.Location = New System.Drawing.Point(0, 242)
        Me.Panel3.Margin = New System.Windows.Forms.Padding(0)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(746, 57)
        Me.Panel3.TabIndex = 13
        '
        'Label46
        '
        Me.Label46.Location = New System.Drawing.Point(44, 19)
        Me.Label46.Name = "Label46"
        Me.Label46.Size = New System.Drawing.Size(682, 32)
        Me.Label46.TabIndex = 11
        Me.Label46.Text = "These settings aren't applicable to non-portable installations"
        '
        'PictureBox8
        '
        Me.PictureBox8.Image = Global.DISMTools.My.Resources.Resources.info_16px
        Me.PictureBox8.Location = New System.Drawing.Point(22, 18)
        Me.PictureBox8.Name = "PictureBox8"
        Me.PictureBox8.Size = New System.Drawing.Size(16, 16)
        Me.PictureBox8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.PictureBox8.TabIndex = 10
        Me.PictureBox8.TabStop = False
        '
        'Panel2
        '
        Me.Panel2.Controls.Add(Me.GroupBox5)
        Me.Panel2.Controls.Add(Me.Label40)
        Me.Panel2.Location = New System.Drawing.Point(0, 0)
        Me.Panel2.Margin = New System.Windows.Forms.Padding(0)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(748, 242)
        Me.Panel2.TabIndex = 12
        '
        'GroupBox5
        '
        Me.GroupBox5.Controls.Add(Me.CheckBox11)
        Me.GroupBox5.Controls.Add(Me.Button9)
        Me.GroupBox5.Controls.Add(Me.Label41)
        Me.GroupBox5.Controls.Add(Me.Label42)
        Me.GroupBox5.Location = New System.Drawing.Point(24, 71)
        Me.GroupBox5.Name = "GroupBox5"
        Me.GroupBox5.Size = New System.Drawing.Size(700, 153)
        Me.GroupBox5.TabIndex = 1
        Me.GroupBox5.TabStop = False
        Me.GroupBox5.Text = "Associations"
        '
        'CheckBox11
        '
        Me.CheckBox11.AutoSize = True
        Me.CheckBox11.Location = New System.Drawing.Point(31, 60)
        Me.CheckBox11.Name = "CheckBox11"
        Me.CheckBox11.Size = New System.Drawing.Size(256, 19)
        Me.CheckBox11.TabIndex = 2
        Me.CheckBox11.Text = "Set custom file icons for DISMTools projects"
        Me.CheckBox11.UseVisualStyleBackColor = True
        '
        'Button9
        '
        Me.Button9.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button9.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.Button9.Location = New System.Drawing.Point(217, 111)
        Me.Button9.Name = "Button9"
        Me.Button9.Size = New System.Drawing.Size(266, 23)
        Me.Button9.TabIndex = 1
        Me.Button9.Text = "Set file associations"
        Me.Button9.UseVisualStyleBackColor = True
        '
        'Label41
        '
        Me.Label41.Location = New System.Drawing.Point(28, 29)
        Me.Label41.Name = "Label41"
        Me.Label41.Size = New System.Drawing.Size(180, 15)
        Me.Label41.TabIndex = 0
        Me.Label41.Text = "Association status:"
        Me.Label41.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label42
        '
        Me.Label42.AutoSize = True
        Me.Label42.Location = New System.Drawing.Point(214, 30)
        Me.Label42.Name = "Label42"
        Me.Label42.Size = New System.Drawing.Size(84, 15)
        Me.Label42.TabIndex = 0
        Me.Label42.Text = "<assocStatus>"
        '
        'Label40
        '
        Me.Label40.AutoEllipsis = True
        Me.Label40.Location = New System.Drawing.Point(22, 22)
        Me.Label40.Name = "Label40"
        Me.Label40.Size = New System.Drawing.Size(705, 38)
        Me.Label40.TabIndex = 0
        Me.Label40.Text = "File associations let you access project files directly, without having to load t" & _
    "he program first"
        '
        'Label39
        '
        Me.Label39.Location = New System.Drawing.Point(20, 148)
        Me.Label39.Name = "Label39"
        Me.Label39.Size = New System.Drawing.Size(704, 56)
        Me.Label39.TabIndex = 2
        Me.Label39.Text = resources.GetString("Label39.Text")
        Me.Label39.Visible = False
        '
        'Button8
        '
        Me.Button8.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.Button8.Location = New System.Drawing.Point(647, 114)
        Me.Button8.Name = "Button8"
        Me.Button8.Size = New System.Drawing.Size(75, 23)
        Me.Button8.TabIndex = 1
        Me.Button8.Text = "Stop"
        Me.Button8.UseVisualStyleBackColor = True
        '
        'Label38
        '
        Me.Label38.AutoSize = True
        Me.Label38.Location = New System.Drawing.Point(65, 118)
        Me.Label38.Name = "Label38"
        Me.Label38.Size = New System.Drawing.Size(93, 15)
        Me.Label38.TabIndex = 0
        Me.Label38.Text = "<bgProcStatus>"
        '
        'Label37
        '
        Me.Label37.AutoSize = True
        Me.Label37.Location = New System.Drawing.Point(17, 118)
        Me.Label37.Name = "Label37"
        Me.Label37.Size = New System.Drawing.Size(42, 15)
        Me.Label37.TabIndex = 0
        Me.Label37.Text = "Status:"
        '
        'Label36
        '
        Me.Label36.AutoSize = True
        Me.Label36.Location = New System.Drawing.Point(17, 90)
        Me.Label36.Name = "Label36"
        Me.Label36.Size = New System.Drawing.Size(247, 15)
        Me.Label36.TabIndex = 0
        Me.Label36.Text = "Review the status of this background process:"
        '
        'CheckBox8
        '
        Me.CheckBox8.AutoSize = True
        Me.CheckBox8.Checked = True
        Me.CheckBox8.CheckState = System.Windows.Forms.CheckState.Checked
        Me.CheckBox8.Enabled = False
        Me.CheckBox8.Location = New System.Drawing.Point(18, 57)
        Me.CheckBox8.Name = "CheckBox8"
        Me.CheckBox8.Size = New System.Drawing.Size(213, 19)
        Me.CheckBox8.TabIndex = 1
        Me.CheckBox8.Text = "Detect mounted images at all times"
        Me.CheckBox8.UseVisualStyleBackColor = True
        '
        'Label35
        '
        Me.Label35.AutoEllipsis = True
        Me.Label35.Location = New System.Drawing.Point(17, 16)
        Me.Label35.Name = "Label35"
        Me.Label35.Size = New System.Drawing.Size(703, 35)
        Me.Label35.TabIndex = 0
        Me.Label35.Text = "Modify these settings only if you experience constant program or system slowdowns" & _
    " due to high CPU usage"
        '
        'Button10
        '
        Me.Button10.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button10.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.Button10.Location = New System.Drawing.Point(522, 349)
        Me.Button10.Name = "Button10"
        Me.Button10.Size = New System.Drawing.Size(185, 23)
        Me.Button10.TabIndex = 7
        Me.Button10.Text = "Advanced settings"
        Me.Button10.UseVisualStyleBackColor = True
        '
        'LinkLabel2
        '
        Me.LinkLabel2.AutoSize = True
        Me.LinkLabel2.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline
        Me.LinkLabel2.LinkColor = System.Drawing.Color.DodgerBlue
        Me.LinkLabel2.Location = New System.Drawing.Point(20, 353)
        Me.LinkLabel2.Name = "LinkLabel2"
        Me.LinkLabel2.Size = New System.Drawing.Size(222, 15)
        Me.LinkLabel2.TabIndex = 6
        Me.LinkLabel2.TabStop = True
        Me.LinkLabel2.Text = "Learn more about background processes"
        '
        'Label29
        '
        Me.Label29.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label29.Location = New System.Drawing.Point(19, 119)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(688, 30)
        Me.Label29.TabIndex = 3
        Me.Label29.Text = "The program uses background processes to gather complete image information, like " & _
    "modification dates, installed packages, features present; and more"
        '
        'ComboBox6
        '
        Me.ComboBox6.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.ComboBox6.FormattingEnabled = True
        Me.ComboBox6.Items.AddRange(New Object() {"Every time a project has been loaded successfully", "Once"})
        Me.ComboBox6.Location = New System.Drawing.Point(9, 31)
        Me.ComboBox6.Name = "ComboBox6"
        Me.ComboBox6.Size = New System.Drawing.Size(640, 23)
        Me.ComboBox6.TabIndex = 4
        Me.ComboBox6.Text = "Every time a project has been loaded successfully"
        '
        'Label28
        '
        Me.Label28.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label28.AutoEllipsis = True
        Me.Label28.Location = New System.Drawing.Point(6, 8)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(640, 18)
        Me.Label28.TabIndex = 3
        Me.Label28.Text = "When should the program notify you about background processes being started?"
        '
        'CheckBox6
        '
        Me.CheckBox6.AutoSize = True
        Me.CheckBox6.Checked = True
        Me.CheckBox6.CheckState = System.Windows.Forms.CheckState.Checked
        Me.CheckBox6.Location = New System.Drawing.Point(20, 16)
        Me.CheckBox6.Name = "CheckBox6"
        Me.CheckBox6.Size = New System.Drawing.Size(299, 19)
        Me.CheckBox6.TabIndex = 2
        Me.CheckBox6.Text = "Notify me when background processes have started"
        Me.CheckBox6.UseVisualStyleBackColor = True
        '
        'PictureBox7
        '
        Me.PictureBox7.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.PictureBox7.Image = Global.DISMTools.My.Resources.Resources.bgproc_notify
        Me.PictureBox7.Location = New System.Drawing.Point(191, 163)
        Me.PictureBox7.Name = "PictureBox7"
        Me.PictureBox7.Size = New System.Drawing.Size(366, 163)
        Me.PictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.PictureBox7.TabIndex = 5
        Me.PictureBox7.TabStop = False
        '
        'Label27
        '
        Me.Label27.Location = New System.Drawing.Point(41, 353)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(682, 32)
        Me.Label27.TabIndex = 9
        Me.Label27.Text = "Some reports do not allow being shown as a table."
        '
        'TextBox4
        '
        Me.TextBox4.Font = New System.Drawing.Font("Courier New", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox4.Location = New System.Drawing.Point(19, 106)
        Me.TextBox4.Multiline = True
        Me.TextBox4.Name = "TextBox4"
        Me.TextBox4.ReadOnly = True
        Me.TextBox4.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.TextBox4.Size = New System.Drawing.Size(707, 240)
        Me.TextBox4.TabIndex = 5
        Me.TextBox4.Text = resources.GetString("TextBox4.Text")
        '
        'ComboBox5
        '
        Me.ComboBox5.FormattingEnabled = True
        Me.ComboBox5.Items.AddRange(New Object() {"list", "table"})
        Me.ComboBox5.Location = New System.Drawing.Point(19, 35)
        Me.ComboBox5.Name = "ComboBox5"
        Me.ComboBox5.Size = New System.Drawing.Size(133, 23)
        Me.ComboBox5.TabIndex = 3
        Me.ComboBox5.Text = "list"
        '
        'Label26
        '
        Me.Label26.AutoSize = True
        Me.Label26.Location = New System.Drawing.Point(16, 81)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(90, 15)
        Me.Label26.TabIndex = 2
        Me.Label26.Text = "Example report:"
        '
        'Label25
        '
        Me.Label25.AutoSize = True
        Me.Label25.Location = New System.Drawing.Point(16, 17)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(57, 15)
        Me.Label25.TabIndex = 2
        Me.Label25.Text = "Log view:"
        '
        'CheckBox5
        '
        Me.CheckBox5.AutoSize = True
        Me.CheckBox5.Checked = True
        Me.CheckBox5.CheckState = System.Windows.Forms.CheckState.Checked
        Me.CheckBox5.Location = New System.Drawing.Point(18, 16)
        Me.CheckBox5.Name = "CheckBox5"
        Me.CheckBox5.Size = New System.Drawing.Size(206, 19)
        Me.CheckBox5.TabIndex = 1
        Me.CheckBox5.Text = "Show command output in English"
        Me.CheckBox5.UseVisualStyleBackColor = True
        '
        'PictureBox6
        '
        Me.PictureBox6.Image = Global.DISMTools.My.Resources.Resources.info_16px
        Me.PictureBox6.Location = New System.Drawing.Point(19, 352)
        Me.PictureBox6.Name = "PictureBox6"
        Me.PictureBox6.Size = New System.Drawing.Size(16, 16)
        Me.PictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.PictureBox6.TabIndex = 8
        Me.PictureBox6.TabStop = False
        '
        'RadioButton4
        '
        Me.RadioButton4.AutoSize = True
        Me.RadioButton4.Enabled = False
        Me.RadioButton4.Location = New System.Drawing.Point(41, 103)
        Me.RadioButton4.Name = "RadioButton4"
        Me.RadioButton4.Size = New System.Drawing.Size(205, 19)
        Me.RadioButton4.TabIndex = 12
        Me.RadioButton4.Text = "Use the specified scratch directory"
        Me.RadioButton4.UseVisualStyleBackColor = True
        '
        'RadioButton3
        '
        Me.RadioButton3.AutoSize = True
        Me.RadioButton3.Checked = True
        Me.RadioButton3.Enabled = False
        Me.RadioButton3.Location = New System.Drawing.Point(41, 41)
        Me.RadioButton3.Name = "RadioButton3"
        Me.RadioButton3.Size = New System.Drawing.Size(258, 19)
        Me.RadioButton3.TabIndex = 12
        Me.RadioButton3.TabStop = True
        Me.RadioButton3.Text = "Use the project or program scratch directory"
        Me.RadioButton3.UseVisualStyleBackColor = True
        '
        'Label24
        '
        Me.Label24.Enabled = False
        Me.Label24.Location = New System.Drawing.Point(81, 212)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(629, 32)
        Me.Label24.TabIndex = 11
        Me.Label24.Text = "You may not have enough space on the selected scratch directory for some operatio" & _
    "ns."
        Me.Label24.Visible = False
        '
        'Label23
        '
        Me.Label23.AutoEllipsis = True
        Me.Label23.Enabled = False
        Me.Label23.Location = New System.Drawing.Point(295, 179)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(431, 25)
        Me.Label23.TabIndex = 4
        Me.Label23.Text = "<scdir_space>"
        Me.Label23.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label22
        '
        Me.Label22.AutoEllipsis = True
        Me.Label22.Enabled = False
        Me.Label22.Location = New System.Drawing.Point(57, 178)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(232, 25)
        Me.Label22.TabIndex = 4
        Me.Label22.Text = "Space left on selected scratch directory:"
        Me.Label22.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Button4
        '
        Me.Button4.Enabled = False
        Me.Button4.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.Button4.Location = New System.Drawing.Point(635, 152)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(75, 23)
        Me.Button4.TabIndex = 3
        Me.Button4.Text = "Browse..."
        Me.Button4.UseVisualStyleBackColor = True
        '
        'TextBox3
        '
        Me.TextBox3.Enabled = False
        Me.TextBox3.Location = New System.Drawing.Point(170, 152)
        Me.TextBox3.Name = "TextBox3"
        Me.TextBox3.Size = New System.Drawing.Size(459, 23)
        Me.TextBox3.TabIndex = 2
        '
        'Label21
        '
        Me.Label21.AutoEllipsis = True
        Me.Label21.Enabled = False
        Me.Label21.Location = New System.Drawing.Point(56, 152)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(108, 23)
        Me.Label21.TabIndex = 1
        Me.Label21.Text = "Scratch directory:"
        Me.Label21.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label44
        '
        Me.Label44.AutoEllipsis = True
        Me.Label44.Enabled = False
        Me.Label44.Location = New System.Drawing.Point(56, 64)
        Me.Label44.Name = "Label44"
        Me.Label44.Size = New System.Drawing.Size(654, 36)
        Me.Label44.TabIndex = 1
        Me.Label44.Text = "The program will use the scratch directory provided by the project if one is load" & _
    "ed. If you are in the online or offline installation management modes, the progr" & _
    "am will use its scratch directory"
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Enabled = False
        Me.Label20.Location = New System.Drawing.Point(56, 130)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(360, 15)
        Me.Label20.TabIndex = 1
        Me.Label20.Text = "Please specify the scratch directory to be used for DISM operations:"
        '
        'CheckBox4
        '
        Me.CheckBox4.AutoSize = True
        Me.CheckBox4.Location = New System.Drawing.Point(21, 17)
        Me.CheckBox4.Name = "CheckBox4"
        Me.CheckBox4.Size = New System.Drawing.Size(145, 19)
        Me.CheckBox4.TabIndex = 0
        Me.CheckBox4.Text = "Use a scratch directory"
        Me.CheckBox4.UseVisualStyleBackColor = True
        '
        'PictureBox5
        '
        Me.PictureBox5.Enabled = False
        Me.PictureBox5.Image = Global.DISMTools.My.Resources.Resources.warning_16px
        Me.PictureBox5.Location = New System.Drawing.Point(59, 211)
        Me.PictureBox5.Name = "PictureBox5"
        Me.PictureBox5.Size = New System.Drawing.Size(16, 16)
        Me.PictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.PictureBox5.TabIndex = 10
        Me.PictureBox5.TabStop = False
        Me.PictureBox5.Visible = False
        '
        'CheckBox14
        '
        Me.CheckBox14.AutoSize = True
        Me.CheckBox14.Location = New System.Drawing.Point(41, 77)
        Me.CheckBox14.Name = "CheckBox14"
        Me.CheckBox14.Size = New System.Drawing.Size(353, 19)
        Me.CheckBox14.TabIndex = 1
        Me.CheckBox14.Text = "Always save complete information for the following elements:"
        Me.CheckBox14.UseVisualStyleBackColor = True
        '
        'Label48
        '
        Me.Label48.AutoEllipsis = True
        Me.Label48.Location = New System.Drawing.Point(41, 47)
        Me.Label48.Name = "Label48"
        Me.Label48.Size = New System.Drawing.Size(665, 26)
        Me.Label48.TabIndex = 0
        Me.Label48.Text = "Choose the settings the program should consider when saving image information:"
        '
        'TableLayoutPanel2
        '
        Me.TableLayoutPanel2.ColumnCount = 3
        Me.TableLayoutPanel2.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333!))
        Me.TableLayoutPanel2.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333!))
        Me.TableLayoutPanel2.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333!))
        Me.TableLayoutPanel2.Controls.Add(Me.CheckBox15, 0, 0)
        Me.TableLayoutPanel2.Controls.Add(Me.CheckBox19, 2, 0)
        Me.TableLayoutPanel2.Controls.Add(Me.CheckBox18, 1, 1)
        Me.TableLayoutPanel2.Controls.Add(Me.CheckBox16, 0, 1)
        Me.TableLayoutPanel2.Controls.Add(Me.CheckBox17, 1, 0)
        Me.TableLayoutPanel2.Enabled = False
        Me.TableLayoutPanel2.Location = New System.Drawing.Point(57, 102)
        Me.TableLayoutPanel2.Name = "TableLayoutPanel2"
        Me.TableLayoutPanel2.RowCount = 2
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel2.Size = New System.Drawing.Size(627, 51)
        Me.TableLayoutPanel2.TabIndex = 2
        '
        'CheckBox15
        '
        Me.CheckBox15.AutoSize = True
        Me.CheckBox15.Checked = True
        Me.CheckBox15.CheckState = System.Windows.Forms.CheckState.Checked
        Me.CheckBox15.Location = New System.Drawing.Point(3, 3)
        Me.CheckBox15.Name = "CheckBox15"
        Me.CheckBox15.Size = New System.Drawing.Size(122, 19)
        Me.CheckBox15.TabIndex = 1
        Me.CheckBox15.Text = "Installed packages"
        Me.CheckBox15.UseVisualStyleBackColor = True
        '
        'CheckBox19
        '
        Me.CheckBox19.AutoSize = True
        Me.CheckBox19.Checked = True
        Me.CheckBox19.CheckState = System.Windows.Forms.CheckState.Checked
        Me.CheckBox19.Location = New System.Drawing.Point(421, 3)
        Me.CheckBox19.Name = "CheckBox19"
        Me.CheckBox19.Size = New System.Drawing.Size(108, 19)
        Me.CheckBox19.TabIndex = 1
        Me.CheckBox19.Text = "Installed drivers"
        Me.CheckBox19.UseVisualStyleBackColor = True
        '
        'CheckBox18
        '
        Me.CheckBox18.AutoSize = True
        Me.CheckBox18.Checked = True
        Me.CheckBox18.CheckState = System.Windows.Forms.CheckState.Checked
        Me.CheckBox18.Location = New System.Drawing.Point(212, 28)
        Me.CheckBox18.Name = "CheckBox18"
        Me.CheckBox18.Size = New System.Drawing.Size(87, 19)
        Me.CheckBox18.TabIndex = 1
        Me.CheckBox18.Text = "Capabilities"
        Me.CheckBox18.UseVisualStyleBackColor = True
        '
        'CheckBox16
        '
        Me.CheckBox16.AutoSize = True
        Me.CheckBox16.Checked = True
        Me.CheckBox16.CheckState = System.Windows.Forms.CheckState.Checked
        Me.CheckBox16.Location = New System.Drawing.Point(3, 28)
        Me.CheckBox16.Name = "CheckBox16"
        Me.CheckBox16.Size = New System.Drawing.Size(70, 19)
        Me.CheckBox16.TabIndex = 1
        Me.CheckBox16.Text = "Features"
        Me.CheckBox16.UseVisualStyleBackColor = True
        '
        'CheckBox17
        '
        Me.CheckBox17.AutoSize = True
        Me.CheckBox17.Checked = True
        Me.CheckBox17.CheckState = System.Windows.Forms.CheckState.Checked
        Me.CheckBox17.Location = New System.Drawing.Point(212, 3)
        Me.CheckBox17.Name = "CheckBox17"
        Me.CheckBox17.Size = New System.Drawing.Size(154, 19)
        Me.CheckBox17.TabIndex = 1
        Me.CheckBox17.Text = "Installed AppX packages"
        Me.CheckBox17.UseVisualStyleBackColor = True
        '
        'Label19
        '
        Me.Label19.AutoEllipsis = True
        Me.Label19.Location = New System.Drawing.Point(38, 130)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(687, 34)
        Me.Label19.TabIndex = 8
        Me.Label19.Text = "When this option is checked, your computer will not restart automatically; even w" & _
    "hen quietly performing operations."
        '
        'Label18
        '
        Me.Label18.AutoEllipsis = True
        Me.Label18.Location = New System.Drawing.Point(38, 40)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(687, 64)
        Me.Label18.TabIndex = 8
        Me.Label18.Text = resources.GetString("Label18.Text")
        '
        'CheckBox3
        '
        Me.CheckBox3.AutoSize = True
        Me.CheckBox3.Location = New System.Drawing.Point(21, 109)
        Me.CheckBox3.Name = "CheckBox3"
        Me.CheckBox3.Size = New System.Drawing.Size(124, 19)
        Me.CheckBox3.TabIndex = 6
        Me.CheckBox3.Text = "Skip system restart"
        Me.CheckBox3.UseVisualStyleBackColor = True
        '
        'CheckBox2
        '
        Me.CheckBox2.AutoSize = True
        Me.CheckBox2.Location = New System.Drawing.Point(21, 19)
        Me.CheckBox2.Name = "CheckBox2"
        Me.CheckBox2.Size = New System.Drawing.Size(205, 19)
        Me.CheckBox2.TabIndex = 6
        Me.CheckBox2.Text = "Quietly perform image operations"
        Me.CheckBox2.UseVisualStyleBackColor = True
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.Label16)
        Me.Panel1.Controls.Add(Me.Label15)
        Me.Panel1.Location = New System.Drawing.Point(78, 47)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(631, 74)
        Me.Panel1.TabIndex = 9
        '
        'Label16
        '
        Me.Label16.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label16.Location = New System.Drawing.Point(18, 28)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(596, 33)
        Me.Label16.TabIndex = 0
        Me.Label16.Text = "The log file should display errors, warnings and information messages after perfo" & _
    "rming an image operation."
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label15.Location = New System.Drawing.Point(8, 8)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(315, 15)
        Me.Label15.TabIndex = 0
        Me.Label15.Text = "Errors, warnings and information messages (Log level 3)"
        '
        'TrackBar1
        '
        Me.TrackBar1.BackColor = System.Drawing.SystemColors.Control
        Me.TrackBar1.LargeChange = 1
        Me.TrackBar1.Location = New System.Drawing.Point(27, 47)
        Me.TrackBar1.Maximum = 3
        Me.TrackBar1.Name = "TrackBar1"
        Me.TrackBar1.Orientation = System.Windows.Forms.Orientation.Vertical
        Me.TrackBar1.Size = New System.Drawing.Size(45, 74)
        Me.TrackBar1.TabIndex = 8
        Me.TrackBar1.TickStyle = System.Windows.Forms.TickStyle.Both
        Me.TrackBar1.Value = 2
        '
        'Label13
        '
        Me.Label13.Location = New System.Drawing.Point(40, 70)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(685, 33)
        Me.Label13.TabIndex = 7
        Me.Label13.Text = "When performing image operations in the command line, specify the ""/LogPath"" argu" & _
    "ment to save the image operation log to the target log file."
        '
        'Button3
        '
        Me.Button3.Enabled = False
        Me.Button3.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.Button3.Location = New System.Drawing.Point(650, 40)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(75, 23)
        Me.Button3.TabIndex = 5
        Me.Button3.Text = "Browse..."
        Me.Button3.UseVisualStyleBackColor = True
        '
        'TextBox2
        '
        Me.TextBox2.Enabled = False
        Me.TextBox2.Location = New System.Drawing.Point(166, 40)
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.Size = New System.Drawing.Size(478, 23)
        Me.TextBox2.TabIndex = 4
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold)
        Me.Label14.Location = New System.Drawing.Point(15, 18)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(81, 15)
        Me.Label14.TabIndex = 3
        Me.Label14.Text = "Log file level:"
        '
        'Label12
        '
        Me.Label12.AutoEllipsis = True
        Me.Label12.Enabled = False
        Me.Label12.Location = New System.Drawing.Point(33, 39)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(123, 23)
        Me.Label12.TabIndex = 3
        Me.Label12.Text = "Operation log file:"
        Me.Label12.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'CheckBox10
        '
        Me.CheckBox10.AutoSize = True
        Me.CheckBox10.Checked = True
        Me.CheckBox10.CheckState = System.Windows.Forms.CheckState.Checked
        Me.CheckBox10.Location = New System.Drawing.Point(18, 17)
        Me.CheckBox10.Name = "CheckBox10"
        Me.CheckBox10.Size = New System.Drawing.Size(319, 19)
        Me.CheckBox10.TabIndex = 10
        Me.CheckBox10.Text = "Automatically create logs for each operation performed"
        Me.CheckBox10.UseVisualStyleBackColor = True
        '
        'PictureBox4
        '
        Me.PictureBox4.Image = Global.DISMTools.My.Resources.Resources.info_16px
        Me.PictureBox4.Location = New System.Drawing.Point(18, 70)
        Me.PictureBox4.Name = "PictureBox4"
        Me.PictureBox4.Size = New System.Drawing.Size(16, 16)
        Me.PictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.PictureBox4.TabIndex = 6
        Me.PictureBox4.TabStop = False
        '
        'CheckBox20
        '
        Me.CheckBox20.AutoSize = True
        Me.CheckBox20.Location = New System.Drawing.Point(21, 90)
        Me.CheckBox20.Name = "CheckBox20"
        Me.CheckBox20.Size = New System.Drawing.Size(195, 19)
        Me.CheckBox20.TabIndex = 8
        Me.CheckBox20.Text = "Use the new project view design"
        Me.CheckBox20.UseVisualStyleBackColor = True
        '
        'SecProgressStylePreview
        '
        Me.SecProgressStylePreview.Image = Global.DISMTools.My.Resources.Resources.secprogress_modern
        Me.SecProgressStylePreview.Location = New System.Drawing.Point(348, 33)
        Me.SecProgressStylePreview.Name = "SecProgressStylePreview"
        Me.SecProgressStylePreview.Size = New System.Drawing.Size(360, 60)
        Me.SecProgressStylePreview.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.SecProgressStylePreview.TabIndex = 7
        Me.SecProgressStylePreview.TabStop = False
        '
        'RadioButton6
        '
        Me.RadioButton6.AutoSize = True
        Me.RadioButton6.Location = New System.Drawing.Point(48, 65)
        Me.RadioButton6.Name = "RadioButton6"
        Me.RadioButton6.Size = New System.Drawing.Size(61, 19)
        Me.RadioButton6.TabIndex = 6
        Me.RadioButton6.Text = "Classic"
        Me.RadioButton6.UseVisualStyleBackColor = True
        '
        'RadioButton5
        '
        Me.RadioButton5.AutoSize = True
        Me.RadioButton5.Checked = True
        Me.RadioButton5.Location = New System.Drawing.Point(48, 40)
        Me.RadioButton5.Name = "RadioButton5"
        Me.RadioButton5.Size = New System.Drawing.Size(67, 19)
        Me.RadioButton5.TabIndex = 6
        Me.RadioButton5.TabStop = True
        Me.RadioButton5.Text = "Modern"
        Me.RadioButton5.UseVisualStyleBackColor = True
        '
        'Label45
        '
        Me.Label45.AutoEllipsis = True
        Me.Label45.Location = New System.Drawing.Point(18, 13)
        Me.Label45.Name = "Label45"
        Me.Label45.Size = New System.Drawing.Size(330, 24)
        Me.Label45.TabIndex = 2
        Me.Label45.Text = "Secondary progress panel style:"
        Me.Label45.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Panel4
        '
        Me.Panel4.Controls.Add(Me.Label47)
        Me.Panel4.Controls.Add(Me.PictureBox9)
        Me.Panel4.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.Panel4.Location = New System.Drawing.Point(0, 313)
        Me.Panel4.Name = "Panel4"
        Me.Panel4.Size = New System.Drawing.Size(728, 50)
        Me.Panel4.TabIndex = 7
        Me.Panel4.Visible = False
        '
        'Label47
        '
        Me.Label47.Location = New System.Drawing.Point(44, 7)
        Me.Label47.Name = "Label47"
        Me.Label47.Size = New System.Drawing.Size(641, 33)
        Me.Label47.TabIndex = 9
        Me.Label47.Text = "This font may not be readable on log windows. While you can still use it, we reco" & _
    "mmend monospaced fonts for increased readability."
        '
        'PictureBox9
        '
        Me.PictureBox9.Image = Global.DISMTools.My.Resources.Resources.info_16px
        Me.PictureBox9.Location = New System.Drawing.Point(21, 7)
        Me.PictureBox9.Name = "PictureBox9"
        Me.PictureBox9.Size = New System.Drawing.Size(16, 16)
        Me.PictureBox9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.PictureBox9.TabIndex = 8
        Me.PictureBox9.TabStop = False
        '
        'Toggle1
        '
        Me.Toggle1.Appearance = System.Windows.Forms.Appearance.Button
        Me.Toggle1.AutoSize = True
        Me.Toggle1.Image = Global.DISMTools.My.Resources.Resources.bold_font
        Me.Toggle1.Location = New System.Drawing.Point(662, 52)
        Me.Toggle1.Name = "Toggle1"
        Me.Toggle1.Size = New System.Drawing.Size(22, 22)
        Me.Toggle1.TabIndex = 6
        Me.Toggle1.UseVisualStyleBackColor = True
        '
        'NumericUpDown1
        '
        Me.NumericUpDown1.Location = New System.Drawing.Point(606, 52)
        Me.NumericUpDown1.Maximum = New Decimal(New Integer() {96, 0, 0, 0})
        Me.NumericUpDown1.Minimum = New Decimal(New Integer() {8, 0, 0, 0})
        Me.NumericUpDown1.Name = "NumericUpDown1"
        Me.NumericUpDown1.Size = New System.Drawing.Size(50, 23)
        Me.NumericUpDown1.TabIndex = 5
        Me.NumericUpDown1.Value = New Decimal(New Integer() {10, 0, 0, 0})
        '
        'LogPreview
        '
        Me.LogPreview.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.LogPreview.Font = New System.Drawing.Font("Courier New", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LogPreview.Location = New System.Drawing.Point(44, 122)
        Me.LogPreview.Multiline = True
        Me.LogPreview.Name = "LogPreview"
        Me.LogPreview.ReadOnly = True
        Me.LogPreview.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.LogPreview.Size = New System.Drawing.Size(643, 182)
        Me.LogPreview.TabIndex = 4
        Me.LogPreview.Text = resources.GetString("LogPreview.Text")
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(18, 89)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(51, 15)
        Me.Label11.TabIndex = 0
        Me.Label11.Text = "Preview:"
        '
        'Label10
        '
        Me.Label10.AutoEllipsis = True
        Me.Label10.Location = New System.Drawing.Point(41, 50)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(123, 24)
        Me.Label10.TabIndex = 2
        Me.Label10.Text = "Log window font:"
        Me.Label10.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'ComboBox4
        '
        Me.ComboBox4.FormattingEnabled = True
        Me.ComboBox4.Location = New System.Drawing.Point(170, 52)
        Me.ComboBox4.Name = "ComboBox4"
        Me.ComboBox4.Size = New System.Drawing.Size(430, 23)
        Me.ComboBox4.TabIndex = 3
        Me.ComboBox4.Text = "Courier New"
        '
        'CheckBox9
        '
        Me.CheckBox9.AutoSize = True
        Me.CheckBox9.Location = New System.Drawing.Point(21, 71)
        Me.CheckBox9.Name = "CheckBox9"
        Me.CheckBox9.Size = New System.Drawing.Size(141, 19)
        Me.CheckBox9.TabIndex = 5
        Me.CheckBox9.Text = "Use uppercase menus"
        Me.CheckBox9.UseVisualStyleBackColor = True
        '
        'ComboBox3
        '
        Me.ComboBox3.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.ComboBox3.FormattingEnabled = True
        Me.ComboBox3.Items.AddRange(New Object() {"Use system language", "English", "Spanish", "French", "Portuguese"})
        Me.ComboBox3.Location = New System.Drawing.Point(119, 42)
        Me.ComboBox3.Name = "ComboBox3"
        Me.ComboBox3.Size = New System.Drawing.Size(592, 23)
        Me.ComboBox3.TabIndex = 3
        Me.ComboBox3.Text = "English"
        '
        'ComboBox2
        '
        Me.ComboBox2.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.ComboBox2.FormattingEnabled = True
        Me.ComboBox2.Items.AddRange(New Object() {"Use system setting", "Light mode", "Dark mode"})
        Me.ComboBox2.Location = New System.Drawing.Point(119, 13)
        Me.ComboBox2.Name = "ComboBox2"
        Me.ComboBox2.Size = New System.Drawing.Size(592, 23)
        Me.ComboBox2.TabIndex = 3
        Me.ComboBox2.Text = "Use system setting"
        '
        'Label8
        '
        Me.Label8.AutoEllipsis = True
        Me.Label8.Location = New System.Drawing.Point(18, 42)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(95, 23)
        Me.Label8.TabIndex = 2
        Me.Label8.Text = "Language:"
        Me.Label8.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label7
        '
        Me.Label7.AutoEllipsis = True
        Me.Label7.Location = New System.Drawing.Point(18, 13)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(95, 23)
        Me.Label7.TabIndex = 2
        Me.Label7.Text = "Color mode:"
        Me.Label7.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'CheckBox1
        '
        Me.CheckBox1.AutoSize = True
        Me.CheckBox1.Location = New System.Drawing.Point(21, 43)
        Me.CheckBox1.Name = "CheckBox1"
        Me.CheckBox1.Size = New System.Drawing.Size(98, 19)
        Me.CheckBox1.TabIndex = 6
        Me.CheckBox1.Text = "Volatile mode"
        Me.CheckBox1.UseVisualStyleBackColor = True
        '
        'ComboBox1
        '
        Me.ComboBox1.FormattingEnabled = True
        Me.ComboBox1.Items.AddRange(New Object() {"Settings file", "Registry"})
        Me.ComboBox1.Location = New System.Drawing.Point(169, 14)
        Me.ComboBox1.Name = "ComboBox1"
        Me.ComboBox1.Size = New System.Drawing.Size(556, 23)
        Me.ComboBox1.TabIndex = 5
        Me.ComboBox1.Text = "Settings file"
        '
        'PictureBox3
        '
        Me.PictureBox3.Image = Global.DISMTools.My.Resources.Resources.info_16px
        Me.PictureBox3.Location = New System.Drawing.Point(40, 67)
        Me.PictureBox3.Name = "PictureBox3"
        Me.PictureBox3.Size = New System.Drawing.Size(16, 16)
        Me.PictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.PictureBox3.TabIndex = 3
        Me.PictureBox3.TabStop = False
        '
        'LinkLabel1
        '
        Me.LinkLabel1.LinkArea = New System.Windows.Forms.LinkArea(97, 100)
        Me.LinkLabel1.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline
        Me.LinkLabel1.LinkColor = System.Drawing.Color.DodgerBlue
        Me.LinkLabel1.Location = New System.Drawing.Point(44, 76)
        Me.LinkLabel1.Name = "LinkLabel1"
        Me.LinkLabel1.Size = New System.Drawing.Size(681, 54)
        Me.LinkLabel1.TabIndex = 4
        Me.LinkLabel1.TabStop = True
        Me.LinkLabel1.Text = "The program will enable or disable certain features according to what the DISM ve" & _
    "rsion supports. How is it going to affect my usage of this program, and which fe" & _
    "atures will be disabled accordingly?"
        Me.LinkLabel1.UseCompatibleTextRendering = True
        '
        'PictureBox2
        '
        Me.PictureBox2.Image = Global.DISMTools.My.Resources.Resources.info_16px
        Me.PictureBox2.Location = New System.Drawing.Point(21, 75)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(16, 16)
        Me.PictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.PictureBox2.TabIndex = 3
        Me.PictureBox2.TabStop = False
        '
        'Button2
        '
        Me.Button2.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.Button2.Location = New System.Drawing.Point(468, 46)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(257, 23)
        Me.Button2.TabIndex = 2
        Me.Button2.Text = "View DISM component versions"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'Button1
        '
        Me.Button1.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.Button1.Location = New System.Drawing.Point(650, 16)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(75, 23)
        Me.Button1.TabIndex = 2
        Me.Button1.Text = "Browse..."
        Me.Button1.UseVisualStyleBackColor = True
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(188, 16)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(456, 23)
        Me.TextBox1.TabIndex = 1
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(90, 51)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(65, 15)
        Me.Label4.TabIndex = 0
        Me.Label4.Text = "<dismVer>"
        '
        'Label5
        '
        Me.Label5.AutoEllipsis = True
        Me.Label5.Location = New System.Drawing.Point(18, 14)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(145, 23)
        Me.Label5.TabIndex = 0
        Me.Label5.Text = "Save settings on:"
        Me.Label5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label6
        '
        Me.Label6.Location = New System.Drawing.Point(62, 68)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(663, 33)
        Me.Label6.TabIndex = 0
        Me.Label6.Text = "While in volatile mode, settings will be reset on program closure."
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(38, 51)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(48, 15)
        Me.Label3.TabIndex = 0
        Me.Label3.Text = "Version:"
        '
        'Label2
        '
        Me.Label2.AutoEllipsis = True
        Me.Label2.Location = New System.Drawing.Point(18, 16)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(164, 23)
        Me.Label2.TabIndex = 0
        Me.Label2.Text = "DISM executable path:"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'PrefReset
        '
        Me.PrefReset.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.PrefReset.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.PrefReset.Location = New System.Drawing.Point(12, 12)
        Me.PrefReset.Name = "PrefReset"
        Me.PrefReset.Size = New System.Drawing.Size(168, 23)
        Me.PrefReset.TabIndex = 2
        Me.PrefReset.Text = "Reset preferences"
        Me.PrefReset.UseVisualStyleBackColor = True
        '
        'LogSFD
        '
        Me.LogSFD.Filter = "All files|*.*"
        Me.LogSFD.Title = "Specify the location of the log file"
        '
        'btnPanel
        '
        Me.btnPanel.Controls.Add(Me.TableLayoutPanel1)
        Me.btnPanel.Controls.Add(Me.PrefReset)
        Me.btnPanel.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.btnPanel.Location = New System.Drawing.Point(0, 513)
        Me.btnPanel.Name = "btnPanel"
        Me.btnPanel.Size = New System.Drawing.Size(1008, 48)
        Me.btnPanel.TabIndex = 4
        '
        'OptionContainer
        '
        Me.OptionContainer.Controls.Add(Me.SplitContainer1)
        Me.OptionContainer.Dock = System.Windows.Forms.DockStyle.Fill
        Me.OptionContainer.Location = New System.Drawing.Point(0, 48)
        Me.OptionContainer.Name = "OptionContainer"
        Me.OptionContainer.Size = New System.Drawing.Size(1008, 465)
        Me.OptionContainer.TabIndex = 5
        '
        'SplitContainer1
        '
        Me.SplitContainer1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SplitContainer1.FixedPanel = System.Windows.Forms.FixedPanel.Panel1
        Me.SplitContainer1.Location = New System.Drawing.Point(0, 0)
        Me.SplitContainer1.Name = "SplitContainer1"
        '
        'SplitContainer1.Panel1
        '
        Me.SplitContainer1.Panel1.Controls.Add(Me.FlowLayoutPanel1)
        '
        'SplitContainer1.Panel2
        '
        Me.SplitContainer1.Panel2.Controls.Add(Me.ValueContainer)
        Me.SplitContainer1.Size = New System.Drawing.Size(1008, 465)
        Me.SplitContainer1.SplitterDistance = 256
        Me.SplitContainer1.TabIndex = 0
        '
        'FlowLayoutPanel1
        '
        Me.FlowLayoutPanel1.AutoScroll = True
        Me.FlowLayoutPanel1.Controls.Add(Me.ProgramSectionBtn)
        Me.FlowLayoutPanel1.Controls.Add(Me.PersonalizationSectionBtn)
        Me.FlowLayoutPanel1.Controls.Add(Me.LogSectionBtn)
        Me.FlowLayoutPanel1.Controls.Add(Me.ImgOpsSectionBtn)
        Me.FlowLayoutPanel1.Controls.Add(Me.ScDirSectionBtn)
        Me.FlowLayoutPanel1.Controls.Add(Me.OutputSectionBtn)
        Me.FlowLayoutPanel1.Controls.Add(Me.BgProcsSectionBtn)
        Me.FlowLayoutPanel1.Controls.Add(Me.ImgDetectSectionBtn)
        Me.FlowLayoutPanel1.Controls.Add(Me.AssocsSectionBtn)
        Me.FlowLayoutPanel1.Controls.Add(Me.StartupSectionBtn)
        Me.FlowLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.FlowLayoutPanel1.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FlowLayoutPanel1.Location = New System.Drawing.Point(0, 0)
        Me.FlowLayoutPanel1.Margin = New System.Windows.Forms.Padding(0)
        Me.FlowLayoutPanel1.Name = "FlowLayoutPanel1"
        Me.FlowLayoutPanel1.Size = New System.Drawing.Size(256, 465)
        Me.FlowLayoutPanel1.TabIndex = 0
        '
        'ProgramSectionBtn
        '
        Me.ProgramSectionBtn.Controls.Add(Me.PictureBox10)
        Me.ProgramSectionBtn.Controls.Add(Me.Label49)
        Me.ProgramSectionBtn.Location = New System.Drawing.Point(0, 0)
        Me.ProgramSectionBtn.Margin = New System.Windows.Forms.Padding(0)
        Me.ProgramSectionBtn.Name = "ProgramSectionBtn"
        Me.ProgramSectionBtn.Size = New System.Drawing.Size(256, 32)
        Me.ProgramSectionBtn.TabIndex = 0
        '
        'PictureBox10
        '
        Me.PictureBox10.Image = Global.DISMTools.My.Resources.Resources.options_program_light
        Me.PictureBox10.Location = New System.Drawing.Point(9, 6)
        Me.PictureBox10.Name = "PictureBox10"
        Me.PictureBox10.Size = New System.Drawing.Size(20, 20)
        Me.PictureBox10.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.PictureBox10.TabIndex = 1
        Me.PictureBox10.TabStop = False
        '
        'Label49
        '
        Me.Label49.AutoSize = True
        Me.Label49.Location = New System.Drawing.Point(37, 9)
        Me.Label49.Name = "Label49"
        Me.Label49.Size = New System.Drawing.Size(53, 15)
        Me.Label49.TabIndex = 0
        Me.Label49.Text = "Program"
        '
        'PersonalizationSectionBtn
        '
        Me.PersonalizationSectionBtn.Controls.Add(Me.PictureBox11)
        Me.PersonalizationSectionBtn.Controls.Add(Me.Label50)
        Me.PersonalizationSectionBtn.Location = New System.Drawing.Point(0, 32)
        Me.PersonalizationSectionBtn.Margin = New System.Windows.Forms.Padding(0)
        Me.PersonalizationSectionBtn.Name = "PersonalizationSectionBtn"
        Me.PersonalizationSectionBtn.Size = New System.Drawing.Size(256, 32)
        Me.PersonalizationSectionBtn.TabIndex = 1
        '
        'PictureBox11
        '
        Me.PictureBox11.Image = Global.DISMTools.My.Resources.Resources.options_personalization_light
        Me.PictureBox11.Location = New System.Drawing.Point(9, 6)
        Me.PictureBox11.Name = "PictureBox11"
        Me.PictureBox11.Size = New System.Drawing.Size(20, 20)
        Me.PictureBox11.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.PictureBox11.TabIndex = 2
        Me.PictureBox11.TabStop = False
        '
        'Label50
        '
        Me.Label50.AutoSize = True
        Me.Label50.Location = New System.Drawing.Point(37, 9)
        Me.Label50.Name = "Label50"
        Me.Label50.Size = New System.Drawing.Size(87, 15)
        Me.Label50.TabIndex = 0
        Me.Label50.Text = "Personalization"
        '
        'LogSectionBtn
        '
        Me.LogSectionBtn.Controls.Add(Me.PictureBox12)
        Me.LogSectionBtn.Controls.Add(Me.Label51)
        Me.LogSectionBtn.Location = New System.Drawing.Point(0, 64)
        Me.LogSectionBtn.Margin = New System.Windows.Forms.Padding(0)
        Me.LogSectionBtn.Name = "LogSectionBtn"
        Me.LogSectionBtn.Size = New System.Drawing.Size(256, 32)
        Me.LogSectionBtn.TabIndex = 2
        '
        'PictureBox12
        '
        Me.PictureBox12.Image = Global.DISMTools.My.Resources.Resources.options_logs_light
        Me.PictureBox12.Location = New System.Drawing.Point(9, 6)
        Me.PictureBox12.Name = "PictureBox12"
        Me.PictureBox12.Size = New System.Drawing.Size(20, 20)
        Me.PictureBox12.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.PictureBox12.TabIndex = 2
        Me.PictureBox12.TabStop = False
        '
        'Label51
        '
        Me.Label51.AutoSize = True
        Me.Label51.Location = New System.Drawing.Point(37, 9)
        Me.Label51.Name = "Label51"
        Me.Label51.Size = New System.Drawing.Size(32, 15)
        Me.Label51.TabIndex = 0
        Me.Label51.Text = "Logs"
        '
        'ImgOpsSectionBtn
        '
        Me.ImgOpsSectionBtn.Controls.Add(Me.PictureBox13)
        Me.ImgOpsSectionBtn.Controls.Add(Me.Label52)
        Me.ImgOpsSectionBtn.Location = New System.Drawing.Point(0, 96)
        Me.ImgOpsSectionBtn.Margin = New System.Windows.Forms.Padding(0)
        Me.ImgOpsSectionBtn.Name = "ImgOpsSectionBtn"
        Me.ImgOpsSectionBtn.Size = New System.Drawing.Size(256, 32)
        Me.ImgOpsSectionBtn.TabIndex = 3
        '
        'PictureBox13
        '
        Me.PictureBox13.Image = Global.DISMTools.My.Resources.Resources.image_light
        Me.PictureBox13.Location = New System.Drawing.Point(9, 6)
        Me.PictureBox13.Name = "PictureBox13"
        Me.PictureBox13.Size = New System.Drawing.Size(20, 20)
        Me.PictureBox13.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.PictureBox13.TabIndex = 2
        Me.PictureBox13.TabStop = False
        '
        'Label52
        '
        Me.Label52.AutoSize = True
        Me.Label52.Location = New System.Drawing.Point(37, 9)
        Me.Label52.Name = "Label52"
        Me.Label52.Size = New System.Drawing.Size(99, 15)
        Me.Label52.TabIndex = 0
        Me.Label52.Text = "Image operations"
        '
        'ScDirSectionBtn
        '
        Me.ScDirSectionBtn.Controls.Add(Me.PictureBox14)
        Me.ScDirSectionBtn.Controls.Add(Me.Label53)
        Me.ScDirSectionBtn.Location = New System.Drawing.Point(0, 128)
        Me.ScDirSectionBtn.Margin = New System.Windows.Forms.Padding(0)
        Me.ScDirSectionBtn.Name = "ScDirSectionBtn"
        Me.ScDirSectionBtn.Size = New System.Drawing.Size(256, 32)
        Me.ScDirSectionBtn.TabIndex = 4
        '
        'PictureBox14
        '
        Me.PictureBox14.Image = Global.DISMTools.My.Resources.Resources.options_scratch_light
        Me.PictureBox14.Location = New System.Drawing.Point(9, 6)
        Me.PictureBox14.Name = "PictureBox14"
        Me.PictureBox14.Size = New System.Drawing.Size(20, 20)
        Me.PictureBox14.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.PictureBox14.TabIndex = 2
        Me.PictureBox14.TabStop = False
        '
        'Label53
        '
        Me.Label53.AutoSize = True
        Me.Label53.Location = New System.Drawing.Point(37, 9)
        Me.Label53.Name = "Label53"
        Me.Label53.Size = New System.Drawing.Size(96, 15)
        Me.Label53.TabIndex = 0
        Me.Label53.Text = "Scratch directory"
        '
        'OutputSectionBtn
        '
        Me.OutputSectionBtn.Controls.Add(Me.PictureBox15)
        Me.OutputSectionBtn.Controls.Add(Me.Label54)
        Me.OutputSectionBtn.Location = New System.Drawing.Point(0, 160)
        Me.OutputSectionBtn.Margin = New System.Windows.Forms.Padding(0)
        Me.OutputSectionBtn.Name = "OutputSectionBtn"
        Me.OutputSectionBtn.Size = New System.Drawing.Size(256, 32)
        Me.OutputSectionBtn.TabIndex = 5
        '
        'PictureBox15
        '
        Me.PictureBox15.Image = Global.DISMTools.My.Resources.Resources.options_output_light
        Me.PictureBox15.Location = New System.Drawing.Point(9, 6)
        Me.PictureBox15.Name = "PictureBox15"
        Me.PictureBox15.Size = New System.Drawing.Size(20, 20)
        Me.PictureBox15.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.PictureBox15.TabIndex = 2
        Me.PictureBox15.TabStop = False
        '
        'Label54
        '
        Me.Label54.AutoSize = True
        Me.Label54.Location = New System.Drawing.Point(37, 9)
        Me.Label54.Name = "Label54"
        Me.Label54.Size = New System.Drawing.Size(92, 15)
        Me.Label54.TabIndex = 0
        Me.Label54.Text = "Program output"
        '
        'BgProcsSectionBtn
        '
        Me.BgProcsSectionBtn.Controls.Add(Me.PictureBox16)
        Me.BgProcsSectionBtn.Controls.Add(Me.Label55)
        Me.BgProcsSectionBtn.Location = New System.Drawing.Point(0, 192)
        Me.BgProcsSectionBtn.Margin = New System.Windows.Forms.Padding(0)
        Me.BgProcsSectionBtn.Name = "BgProcsSectionBtn"
        Me.BgProcsSectionBtn.Size = New System.Drawing.Size(256, 32)
        Me.BgProcsSectionBtn.TabIndex = 6
        '
        'PictureBox16
        '
        Me.PictureBox16.Image = Global.DISMTools.My.Resources.Resources.options_bgprocs_light
        Me.PictureBox16.Location = New System.Drawing.Point(9, 6)
        Me.PictureBox16.Name = "PictureBox16"
        Me.PictureBox16.Size = New System.Drawing.Size(20, 20)
        Me.PictureBox16.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.PictureBox16.TabIndex = 2
        Me.PictureBox16.TabStop = False
        '
        'Label55
        '
        Me.Label55.AutoSize = True
        Me.Label55.Location = New System.Drawing.Point(37, 9)
        Me.Label55.Name = "Label55"
        Me.Label55.Size = New System.Drawing.Size(125, 15)
        Me.Label55.TabIndex = 0
        Me.Label55.Text = "Background processes"
        '
        'ImgDetectSectionBtn
        '
        Me.ImgDetectSectionBtn.Controls.Add(Me.PictureBox17)
        Me.ImgDetectSectionBtn.Controls.Add(Me.Label56)
        Me.ImgDetectSectionBtn.Location = New System.Drawing.Point(0, 224)
        Me.ImgDetectSectionBtn.Margin = New System.Windows.Forms.Padding(0)
        Me.ImgDetectSectionBtn.Name = "ImgDetectSectionBtn"
        Me.ImgDetectSectionBtn.Size = New System.Drawing.Size(256, 32)
        Me.ImgDetectSectionBtn.TabIndex = 7
        '
        'PictureBox17
        '
        Me.PictureBox17.Image = Global.DISMTools.My.Resources.Resources.options_imgdetect_light
        Me.PictureBox17.Location = New System.Drawing.Point(9, 6)
        Me.PictureBox17.Name = "PictureBox17"
        Me.PictureBox17.Size = New System.Drawing.Size(20, 20)
        Me.PictureBox17.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.PictureBox17.TabIndex = 2
        Me.PictureBox17.TabStop = False
        '
        'Label56
        '
        Me.Label56.AutoSize = True
        Me.Label56.Location = New System.Drawing.Point(37, 9)
        Me.Label56.Name = "Label56"
        Me.Label56.Size = New System.Drawing.Size(93, 15)
        Me.Label56.TabIndex = 0
        Me.Label56.Text = "Image detection"
        '
        'AssocsSectionBtn
        '
        Me.AssocsSectionBtn.Controls.Add(Me.PictureBox18)
        Me.AssocsSectionBtn.Controls.Add(Me.Label57)
        Me.AssocsSectionBtn.Location = New System.Drawing.Point(0, 256)
        Me.AssocsSectionBtn.Margin = New System.Windows.Forms.Padding(0)
        Me.AssocsSectionBtn.Name = "AssocsSectionBtn"
        Me.AssocsSectionBtn.Size = New System.Drawing.Size(256, 32)
        Me.AssocsSectionBtn.TabIndex = 8
        '
        'PictureBox18
        '
        Me.PictureBox18.Location = New System.Drawing.Point(9, 6)
        Me.PictureBox18.Name = "PictureBox18"
        Me.PictureBox18.Size = New System.Drawing.Size(20, 20)
        Me.PictureBox18.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.PictureBox18.TabIndex = 2
        Me.PictureBox18.TabStop = False
        '
        'Label57
        '
        Me.Label57.AutoSize = True
        Me.Label57.Location = New System.Drawing.Point(37, 9)
        Me.Label57.Name = "Label57"
        Me.Label57.Size = New System.Drawing.Size(92, 15)
        Me.Label57.TabIndex = 0
        Me.Label57.Text = "File associations"
        '
        'StartupSectionBtn
        '
        Me.StartupSectionBtn.Controls.Add(Me.PictureBox19)
        Me.StartupSectionBtn.Controls.Add(Me.Label58)
        Me.StartupSectionBtn.Location = New System.Drawing.Point(0, 288)
        Me.StartupSectionBtn.Margin = New System.Windows.Forms.Padding(0)
        Me.StartupSectionBtn.Name = "StartupSectionBtn"
        Me.StartupSectionBtn.Size = New System.Drawing.Size(256, 32)
        Me.StartupSectionBtn.TabIndex = 9
        '
        'PictureBox19
        '
        Me.PictureBox19.Location = New System.Drawing.Point(9, 6)
        Me.PictureBox19.Name = "PictureBox19"
        Me.PictureBox19.Size = New System.Drawing.Size(20, 20)
        Me.PictureBox19.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.PictureBox19.TabIndex = 2
        Me.PictureBox19.TabStop = False
        '
        'Label58
        '
        Me.Label58.AutoSize = True
        Me.Label58.Location = New System.Drawing.Point(37, 9)
        Me.Label58.Name = "Label58"
        Me.Label58.Size = New System.Drawing.Size(88, 15)
        Me.Label58.TabIndex = 0
        Me.Label58.Text = "Startup options"
        '
        'ValueContainer
        '
        Me.ValueContainer.Controls.Add(Me.Options_Program)
        Me.ValueContainer.Controls.Add(Me.Options_Personalization)
        Me.ValueContainer.Controls.Add(Me.Options_Logs)
        Me.ValueContainer.Controls.Add(Me.Options_ImgOps)
        Me.ValueContainer.Controls.Add(Me.Options_Scratch)
        Me.ValueContainer.Controls.Add(Me.Options_Output)
        Me.ValueContainer.Controls.Add(Me.Options_BgProcs)
        Me.ValueContainer.Controls.Add(Me.Options_ImgDetection)
        Me.ValueContainer.Controls.Add(Me.Options_FileAssocs)
        Me.ValueContainer.Controls.Add(Me.Options_Startup)
        Me.ValueContainer.Dock = System.Windows.Forms.DockStyle.Fill
        Me.ValueContainer.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ValueContainer.Location = New System.Drawing.Point(0, 0)
        Me.ValueContainer.Name = "ValueContainer"
        Me.ValueContainer.Size = New System.Drawing.Size(748, 465)
        Me.ValueContainer.TabIndex = 4
        '
        'Options_Program
        '
        Me.Options_Program.Controls.Add(Me.FlowLayoutPanel2)
        Me.Options_Program.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Options_Program.Location = New System.Drawing.Point(0, 0)
        Me.Options_Program.Name = "Options_Program"
        Me.Options_Program.Size = New System.Drawing.Size(748, 465)
        Me.Options_Program.TabIndex = 0
        Me.Options_Program.Visible = False
        '
        'FlowLayoutPanel2
        '
        Me.FlowLayoutPanel2.AutoScroll = True
        Me.FlowLayoutPanel2.Controls.Add(Me.Panel14)
        Me.FlowLayoutPanel2.Controls.Add(Me.Panel15)
        Me.FlowLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.FlowLayoutPanel2.Location = New System.Drawing.Point(0, 0)
        Me.FlowLayoutPanel2.Name = "FlowLayoutPanel2"
        Me.FlowLayoutPanel2.Size = New System.Drawing.Size(748, 465)
        Me.FlowLayoutPanel2.TabIndex = 0
        '
        'Panel14
        '
        Me.Panel14.Controls.Add(Me.Label2)
        Me.Panel14.Controls.Add(Me.Label3)
        Me.Panel14.Controls.Add(Me.Label4)
        Me.Panel14.Controls.Add(Me.LinkLabel1)
        Me.Panel14.Controls.Add(Me.TextBox1)
        Me.Panel14.Controls.Add(Me.PictureBox2)
        Me.Panel14.Controls.Add(Me.Button1)
        Me.Panel14.Controls.Add(Me.Button2)
        Me.Panel14.Location = New System.Drawing.Point(0, 0)
        Me.Panel14.Margin = New System.Windows.Forms.Padding(0)
        Me.Panel14.Name = "Panel14"
        Me.Panel14.Size = New System.Drawing.Size(748, 138)
        Me.Panel14.TabIndex = 0
        '
        'Panel15
        '
        Me.Panel15.Controls.Add(Me.CheckBox1)
        Me.Panel15.Controls.Add(Me.Label5)
        Me.Panel15.Controls.Add(Me.ComboBox1)
        Me.Panel15.Controls.Add(Me.Label6)
        Me.Panel15.Controls.Add(Me.PictureBox3)
        Me.Panel15.Location = New System.Drawing.Point(0, 138)
        Me.Panel15.Margin = New System.Windows.Forms.Padding(0)
        Me.Panel15.Name = "Panel15"
        Me.Panel15.Size = New System.Drawing.Size(748, 118)
        Me.Panel15.TabIndex = 1
        '
        'Options_Personalization
        '
        Me.Options_Personalization.Controls.Add(Me.FlowLayoutPanel3)
        Me.Options_Personalization.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Options_Personalization.Location = New System.Drawing.Point(0, 0)
        Me.Options_Personalization.Name = "Options_Personalization"
        Me.Options_Personalization.Size = New System.Drawing.Size(748, 465)
        Me.Options_Personalization.TabIndex = 1
        Me.Options_Personalization.Visible = False
        '
        'FlowLayoutPanel3
        '
        Me.FlowLayoutPanel3.AutoScroll = True
        Me.FlowLayoutPanel3.Controls.Add(Me.Panel16)
        Me.FlowLayoutPanel3.Controls.Add(Me.Panel17)
        Me.FlowLayoutPanel3.Controls.Add(Me.Panel18)
        Me.FlowLayoutPanel3.Dock = System.Windows.Forms.DockStyle.Fill
        Me.FlowLayoutPanel3.Location = New System.Drawing.Point(0, 0)
        Me.FlowLayoutPanel3.Name = "FlowLayoutPanel3"
        Me.FlowLayoutPanel3.Size = New System.Drawing.Size(748, 465)
        Me.FlowLayoutPanel3.TabIndex = 0
        '
        'Panel16
        '
        Me.Panel16.Controls.Add(Me.Label7)
        Me.Panel16.Controls.Add(Me.Label8)
        Me.Panel16.Controls.Add(Me.ComboBox2)
        Me.Panel16.Controls.Add(Me.ComboBox3)
        Me.Panel16.Controls.Add(Me.CheckBox9)
        Me.Panel16.Location = New System.Drawing.Point(0, 0)
        Me.Panel16.Margin = New System.Windows.Forms.Padding(0)
        Me.Panel16.Name = "Panel16"
        Me.Panel16.Size = New System.Drawing.Size(728, 100)
        Me.Panel16.TabIndex = 0
        '
        'Panel17
        '
        Me.Panel17.Controls.Add(Me.Panel4)
        Me.Panel17.Controls.Add(Me.Label59)
        Me.Panel17.Controls.Add(Me.Toggle1)
        Me.Panel17.Controls.Add(Me.NumericUpDown1)
        Me.Panel17.Controls.Add(Me.ComboBox4)
        Me.Panel17.Controls.Add(Me.LogPreview)
        Me.Panel17.Controls.Add(Me.Label10)
        Me.Panel17.Controls.Add(Me.Label11)
        Me.Panel17.Location = New System.Drawing.Point(0, 100)
        Me.Panel17.Margin = New System.Windows.Forms.Padding(0)
        Me.Panel17.Name = "Panel17"
        Me.Panel17.Size = New System.Drawing.Size(728, 363)
        Me.Panel17.TabIndex = 1
        '
        'Label59
        '
        Me.Label59.AutoSize = True
        Me.Label59.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label59.Location = New System.Drawing.Point(18, 18)
        Me.Label59.Name = "Label59"
        Me.Label59.Size = New System.Drawing.Size(108, 15)
        Me.Label59.TabIndex = 0
        Me.Label59.Text = "Log customization"
        '
        'Panel18
        '
        Me.Panel18.Controls.Add(Me.CheckBox20)
        Me.Panel18.Controls.Add(Me.Label45)
        Me.Panel18.Controls.Add(Me.SecProgressStylePreview)
        Me.Panel18.Controls.Add(Me.RadioButton5)
        Me.Panel18.Controls.Add(Me.RadioButton6)
        Me.Panel18.Location = New System.Drawing.Point(0, 463)
        Me.Panel18.Margin = New System.Windows.Forms.Padding(0)
        Me.Panel18.Name = "Panel18"
        Me.Panel18.Size = New System.Drawing.Size(728, 127)
        Me.Panel18.TabIndex = 2
        '
        'Options_Logs
        '
        Me.Options_Logs.Controls.Add(Me.FlowLayoutPanel4)
        Me.Options_Logs.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Options_Logs.Location = New System.Drawing.Point(0, 0)
        Me.Options_Logs.Name = "Options_Logs"
        Me.Options_Logs.Size = New System.Drawing.Size(748, 465)
        Me.Options_Logs.TabIndex = 2
        Me.Options_Logs.Visible = False
        '
        'FlowLayoutPanel4
        '
        Me.FlowLayoutPanel4.AutoScroll = True
        Me.FlowLayoutPanel4.Controls.Add(Me.Panel5)
        Me.FlowLayoutPanel4.Controls.Add(Me.Panel19)
        Me.FlowLayoutPanel4.Dock = System.Windows.Forms.DockStyle.Fill
        Me.FlowLayoutPanel4.Location = New System.Drawing.Point(0, 0)
        Me.FlowLayoutPanel4.Name = "FlowLayoutPanel4"
        Me.FlowLayoutPanel4.Size = New System.Drawing.Size(748, 465)
        Me.FlowLayoutPanel4.TabIndex = 0
        '
        'Panel5
        '
        Me.Panel5.Controls.Add(Me.CheckBox10)
        Me.Panel5.Controls.Add(Me.PictureBox4)
        Me.Panel5.Controls.Add(Me.Label13)
        Me.Panel5.Controls.Add(Me.Label12)
        Me.Panel5.Controls.Add(Me.Button3)
        Me.Panel5.Controls.Add(Me.TextBox2)
        Me.Panel5.Location = New System.Drawing.Point(0, 0)
        Me.Panel5.Margin = New System.Windows.Forms.Padding(0)
        Me.Panel5.Name = "Panel5"
        Me.Panel5.Size = New System.Drawing.Size(748, 120)
        Me.Panel5.TabIndex = 0
        '
        'Panel19
        '
        Me.Panel19.Controls.Add(Me.Panel1)
        Me.Panel19.Controls.Add(Me.Label14)
        Me.Panel19.Controls.Add(Me.TrackBar1)
        Me.Panel19.Location = New System.Drawing.Point(0, 120)
        Me.Panel19.Margin = New System.Windows.Forms.Padding(0)
        Me.Panel19.Name = "Panel19"
        Me.Panel19.Size = New System.Drawing.Size(748, 134)
        Me.Panel19.TabIndex = 1
        '
        'Options_ImgOps
        '
        Me.Options_ImgOps.Controls.Add(Me.FlowLayoutPanel5)
        Me.Options_ImgOps.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Options_ImgOps.Location = New System.Drawing.Point(0, 0)
        Me.Options_ImgOps.Name = "Options_ImgOps"
        Me.Options_ImgOps.Size = New System.Drawing.Size(748, 465)
        Me.Options_ImgOps.TabIndex = 3
        Me.Options_ImgOps.Visible = False
        '
        'FlowLayoutPanel5
        '
        Me.FlowLayoutPanel5.AutoScroll = True
        Me.FlowLayoutPanel5.Controls.Add(Me.Panel6)
        Me.FlowLayoutPanel5.Controls.Add(Me.Panel7)
        Me.FlowLayoutPanel5.Dock = System.Windows.Forms.DockStyle.Fill
        Me.FlowLayoutPanel5.Location = New System.Drawing.Point(0, 0)
        Me.FlowLayoutPanel5.Name = "FlowLayoutPanel5"
        Me.FlowLayoutPanel5.Size = New System.Drawing.Size(748, 465)
        Me.FlowLayoutPanel5.TabIndex = 0
        '
        'Panel6
        '
        Me.Panel6.Controls.Add(Me.CheckBox2)
        Me.Panel6.Controls.Add(Me.Label19)
        Me.Panel6.Controls.Add(Me.CheckBox3)
        Me.Panel6.Controls.Add(Me.Label18)
        Me.Panel6.Location = New System.Drawing.Point(0, 0)
        Me.Panel6.Margin = New System.Windows.Forms.Padding(0)
        Me.Panel6.Name = "Panel6"
        Me.Panel6.Size = New System.Drawing.Size(748, 175)
        Me.Panel6.TabIndex = 0
        '
        'Panel7
        '
        Me.Panel7.Controls.Add(Me.Label9)
        Me.Panel7.Controls.Add(Me.CheckBox14)
        Me.Panel7.Controls.Add(Me.Label48)
        Me.Panel7.Controls.Add(Me.TableLayoutPanel2)
        Me.Panel7.Location = New System.Drawing.Point(0, 175)
        Me.Panel7.Margin = New System.Windows.Forms.Padding(0)
        Me.Panel7.Name = "Panel7"
        Me.Panel7.Size = New System.Drawing.Size(748, 172)
        Me.Panel7.TabIndex = 1
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.Location = New System.Drawing.Point(18, 18)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(150, 15)
        Me.Label9.TabIndex = 3
        Me.Label9.Text = "Saving image information"
        '
        'Options_Scratch
        '
        Me.Options_Scratch.Controls.Add(Me.FlowLayoutPanel6)
        Me.Options_Scratch.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Options_Scratch.Location = New System.Drawing.Point(0, 0)
        Me.Options_Scratch.Name = "Options_Scratch"
        Me.Options_Scratch.Size = New System.Drawing.Size(748, 465)
        Me.Options_Scratch.TabIndex = 4
        Me.Options_Scratch.Visible = False
        '
        'FlowLayoutPanel6
        '
        Me.FlowLayoutPanel6.AutoScroll = True
        Me.FlowLayoutPanel6.Controls.Add(Me.Panel8)
        Me.FlowLayoutPanel6.Dock = System.Windows.Forms.DockStyle.Fill
        Me.FlowLayoutPanel6.Location = New System.Drawing.Point(0, 0)
        Me.FlowLayoutPanel6.Name = "FlowLayoutPanel6"
        Me.FlowLayoutPanel6.Size = New System.Drawing.Size(748, 465)
        Me.FlowLayoutPanel6.TabIndex = 0
        '
        'Panel8
        '
        Me.Panel8.Controls.Add(Me.RadioButton4)
        Me.Panel8.Controls.Add(Me.CheckBox4)
        Me.Panel8.Controls.Add(Me.RadioButton3)
        Me.Panel8.Controls.Add(Me.PictureBox5)
        Me.Panel8.Controls.Add(Me.Label24)
        Me.Panel8.Controls.Add(Me.Label20)
        Me.Panel8.Controls.Add(Me.Label23)
        Me.Panel8.Controls.Add(Me.Label44)
        Me.Panel8.Controls.Add(Me.Label22)
        Me.Panel8.Controls.Add(Me.Label21)
        Me.Panel8.Controls.Add(Me.Button4)
        Me.Panel8.Controls.Add(Me.TextBox3)
        Me.Panel8.Location = New System.Drawing.Point(0, 0)
        Me.Panel8.Margin = New System.Windows.Forms.Padding(0)
        Me.Panel8.Name = "Panel8"
        Me.Panel8.Size = New System.Drawing.Size(748, 282)
        Me.Panel8.TabIndex = 0
        '
        'Options_Output
        '
        Me.Options_Output.Controls.Add(Me.FlowLayoutPanel7)
        Me.Options_Output.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Options_Output.Location = New System.Drawing.Point(0, 0)
        Me.Options_Output.Name = "Options_Output"
        Me.Options_Output.Size = New System.Drawing.Size(748, 465)
        Me.Options_Output.TabIndex = 5
        Me.Options_Output.Visible = False
        '
        'FlowLayoutPanel7
        '
        Me.FlowLayoutPanel7.AutoScroll = True
        Me.FlowLayoutPanel7.Controls.Add(Me.Panel9)
        Me.FlowLayoutPanel7.Controls.Add(Me.Panel10)
        Me.FlowLayoutPanel7.Dock = System.Windows.Forms.DockStyle.Fill
        Me.FlowLayoutPanel7.Location = New System.Drawing.Point(0, 0)
        Me.FlowLayoutPanel7.Name = "FlowLayoutPanel7"
        Me.FlowLayoutPanel7.Size = New System.Drawing.Size(748, 465)
        Me.FlowLayoutPanel7.TabIndex = 0
        '
        'Panel9
        '
        Me.Panel9.Controls.Add(Me.CheckBox5)
        Me.Panel9.Location = New System.Drawing.Point(0, 0)
        Me.Panel9.Margin = New System.Windows.Forms.Padding(0)
        Me.Panel9.Name = "Panel9"
        Me.Panel9.Size = New System.Drawing.Size(748, 51)
        Me.Panel9.TabIndex = 0
        '
        'Panel10
        '
        Me.Panel10.Controls.Add(Me.Label27)
        Me.Panel10.Controls.Add(Me.Label25)
        Me.Panel10.Controls.Add(Me.TextBox4)
        Me.Panel10.Controls.Add(Me.PictureBox6)
        Me.Panel10.Controls.Add(Me.ComboBox5)
        Me.Panel10.Controls.Add(Me.Label26)
        Me.Panel10.Location = New System.Drawing.Point(0, 51)
        Me.Panel10.Margin = New System.Windows.Forms.Padding(0)
        Me.Panel10.Name = "Panel10"
        Me.Panel10.Size = New System.Drawing.Size(748, 400)
        Me.Panel10.TabIndex = 1
        '
        'Options_BgProcs
        '
        Me.Options_BgProcs.Controls.Add(Me.FlowLayoutPanel8)
        Me.Options_BgProcs.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Options_BgProcs.Location = New System.Drawing.Point(0, 0)
        Me.Options_BgProcs.Name = "Options_BgProcs"
        Me.Options_BgProcs.Size = New System.Drawing.Size(748, 465)
        Me.Options_BgProcs.TabIndex = 6
        Me.Options_BgProcs.Visible = False
        '
        'FlowLayoutPanel8
        '
        Me.FlowLayoutPanel8.AutoScroll = True
        Me.FlowLayoutPanel8.Controls.Add(Me.Panel11)
        Me.FlowLayoutPanel8.Dock = System.Windows.Forms.DockStyle.Fill
        Me.FlowLayoutPanel8.Location = New System.Drawing.Point(0, 0)
        Me.FlowLayoutPanel8.Name = "FlowLayoutPanel8"
        Me.FlowLayoutPanel8.Size = New System.Drawing.Size(748, 465)
        Me.FlowLayoutPanel8.TabIndex = 0
        '
        'Panel11
        '
        Me.Panel11.Controls.Add(Me.Panel12)
        Me.Panel11.Controls.Add(Me.Button10)
        Me.Panel11.Controls.Add(Me.CheckBox6)
        Me.Panel11.Controls.Add(Me.LinkLabel2)
        Me.Panel11.Controls.Add(Me.PictureBox7)
        Me.Panel11.Controls.Add(Me.Label29)
        Me.Panel11.Location = New System.Drawing.Point(0, 0)
        Me.Panel11.Margin = New System.Windows.Forms.Padding(0)
        Me.Panel11.Name = "Panel11"
        Me.Panel11.Size = New System.Drawing.Size(748, 397)
        Me.Panel11.TabIndex = 0
        '
        'Panel12
        '
        Me.Panel12.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel12.Controls.Add(Me.ComboBox6)
        Me.Panel12.Controls.Add(Me.Label28)
        Me.Panel12.Location = New System.Drawing.Point(45, 50)
        Me.Panel12.Name = "Panel12"
        Me.Panel12.Size = New System.Drawing.Size(656, 63)
        Me.Panel12.TabIndex = 8
        '
        'Options_ImgDetection
        '
        Me.Options_ImgDetection.Controls.Add(Me.FlowLayoutPanel9)
        Me.Options_ImgDetection.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Options_ImgDetection.Location = New System.Drawing.Point(0, 0)
        Me.Options_ImgDetection.Name = "Options_ImgDetection"
        Me.Options_ImgDetection.Size = New System.Drawing.Size(748, 465)
        Me.Options_ImgDetection.TabIndex = 7
        Me.Options_ImgDetection.Visible = False
        '
        'FlowLayoutPanel9
        '
        Me.FlowLayoutPanel9.AutoScroll = True
        Me.FlowLayoutPanel9.Controls.Add(Me.Panel13)
        Me.FlowLayoutPanel9.Dock = System.Windows.Forms.DockStyle.Fill
        Me.FlowLayoutPanel9.Location = New System.Drawing.Point(0, 0)
        Me.FlowLayoutPanel9.Name = "FlowLayoutPanel9"
        Me.FlowLayoutPanel9.Size = New System.Drawing.Size(748, 465)
        Me.FlowLayoutPanel9.TabIndex = 0
        '
        'Panel13
        '
        Me.Panel13.Controls.Add(Me.Label39)
        Me.Panel13.Controls.Add(Me.Button8)
        Me.Panel13.Controls.Add(Me.Label35)
        Me.Panel13.Controls.Add(Me.Label38)
        Me.Panel13.Controls.Add(Me.CheckBox8)
        Me.Panel13.Controls.Add(Me.Label37)
        Me.Panel13.Controls.Add(Me.Label36)
        Me.Panel13.Location = New System.Drawing.Point(0, 0)
        Me.Panel13.Margin = New System.Windows.Forms.Padding(0)
        Me.Panel13.Name = "Panel13"
        Me.Panel13.Size = New System.Drawing.Size(748, 271)
        Me.Panel13.TabIndex = 0
        '
        'Options_FileAssocs
        '
        Me.Options_FileAssocs.Controls.Add(Me.FlowLayoutPanel10)
        Me.Options_FileAssocs.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Options_FileAssocs.Location = New System.Drawing.Point(0, 0)
        Me.Options_FileAssocs.Name = "Options_FileAssocs"
        Me.Options_FileAssocs.Size = New System.Drawing.Size(748, 465)
        Me.Options_FileAssocs.TabIndex = 8
        Me.Options_FileAssocs.Visible = False
        '
        'FlowLayoutPanel10
        '
        Me.FlowLayoutPanel10.AutoScroll = True
        Me.FlowLayoutPanel10.Controls.Add(Me.Panel2)
        Me.FlowLayoutPanel10.Controls.Add(Me.Panel3)
        Me.FlowLayoutPanel10.Dock = System.Windows.Forms.DockStyle.Fill
        Me.FlowLayoutPanel10.Location = New System.Drawing.Point(0, 0)
        Me.FlowLayoutPanel10.Name = "FlowLayoutPanel10"
        Me.FlowLayoutPanel10.Size = New System.Drawing.Size(748, 465)
        Me.FlowLayoutPanel10.TabIndex = 0
        '
        'Options_Startup
        '
        Me.Options_Startup.Controls.Add(Me.FlowLayoutPanel11)
        Me.Options_Startup.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Options_Startup.Location = New System.Drawing.Point(0, 0)
        Me.Options_Startup.Name = "Options_Startup"
        Me.Options_Startup.Size = New System.Drawing.Size(748, 465)
        Me.Options_Startup.TabIndex = 9
        Me.Options_Startup.Visible = False
        '
        'FlowLayoutPanel11
        '
        Me.FlowLayoutPanel11.AutoScroll = True
        Me.FlowLayoutPanel11.Controls.Add(Me.Panel20)
        Me.FlowLayoutPanel11.Dock = System.Windows.Forms.DockStyle.Fill
        Me.FlowLayoutPanel11.Location = New System.Drawing.Point(0, 0)
        Me.FlowLayoutPanel11.Name = "FlowLayoutPanel11"
        Me.FlowLayoutPanel11.Size = New System.Drawing.Size(748, 465)
        Me.FlowLayoutPanel11.TabIndex = 0
        '
        'Panel20
        '
        Me.Panel20.Controls.Add(Me.CheckBox13)
        Me.Panel20.Controls.Add(Me.Label43)
        Me.Panel20.Controls.Add(Me.CheckBox12)
        Me.Panel20.Location = New System.Drawing.Point(0, 0)
        Me.Panel20.Margin = New System.Windows.Forms.Padding(0)
        Me.Panel20.Name = "Panel20"
        Me.Panel20.Size = New System.Drawing.Size(748, 130)
        Me.Panel20.TabIndex = 0
        '
        'Options
        '
        Me.AcceptButton = Me.OK_Button
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.CancelButton = Me.Cancel_Button
        Me.ClientSize = New System.Drawing.Size(1008, 561)
        Me.Controls.Add(Me.OptionContainer)
        Me.Controls.Add(Me.Win10Title)
        Me.Controls.Add(Me.btnPanel)
        Me.Font = New System.Drawing.Font("Tahoma", 8.25!)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "Options"
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "Options"
        Me.TableLayoutPanel1.ResumeLayout(False)
        Me.Win10Title.ResumeLayout(False)
        Me.Win10Title.PerformLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel3.ResumeLayout(False)
        Me.Panel3.PerformLayout()
        CType(Me.PictureBox8, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel2.ResumeLayout(False)
        Me.GroupBox5.ResumeLayout(False)
        Me.GroupBox5.PerformLayout()
        CType(Me.PictureBox7, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox6, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox5, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TableLayoutPanel2.ResumeLayout(False)
        Me.TableLayoutPanel2.PerformLayout()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        CType(Me.TrackBar1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.SecProgressStylePreview, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel4.ResumeLayout(False)
        Me.Panel4.PerformLayout()
        CType(Me.PictureBox9, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.btnPanel.ResumeLayout(False)
        Me.OptionContainer.ResumeLayout(False)
        Me.SplitContainer1.Panel1.ResumeLayout(False)
        Me.SplitContainer1.Panel2.ResumeLayout(False)
        CType(Me.SplitContainer1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.SplitContainer1.ResumeLayout(False)
        Me.FlowLayoutPanel1.ResumeLayout(False)
        Me.ProgramSectionBtn.ResumeLayout(False)
        Me.ProgramSectionBtn.PerformLayout()
        CType(Me.PictureBox10, System.ComponentModel.ISupportInitialize).EndInit()
        Me.PersonalizationSectionBtn.ResumeLayout(False)
        Me.PersonalizationSectionBtn.PerformLayout()
        CType(Me.PictureBox11, System.ComponentModel.ISupportInitialize).EndInit()
        Me.LogSectionBtn.ResumeLayout(False)
        Me.LogSectionBtn.PerformLayout()
        CType(Me.PictureBox12, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ImgOpsSectionBtn.ResumeLayout(False)
        Me.ImgOpsSectionBtn.PerformLayout()
        CType(Me.PictureBox13, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ScDirSectionBtn.ResumeLayout(False)
        Me.ScDirSectionBtn.PerformLayout()
        CType(Me.PictureBox14, System.ComponentModel.ISupportInitialize).EndInit()
        Me.OutputSectionBtn.ResumeLayout(False)
        Me.OutputSectionBtn.PerformLayout()
        CType(Me.PictureBox15, System.ComponentModel.ISupportInitialize).EndInit()
        Me.BgProcsSectionBtn.ResumeLayout(False)
        Me.BgProcsSectionBtn.PerformLayout()
        CType(Me.PictureBox16, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ImgDetectSectionBtn.ResumeLayout(False)
        Me.ImgDetectSectionBtn.PerformLayout()
        CType(Me.PictureBox17, System.ComponentModel.ISupportInitialize).EndInit()
        Me.AssocsSectionBtn.ResumeLayout(False)
        Me.AssocsSectionBtn.PerformLayout()
        CType(Me.PictureBox18, System.ComponentModel.ISupportInitialize).EndInit()
        Me.StartupSectionBtn.ResumeLayout(False)
        Me.StartupSectionBtn.PerformLayout()
        CType(Me.PictureBox19, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ValueContainer.ResumeLayout(False)
        Me.Options_Program.ResumeLayout(False)
        Me.FlowLayoutPanel2.ResumeLayout(False)
        Me.Panel14.ResumeLayout(False)
        Me.Panel14.PerformLayout()
        Me.Panel15.ResumeLayout(False)
        Me.Panel15.PerformLayout()
        Me.Options_Personalization.ResumeLayout(False)
        Me.FlowLayoutPanel3.ResumeLayout(False)
        Me.Panel16.ResumeLayout(False)
        Me.Panel16.PerformLayout()
        Me.Panel17.ResumeLayout(False)
        Me.Panel17.PerformLayout()
        Me.Panel18.ResumeLayout(False)
        Me.Panel18.PerformLayout()
        Me.Options_Logs.ResumeLayout(False)
        Me.FlowLayoutPanel4.ResumeLayout(False)
        Me.Panel5.ResumeLayout(False)
        Me.Panel5.PerformLayout()
        Me.Panel19.ResumeLayout(False)
        Me.Panel19.PerformLayout()
        Me.Options_ImgOps.ResumeLayout(False)
        Me.FlowLayoutPanel5.ResumeLayout(False)
        Me.Panel6.ResumeLayout(False)
        Me.Panel6.PerformLayout()
        Me.Panel7.ResumeLayout(False)
        Me.Panel7.PerformLayout()
        Me.Options_Scratch.ResumeLayout(False)
        Me.FlowLayoutPanel6.ResumeLayout(False)
        Me.Panel8.ResumeLayout(False)
        Me.Panel8.PerformLayout()
        Me.Options_Output.ResumeLayout(False)
        Me.FlowLayoutPanel7.ResumeLayout(False)
        Me.Panel9.ResumeLayout(False)
        Me.Panel9.PerformLayout()
        Me.Panel10.ResumeLayout(False)
        Me.Panel10.PerformLayout()
        Me.Options_BgProcs.ResumeLayout(False)
        Me.FlowLayoutPanel8.ResumeLayout(False)
        Me.Panel11.ResumeLayout(False)
        Me.Panel11.PerformLayout()
        Me.Panel12.ResumeLayout(False)
        Me.Options_ImgDetection.ResumeLayout(False)
        Me.FlowLayoutPanel9.ResumeLayout(False)
        Me.Panel13.ResumeLayout(False)
        Me.Panel13.PerformLayout()
        Me.Options_FileAssocs.ResumeLayout(False)
        Me.FlowLayoutPanel10.ResumeLayout(False)
        Me.Options_Startup.ResumeLayout(False)
        Me.FlowLayoutPanel11.ResumeLayout(False)
        Me.Panel20.ResumeLayout(False)
        Me.Panel20.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents TableLayoutPanel1 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents OK_Button As System.Windows.Forms.Button
    Friend WithEvents Cancel_Button As System.Windows.Forms.Button
    Friend WithEvents Win10Title As System.Windows.Forms.Panel
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents DismOFD As System.Windows.Forms.OpenFileDialog
    Friend WithEvents ScratchFBD As System.Windows.Forms.FolderBrowserDialog
    Friend WithEvents CheckBox1 As System.Windows.Forms.CheckBox
    Friend WithEvents ComboBox1 As System.Windows.Forms.ComboBox
    Friend WithEvents PictureBox3 As System.Windows.Forms.PictureBox
    Friend WithEvents LinkLabel1 As System.Windows.Forms.LinkLabel
    Friend WithEvents PictureBox2 As System.Windows.Forms.PictureBox
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents ComboBox4 As System.Windows.Forms.ComboBox
    Friend WithEvents ComboBox3 As System.Windows.Forms.ComboBox
    Friend WithEvents ComboBox2 As System.Windows.Forms.ComboBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents LogPreview As System.Windows.Forms.TextBox
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents TrackBar1 As System.Windows.Forms.TrackBar
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents PictureBox4 As System.Windows.Forms.PictureBox
    Friend WithEvents Button3 As System.Windows.Forms.Button
    Friend WithEvents TextBox2 As System.Windows.Forms.TextBox
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents CheckBox3 As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox2 As System.Windows.Forms.CheckBox
    Friend WithEvents Button4 As System.Windows.Forms.Button
    Friend WithEvents TextBox3 As System.Windows.Forms.TextBox
    Friend WithEvents Label21 As System.Windows.Forms.Label
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents CheckBox4 As System.Windows.Forms.CheckBox
    Friend WithEvents Label27 As System.Windows.Forms.Label
    Friend WithEvents PictureBox6 As System.Windows.Forms.PictureBox
    Friend WithEvents TextBox4 As System.Windows.Forms.TextBox
    Friend WithEvents ComboBox5 As System.Windows.Forms.ComboBox
    Friend WithEvents Label26 As System.Windows.Forms.Label
    Friend WithEvents Label25 As System.Windows.Forms.Label
    Friend WithEvents CheckBox5 As System.Windows.Forms.CheckBox
    Friend WithEvents PrefReset As System.Windows.Forms.Button
    Friend WithEvents LogSFD As System.Windows.Forms.SaveFileDialog
    Friend WithEvents Label24 As System.Windows.Forms.Label
    Friend WithEvents PictureBox5 As System.Windows.Forms.PictureBox
    Friend WithEvents Label23 As System.Windows.Forms.Label
    Friend WithEvents Label22 As System.Windows.Forms.Label
    Friend WithEvents Toggle1 As System.Windows.Forms.CheckBox
    Friend WithEvents NumericUpDown1 As System.Windows.Forms.NumericUpDown
    Friend WithEvents PictureBox7 As System.Windows.Forms.PictureBox
    Friend WithEvents ComboBox6 As System.Windows.Forms.ComboBox
    Friend WithEvents Label28 As System.Windows.Forms.Label
    Friend WithEvents CheckBox6 As System.Windows.Forms.CheckBox
    Friend WithEvents LinkLabel2 As System.Windows.Forms.LinkLabel
    Friend WithEvents Label29 As System.Windows.Forms.Label
    Friend WithEvents CheckBox8 As System.Windows.Forms.CheckBox
    Friend WithEvents Label35 As System.Windows.Forms.Label
    Friend WithEvents CheckBox9 As System.Windows.Forms.CheckBox
    Friend WithEvents Label39 As System.Windows.Forms.Label
    Friend WithEvents Button8 As System.Windows.Forms.Button
    Friend WithEvents Label38 As System.Windows.Forms.Label
    Friend WithEvents Label37 As System.Windows.Forms.Label
    Friend WithEvents Label36 As System.Windows.Forms.Label
    Friend WithEvents CheckBox10 As System.Windows.Forms.CheckBox
    Friend WithEvents GroupBox5 As System.Windows.Forms.GroupBox
    Friend WithEvents CheckBox11 As System.Windows.Forms.CheckBox
    Friend WithEvents Button9 As System.Windows.Forms.Button
    Friend WithEvents Label41 As System.Windows.Forms.Label
    Friend WithEvents Label42 As System.Windows.Forms.Label
    Friend WithEvents Label40 As System.Windows.Forms.Label
    Friend WithEvents Button10 As System.Windows.Forms.Button
    Friend WithEvents CheckBox12 As System.Windows.Forms.CheckBox
    Friend WithEvents Label43 As System.Windows.Forms.Label
    Friend WithEvents CheckBox13 As System.Windows.Forms.CheckBox
    Friend WithEvents RadioButton4 As System.Windows.Forms.RadioButton
    Friend WithEvents RadioButton3 As System.Windows.Forms.RadioButton
    Friend WithEvents Label44 As System.Windows.Forms.Label
    Friend WithEvents SecProgressStylePreview As System.Windows.Forms.PictureBox
    Friend WithEvents RadioButton6 As System.Windows.Forms.RadioButton
    Friend WithEvents RadioButton5 As System.Windows.Forms.RadioButton
    Friend WithEvents Label45 As System.Windows.Forms.Label
    Friend WithEvents Label46 As System.Windows.Forms.Label
    Friend WithEvents PictureBox8 As System.Windows.Forms.PictureBox
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents Panel3 As System.Windows.Forms.Panel
    Friend WithEvents Panel4 As System.Windows.Forms.Panel
    Friend WithEvents Label47 As System.Windows.Forms.Label
    Friend WithEvents PictureBox9 As System.Windows.Forms.PictureBox
    Friend WithEvents CheckBox14 As System.Windows.Forms.CheckBox
    Friend WithEvents Label48 As System.Windows.Forms.Label
    Friend WithEvents TableLayoutPanel2 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents CheckBox15 As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox19 As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox18 As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox16 As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox17 As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox20 As System.Windows.Forms.CheckBox
    Friend WithEvents btnPanel As System.Windows.Forms.Panel
    Friend WithEvents OptionContainer As System.Windows.Forms.Panel
    Friend WithEvents SplitContainer1 As System.Windows.Forms.SplitContainer
    Friend WithEvents FlowLayoutPanel1 As System.Windows.Forms.FlowLayoutPanel
    Friend WithEvents ProgramSectionBtn As System.Windows.Forms.Panel
    Friend WithEvents Label49 As System.Windows.Forms.Label
    Friend WithEvents PersonalizationSectionBtn As System.Windows.Forms.Panel
    Friend WithEvents Label50 As System.Windows.Forms.Label
    Friend WithEvents LogSectionBtn As System.Windows.Forms.Panel
    Friend WithEvents Label51 As System.Windows.Forms.Label
    Friend WithEvents ImgOpsSectionBtn As System.Windows.Forms.Panel
    Friend WithEvents Label52 As System.Windows.Forms.Label
    Friend WithEvents ScDirSectionBtn As System.Windows.Forms.Panel
    Friend WithEvents Label53 As System.Windows.Forms.Label
    Friend WithEvents OutputSectionBtn As System.Windows.Forms.Panel
    Friend WithEvents Label54 As System.Windows.Forms.Label
    Friend WithEvents BgProcsSectionBtn As System.Windows.Forms.Panel
    Friend WithEvents Label55 As System.Windows.Forms.Label
    Friend WithEvents ImgDetectSectionBtn As System.Windows.Forms.Panel
    Friend WithEvents Label56 As System.Windows.Forms.Label
    Friend WithEvents AssocsSectionBtn As System.Windows.Forms.Panel
    Friend WithEvents Label57 As System.Windows.Forms.Label
    Friend WithEvents StartupSectionBtn As System.Windows.Forms.Panel
    Friend WithEvents Label58 As System.Windows.Forms.Label
    Friend WithEvents ValueContainer As System.Windows.Forms.Panel
    Friend WithEvents Options_Personalization As System.Windows.Forms.Panel
    Friend WithEvents FlowLayoutPanel3 As System.Windows.Forms.FlowLayoutPanel
    Friend WithEvents Options_Program As System.Windows.Forms.Panel
    Friend WithEvents FlowLayoutPanel2 As System.Windows.Forms.FlowLayoutPanel
    Friend WithEvents Panel14 As System.Windows.Forms.Panel
    Friend WithEvents Panel15 As System.Windows.Forms.Panel
    Friend WithEvents Options_Logs As System.Windows.Forms.Panel
    Friend WithEvents Options_ImgOps As System.Windows.Forms.Panel
    Friend WithEvents Options_Scratch As System.Windows.Forms.Panel
    Friend WithEvents Options_Output As System.Windows.Forms.Panel
    Friend WithEvents Options_BgProcs As System.Windows.Forms.Panel
    Friend WithEvents Options_ImgDetection As System.Windows.Forms.Panel
    Friend WithEvents Options_FileAssocs As System.Windows.Forms.Panel
    Friend WithEvents Options_Startup As System.Windows.Forms.Panel
    Friend WithEvents Panel16 As System.Windows.Forms.Panel
    Friend WithEvents Panel17 As System.Windows.Forms.Panel
    Friend WithEvents Label59 As System.Windows.Forms.Label
    Friend WithEvents PictureBox10 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox11 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox12 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox13 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox14 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox15 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox16 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox17 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox18 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox19 As System.Windows.Forms.PictureBox
    Friend WithEvents Panel18 As System.Windows.Forms.Panel
    Friend WithEvents FlowLayoutPanel4 As System.Windows.Forms.FlowLayoutPanel
    Friend WithEvents Panel5 As System.Windows.Forms.Panel
    Friend WithEvents Panel19 As System.Windows.Forms.Panel
    Friend WithEvents FlowLayoutPanel5 As System.Windows.Forms.FlowLayoutPanel
    Friend WithEvents Panel6 As System.Windows.Forms.Panel
    Friend WithEvents Panel7 As System.Windows.Forms.Panel
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents FlowLayoutPanel6 As System.Windows.Forms.FlowLayoutPanel
    Friend WithEvents Panel8 As System.Windows.Forms.Panel
    Friend WithEvents FlowLayoutPanel7 As System.Windows.Forms.FlowLayoutPanel
    Friend WithEvents Panel9 As System.Windows.Forms.Panel
    Friend WithEvents Panel10 As System.Windows.Forms.Panel
    Friend WithEvents FlowLayoutPanel8 As System.Windows.Forms.FlowLayoutPanel
    Friend WithEvents Panel11 As System.Windows.Forms.Panel
    Friend WithEvents Panel12 As System.Windows.Forms.Panel
    Friend WithEvents FlowLayoutPanel9 As System.Windows.Forms.FlowLayoutPanel
    Friend WithEvents Panel13 As System.Windows.Forms.Panel
    Friend WithEvents FlowLayoutPanel10 As System.Windows.Forms.FlowLayoutPanel
    Friend WithEvents FlowLayoutPanel11 As System.Windows.Forms.FlowLayoutPanel
    Friend WithEvents Panel20 As System.Windows.Forms.Panel

End Class
