﻿Public Class PkgErrorText

End Class