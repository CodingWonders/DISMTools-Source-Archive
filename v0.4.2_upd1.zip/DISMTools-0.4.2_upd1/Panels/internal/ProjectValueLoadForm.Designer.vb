﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class ProjectValueLoadForm
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.RichTextBox1 = New System.Windows.Forms.RichTextBox()
        Me.Exit_Button = New System.Windows.Forms.Button()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label48 = New System.Windows.Forms.Label()
        Me.Label47 = New System.Windows.Forms.Label()
        Me.Label49 = New System.Windows.Forms.Label()
        Me.Label46 = New System.Windows.Forms.Label()
        Me.Label45 = New System.Windows.Forms.Label()
        Me.Label44 = New System.Windows.Forms.Label()
        Me.Label43 = New System.Windows.Forms.Label()
        Me.Label42 = New System.Windows.Forms.Label()
        Me.Label41 = New System.Windows.Forms.Label()
        Me.Label40 = New System.Windows.Forms.Label()
        Me.Label39 = New System.Windows.Forms.Label()
        Me.Label38 = New System.Windows.Forms.Label()
        Me.Label37 = New System.Windows.Forms.Label()
        Me.Label36 = New System.Windows.Forms.Label()
        Me.Label35 = New System.Windows.Forms.Label()
        Me.Label34 = New System.Windows.Forms.Label()
        Me.Label33 = New System.Windows.Forms.Label()
        Me.Label32 = New System.Windows.Forms.Label()
        Me.Label31 = New System.Windows.Forms.Label()
        Me.Label30 = New System.Windows.Forms.Label()
        Me.Label29 = New System.Windows.Forms.Label()
        Me.Label28 = New System.Windows.Forms.Label()
        Me.Label27 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.RichTextBox24 = New System.Windows.Forms.RichTextBox()
        Me.RichTextBox25 = New System.Windows.Forms.RichTextBox()
        Me.EpochRTB3 = New System.Windows.Forms.RichTextBox()
        Me.RichTextBox23 = New System.Windows.Forms.RichTextBox()
        Me.EpochRTB2 = New System.Windows.Forms.RichTextBox()
        Me.RichTextBox22 = New System.Windows.Forms.RichTextBox()
        Me.RichTextBox21 = New System.Windows.Forms.RichTextBox()
        Me.RichTextBox20 = New System.Windows.Forms.RichTextBox()
        Me.RichTextBox19 = New System.Windows.Forms.RichTextBox()
        Me.RichTextBox18 = New System.Windows.Forms.RichTextBox()
        Me.RichTextBox17 = New System.Windows.Forms.RichTextBox()
        Me.RichTextBox16 = New System.Windows.Forms.RichTextBox()
        Me.RichTextBox15 = New System.Windows.Forms.RichTextBox()
        Me.RichTextBox14 = New System.Windows.Forms.RichTextBox()
        Me.RichTextBox13 = New System.Windows.Forms.RichTextBox()
        Me.RichTextBox12 = New System.Windows.Forms.RichTextBox()
        Me.RichTextBox11 = New System.Windows.Forms.RichTextBox()
        Me.RichTextBox10 = New System.Windows.Forms.RichTextBox()
        Me.RichTextBox9 = New System.Windows.Forms.RichTextBox()
        Me.RichTextBox8 = New System.Windows.Forms.RichTextBox()
        Me.RichTextBox7 = New System.Windows.Forms.RichTextBox()
        Me.RichTextBox6 = New System.Windows.Forms.RichTextBox()
        Me.RichTextBox5 = New System.Windows.Forms.RichTextBox()
        Me.EpochRTB1 = New System.Windows.Forms.RichTextBox()
        Me.RichTextBox4 = New System.Windows.Forms.RichTextBox()
        Me.RichTextBox3 = New System.Windows.Forms.RichTextBox()
        Me.RichTextBox2 = New System.Windows.Forms.RichTextBox()
        Me.Label50 = New System.Windows.Forms.Label()
        Me.RichTextBox26 = New System.Windows.Forms.RichTextBox()
        Me.Continue_Button = New System.Windows.Forms.Button()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(13, 13)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(81, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Old project file:"
        '
        'RichTextBox1
        '
        Me.RichTextBox1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.RichTextBox1.Font = New System.Drawing.Font("Courier New", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RichTextBox1.Location = New System.Drawing.Point(16, 30)
        Me.RichTextBox1.Name = "RichTextBox1"
        Me.RichTextBox1.ReadOnly = True
        Me.RichTextBox1.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.ForcedVertical
        Me.RichTextBox1.Size = New System.Drawing.Size(377, 460)
        Me.RichTextBox1.TabIndex = 1
        Me.RichTextBox1.Text = ""
        '
        'Exit_Button
        '
        Me.Exit_Button.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Exit_Button.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.Exit_Button.Location = New System.Drawing.Point(1177, 954)
        Me.Exit_Button.Name = "Exit_Button"
        Me.Exit_Button.Size = New System.Drawing.Size(75, 23)
        Me.Exit_Button.TabIndex = 2
        Me.Exit_Button.Text = "Exit"
        Me.Exit_Button.UseVisualStyleBackColor = True
        '
        'GroupBox1
        '
        Me.GroupBox1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GroupBox1.Controls.Add(Me.Label25)
        Me.GroupBox1.Controls.Add(Me.Label26)
        Me.GroupBox1.Controls.Add(Me.Label24)
        Me.GroupBox1.Controls.Add(Me.Label23)
        Me.GroupBox1.Controls.Add(Me.Label22)
        Me.GroupBox1.Controls.Add(Me.Label21)
        Me.GroupBox1.Controls.Add(Me.Label20)
        Me.GroupBox1.Controls.Add(Me.Label19)
        Me.GroupBox1.Controls.Add(Me.Label18)
        Me.GroupBox1.Controls.Add(Me.Label17)
        Me.GroupBox1.Controls.Add(Me.Label16)
        Me.GroupBox1.Controls.Add(Me.Label15)
        Me.GroupBox1.Controls.Add(Me.Label14)
        Me.GroupBox1.Controls.Add(Me.Label13)
        Me.GroupBox1.Controls.Add(Me.Label12)
        Me.GroupBox1.Controls.Add(Me.Label11)
        Me.GroupBox1.Controls.Add(Me.Label10)
        Me.GroupBox1.Controls.Add(Me.Label9)
        Me.GroupBox1.Controls.Add(Me.Label8)
        Me.GroupBox1.Controls.Add(Me.Label7)
        Me.GroupBox1.Controls.Add(Me.Label6)
        Me.GroupBox1.Controls.Add(Me.Label5)
        Me.GroupBox1.Controls.Add(Me.Label4)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.Label48)
        Me.GroupBox1.Controls.Add(Me.Label47)
        Me.GroupBox1.Controls.Add(Me.Label49)
        Me.GroupBox1.Controls.Add(Me.Label46)
        Me.GroupBox1.Controls.Add(Me.Label45)
        Me.GroupBox1.Controls.Add(Me.Label44)
        Me.GroupBox1.Controls.Add(Me.Label43)
        Me.GroupBox1.Controls.Add(Me.Label42)
        Me.GroupBox1.Controls.Add(Me.Label41)
        Me.GroupBox1.Controls.Add(Me.Label40)
        Me.GroupBox1.Controls.Add(Me.Label39)
        Me.GroupBox1.Controls.Add(Me.Label38)
        Me.GroupBox1.Controls.Add(Me.Label37)
        Me.GroupBox1.Controls.Add(Me.Label36)
        Me.GroupBox1.Controls.Add(Me.Label35)
        Me.GroupBox1.Controls.Add(Me.Label34)
        Me.GroupBox1.Controls.Add(Me.Label33)
        Me.GroupBox1.Controls.Add(Me.Label32)
        Me.GroupBox1.Controls.Add(Me.Label31)
        Me.GroupBox1.Controls.Add(Me.Label30)
        Me.GroupBox1.Controls.Add(Me.Label29)
        Me.GroupBox1.Controls.Add(Me.Label28)
        Me.GroupBox1.Controls.Add(Me.Label27)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.RichTextBox24)
        Me.GroupBox1.Controls.Add(Me.RichTextBox25)
        Me.GroupBox1.Controls.Add(Me.EpochRTB3)
        Me.GroupBox1.Controls.Add(Me.RichTextBox23)
        Me.GroupBox1.Controls.Add(Me.EpochRTB2)
        Me.GroupBox1.Controls.Add(Me.RichTextBox22)
        Me.GroupBox1.Controls.Add(Me.RichTextBox21)
        Me.GroupBox1.Controls.Add(Me.RichTextBox20)
        Me.GroupBox1.Controls.Add(Me.RichTextBox19)
        Me.GroupBox1.Controls.Add(Me.RichTextBox18)
        Me.GroupBox1.Controls.Add(Me.RichTextBox17)
        Me.GroupBox1.Controls.Add(Me.RichTextBox16)
        Me.GroupBox1.Controls.Add(Me.RichTextBox15)
        Me.GroupBox1.Controls.Add(Me.RichTextBox14)
        Me.GroupBox1.Controls.Add(Me.RichTextBox13)
        Me.GroupBox1.Controls.Add(Me.RichTextBox12)
        Me.GroupBox1.Controls.Add(Me.RichTextBox11)
        Me.GroupBox1.Controls.Add(Me.RichTextBox10)
        Me.GroupBox1.Controls.Add(Me.RichTextBox9)
        Me.GroupBox1.Controls.Add(Me.RichTextBox8)
        Me.GroupBox1.Controls.Add(Me.RichTextBox7)
        Me.GroupBox1.Controls.Add(Me.RichTextBox6)
        Me.GroupBox1.Controls.Add(Me.RichTextBox5)
        Me.GroupBox1.Controls.Add(Me.EpochRTB1)
        Me.GroupBox1.Controls.Add(Me.RichTextBox4)
        Me.GroupBox1.Controls.Add(Me.RichTextBox3)
        Me.GroupBox1.Controls.Add(Me.RichTextBox2)
        Me.GroupBox1.Location = New System.Drawing.Point(400, 13)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(852, 935)
        Me.GroupBox1.TabIndex = 3
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Independent values"
        '
        'Label25
        '
        Me.Label25.AutoSize = True
        Me.Label25.Location = New System.Drawing.Point(24, 712)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(64, 13)
        Me.Label25.TabIndex = 1
        Me.Label25.Text = "ImageLang:"
        '
        'Label26
        '
        Me.Label26.AutoSize = True
        Me.Label26.Location = New System.Drawing.Point(24, 903)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(92, 13)
        Me.Label26.TabIndex = 1
        Me.Label26.Text = "ImageReadWrite:"
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.Location = New System.Drawing.Point(24, 683)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(102, 13)
        Me.Label24.TabIndex = 1
        Me.Label24.Text = "ImageEpochModify:"
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.Location = New System.Drawing.Point(24, 654)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(103, 13)
        Me.Label23.TabIndex = 1
        Me.Label23.Text = "ImageEpochCreate:"
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.Location = New System.Drawing.Point(24, 625)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(86, 13)
        Me.Label22.TabIndex = 1
        Me.Label22.Text = "ImageFileCount:"
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Location = New System.Drawing.Point(24, 596)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(83, 13)
        Me.Label21.TabIndex = 1
        Me.Label21.Text = "ImageDirCount:"
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Location = New System.Drawing.Point(24, 567)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(81, 13)
        Me.Label20.TabIndex = 1
        Me.Label20.Text = "ImageSysRoot:"
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Location = New System.Drawing.Point(24, 538)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(71, 13)
        Me.Label19.TabIndex = 1
        Me.Label19.Text = "ImagePSuite:"
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Location = New System.Drawing.Point(24, 509)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(71, 13)
        Me.Label18.TabIndex = 1
        Me.Label18.Text = "ImagePType:"
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Location = New System.Drawing.Point(24, 480)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(73, 13)
        Me.Label17.TabIndex = 1
        Me.Label17.Text = "ImageEdition:"
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Location = New System.Drawing.Point(24, 451)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(78, 13)
        Me.Label16.TabIndex = 1
        Me.Label16.Text = "ImageSPLevel:"
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(24, 422)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(75, 13)
        Me.Label15.TabIndex = 1
        Me.Label15.Text = "ImageSPBuild:"
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(24, 393)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(56, 13)
        Me.Label14.TabIndex = 1
        Me.Label14.Text = "ImageHal:"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(24, 364)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(63, 13)
        Me.Label13.TabIndex = 1
        Me.Label13.Text = "ImageArch:"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(24, 335)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(85, 13)
        Me.Label12.TabIndex = 1
        Me.Label12.Text = "ImageWIMBoot:"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(24, 306)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(94, 13)
        Me.Label11.TabIndex = 1
        Me.Label11.Text = "ImageDescription:"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(24, 277)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(68, 13)
        Me.Label10.TabIndex = 1
        Me.Label10.Text = "ImageName:"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(24, 248)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(76, 13)
        Me.Label9.TabIndex = 1
        Me.Label9.Text = "ImageVersion:"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(24, 219)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(95, 13)
        Me.Label8.TabIndex = 1
        Me.Label8.Text = "ImageMountPoint:"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(24, 190)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(69, 13)
        Me.Label7.TabIndex = 1
        Me.Label7.Text = "ImageIndex:"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(24, 161)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(57, 13)
        Me.Label6.TabIndex = 1
        Me.Label6.Text = "ImageFile:"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(24, 132)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(103, 13)
        Me.Label5.TabIndex = 1
        Me.Label5.Text = "EpochCreationTime:"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(24, 103)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(51, 13)
        Me.Label4.TabIndex = 1
        Me.Label4.Text = "Location:"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(24, 74)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(38, 13)
        Me.Label3.TabIndex = 1
        Me.Label3.Text = "Name:"
        '
        'Label48
        '
        Me.Label48.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label48.Font = New System.Drawing.Font("Courier New", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label48.Location = New System.Drawing.Point(457, 711)
        Me.Label48.Name = "Label48"
        Me.Label48.Size = New System.Drawing.Size(389, 56)
        Me.Label48.TabIndex = 0
        Me.Label48.Text = "Image file languages"
        '
        'Label47
        '
        Me.Label47.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label47.Font = New System.Drawing.Font("Courier New", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label47.Location = New System.Drawing.Point(457, 653)
        Me.Label47.Name = "Label47"
        Me.Label47.Size = New System.Drawing.Size(389, 56)
        Me.Label47.TabIndex = 0
        Me.Label47.Text = "Image file creation and modification dates stored in Unix time (GMT+0)"
        '
        'Label49
        '
        Me.Label49.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label49.Font = New System.Drawing.Font("Courier New", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label49.Location = New System.Drawing.Point(457, 902)
        Me.Label49.Name = "Label49"
        Me.Label49.Size = New System.Drawing.Size(389, 27)
        Me.Label49.TabIndex = 0
        Me.Label49.Text = "Verify if image has read-write permissions"
        '
        'Label46
        '
        Me.Label46.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label46.Font = New System.Drawing.Font("Courier New", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label46.Location = New System.Drawing.Point(457, 624)
        Me.Label46.Name = "Label46"
        Me.Label46.Size = New System.Drawing.Size(389, 27)
        Me.Label46.TabIndex = 0
        Me.Label46.Text = "Image file count"
        '
        'Label45
        '
        Me.Label45.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label45.Font = New System.Drawing.Font("Courier New", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label45.Location = New System.Drawing.Point(457, 595)
        Me.Label45.Name = "Label45"
        Me.Label45.Size = New System.Drawing.Size(389, 27)
        Me.Label45.TabIndex = 0
        Me.Label45.Text = "Image directory count"
        '
        'Label44
        '
        Me.Label44.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label44.Font = New System.Drawing.Font("Courier New", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label44.Location = New System.Drawing.Point(457, 566)
        Me.Label44.Name = "Label44"
        Me.Label44.Size = New System.Drawing.Size(389, 27)
        Me.Label44.TabIndex = 0
        Me.Label44.Text = "Image system root directory (\WINDOWS)"
        '
        'Label43
        '
        Me.Label43.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label43.Font = New System.Drawing.Font("Courier New", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label43.Location = New System.Drawing.Point(457, 537)
        Me.Label43.Name = "Label43"
        Me.Label43.Size = New System.Drawing.Size(389, 27)
        Me.Label43.TabIndex = 0
        Me.Label43.Text = "Image product suite"
        '
        'Label42
        '
        Me.Label42.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label42.Font = New System.Drawing.Font("Courier New", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label42.Location = New System.Drawing.Point(457, 508)
        Me.Label42.Name = "Label42"
        Me.Label42.Size = New System.Drawing.Size(389, 27)
        Me.Label42.TabIndex = 0
        Me.Label42.Text = "Image product type"
        '
        'Label41
        '
        Me.Label41.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label41.Font = New System.Drawing.Font("Courier New", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label41.Location = New System.Drawing.Point(457, 479)
        Me.Label41.Name = "Label41"
        Me.Label41.Size = New System.Drawing.Size(389, 27)
        Me.Label41.TabIndex = 0
        Me.Label41.Text = "Image edition"
        '
        'Label40
        '
        Me.Label40.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label40.Font = New System.Drawing.Font("Courier New", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label40.Location = New System.Drawing.Point(457, 450)
        Me.Label40.Name = "Label40"
        Me.Label40.Size = New System.Drawing.Size(389, 27)
        Me.Label40.TabIndex = 0
        Me.Label40.Text = "Image Service Pack level (SP1, SP2, SP3...)"
        '
        'Label39
        '
        Me.Label39.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label39.Font = New System.Drawing.Font("Courier New", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label39.Location = New System.Drawing.Point(457, 421)
        Me.Label39.Name = "Label39"
        Me.Label39.Size = New System.Drawing.Size(389, 27)
        Me.Label39.TabIndex = 0
        Me.Label39.Text = "Image Service Pack build"
        '
        'Label38
        '
        Me.Label38.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label38.Font = New System.Drawing.Font("Courier New", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label38.Location = New System.Drawing.Point(457, 392)
        Me.Label38.Name = "Label38"
        Me.Label38.Size = New System.Drawing.Size(389, 27)
        Me.Label38.TabIndex = 0
        Me.Label38.Text = "Image HAL (Hardware Abstraction Layer, hal.dll)"
        '
        'Label37
        '
        Me.Label37.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label37.Font = New System.Drawing.Font("Courier New", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label37.Location = New System.Drawing.Point(457, 363)
        Me.Label37.Name = "Label37"
        Me.Label37.Size = New System.Drawing.Size(389, 27)
        Me.Label37.TabIndex = 0
        Me.Label37.Text = "Mounted image architecture (x86, amd64...)"
        '
        'Label36
        '
        Me.Label36.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label36.Font = New System.Drawing.Font("Courier New", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label36.Location = New System.Drawing.Point(457, 334)
        Me.Label36.Name = "Label36"
        Me.Label36.Size = New System.Drawing.Size(389, 27)
        Me.Label36.TabIndex = 0
        Me.Label36.Text = "Verify if image supports WIMBoot (Win8.1 only)"
        '
        'Label35
        '
        Me.Label35.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label35.Font = New System.Drawing.Font("Courier New", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label35.Location = New System.Drawing.Point(457, 305)
        Me.Label35.Name = "Label35"
        Me.Label35.Size = New System.Drawing.Size(379, 27)
        Me.Label35.TabIndex = 0
        Me.Label35.Text = "Mounted image friendly description"
        '
        'Label34
        '
        Me.Label34.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label34.Font = New System.Drawing.Font("Courier New", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label34.Location = New System.Drawing.Point(457, 276)
        Me.Label34.Name = "Label34"
        Me.Label34.Size = New System.Drawing.Size(379, 27)
        Me.Label34.TabIndex = 0
        Me.Label34.Text = "Mounted image friendly name"
        '
        'Label33
        '
        Me.Label33.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label33.Font = New System.Drawing.Font("Courier New", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label33.Location = New System.Drawing.Point(457, 247)
        Me.Label33.Name = "Label33"
        Me.Label33.Size = New System.Drawing.Size(379, 27)
        Me.Label33.TabIndex = 0
        Me.Label33.Text = "Image version (grab version from ntoskrnl.exe)"
        '
        'Label32
        '
        Me.Label32.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label32.Font = New System.Drawing.Font("Courier New", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label32.Location = New System.Drawing.Point(457, 218)
        Me.Label32.Name = "Label32"
        Me.Label32.Size = New System.Drawing.Size(379, 27)
        Me.Label32.TabIndex = 0
        Me.Label32.Text = "Image file mount point"
        '
        'Label31
        '
        Me.Label31.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label31.Font = New System.Drawing.Font("Courier New", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label31.Location = New System.Drawing.Point(457, 189)
        Me.Label31.Name = "Label31"
        Me.Label31.Size = New System.Drawing.Size(379, 27)
        Me.Label31.TabIndex = 0
        Me.Label31.Text = "Mounted image file index"
        '
        'Label30
        '
        Me.Label30.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label30.Font = New System.Drawing.Font("Courier New", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label30.Location = New System.Drawing.Point(457, 160)
        Me.Label30.Name = "Label30"
        Me.Label30.Size = New System.Drawing.Size(379, 27)
        Me.Label30.TabIndex = 0
        Me.Label30.Text = "Mounted image file name"
        '
        'Label29
        '
        Me.Label29.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label29.Font = New System.Drawing.Font("Courier New", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label29.Location = New System.Drawing.Point(457, 131)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(379, 27)
        Me.Label29.TabIndex = 0
        Me.Label29.Text = "Project creation time in Unix time (GMT+0)"
        '
        'Label28
        '
        Me.Label28.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label28.Font = New System.Drawing.Font("Courier New", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label28.Location = New System.Drawing.Point(457, 102)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(379, 27)
        Me.Label28.TabIndex = 0
        Me.Label28.Text = "Project location"
        '
        'Label27
        '
        Me.Label27.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label27.Font = New System.Drawing.Font("Courier New", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label27.Location = New System.Drawing.Point(457, 73)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(379, 27)
        Me.Label27.TabIndex = 0
        Me.Label27.Text = "Project name"
        '
        'Label2
        '
        Me.Label2.Font = New System.Drawing.Font("Courier New", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(24, 32)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(802, 34)
        Me.Label2.TabIndex = 0
        Me.Label2.Text = "Get independent values by piping ""findstr"" to the ""type"" command. Also pass the """ & _
    "/b"" switch only to show matches on the beginning."
        '
        'RichTextBox24
        '
        Me.RichTextBox24.Font = New System.Drawing.Font("Courier New", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RichTextBox24.Location = New System.Drawing.Point(94, 708)
        Me.RichTextBox24.Name = "RichTextBox24"
        Me.RichTextBox24.ReadOnly = True
        Me.RichTextBox24.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.ForcedVertical
        Me.RichTextBox24.Size = New System.Drawing.Size(357, 185)
        Me.RichTextBox24.TabIndex = 1
        Me.RichTextBox24.Text = ""
        '
        'RichTextBox25
        '
        Me.RichTextBox25.Font = New System.Drawing.Font("Courier New", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RichTextBox25.Location = New System.Drawing.Point(122, 899)
        Me.RichTextBox25.Name = "RichTextBox25"
        Me.RichTextBox25.ReadOnly = True
        Me.RichTextBox25.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.None
        Me.RichTextBox25.Size = New System.Drawing.Size(329, 23)
        Me.RichTextBox25.TabIndex = 1
        Me.RichTextBox25.Text = ""
        '
        'EpochRTB3
        '
        Me.EpochRTB3.Font = New System.Drawing.Font("Courier New", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.EpochRTB3.Location = New System.Drawing.Point(264, 679)
        Me.EpochRTB3.Name = "EpochRTB3"
        Me.EpochRTB3.ReadOnly = True
        Me.EpochRTB3.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.None
        Me.EpochRTB3.Size = New System.Drawing.Size(187, 23)
        Me.EpochRTB3.TabIndex = 1
        Me.EpochRTB3.Text = ""
        '
        'RichTextBox23
        '
        Me.RichTextBox23.Font = New System.Drawing.Font("Courier New", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RichTextBox23.Location = New System.Drawing.Point(133, 679)
        Me.RichTextBox23.Name = "RichTextBox23"
        Me.RichTextBox23.ReadOnly = True
        Me.RichTextBox23.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.None
        Me.RichTextBox23.Size = New System.Drawing.Size(125, 23)
        Me.RichTextBox23.TabIndex = 1
        Me.RichTextBox23.Text = ""
        '
        'EpochRTB2
        '
        Me.EpochRTB2.Font = New System.Drawing.Font("Courier New", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.EpochRTB2.Location = New System.Drawing.Point(264, 650)
        Me.EpochRTB2.Name = "EpochRTB2"
        Me.EpochRTB2.ReadOnly = True
        Me.EpochRTB2.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.None
        Me.EpochRTB2.Size = New System.Drawing.Size(187, 23)
        Me.EpochRTB2.TabIndex = 1
        Me.EpochRTB2.Text = ""
        '
        'RichTextBox22
        '
        Me.RichTextBox22.Font = New System.Drawing.Font("Courier New", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RichTextBox22.Location = New System.Drawing.Point(133, 650)
        Me.RichTextBox22.Name = "RichTextBox22"
        Me.RichTextBox22.ReadOnly = True
        Me.RichTextBox22.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.None
        Me.RichTextBox22.Size = New System.Drawing.Size(125, 23)
        Me.RichTextBox22.TabIndex = 1
        Me.RichTextBox22.Text = ""
        '
        'RichTextBox21
        '
        Me.RichTextBox21.Font = New System.Drawing.Font("Courier New", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RichTextBox21.Location = New System.Drawing.Point(116, 621)
        Me.RichTextBox21.Name = "RichTextBox21"
        Me.RichTextBox21.ReadOnly = True
        Me.RichTextBox21.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.None
        Me.RichTextBox21.Size = New System.Drawing.Size(335, 23)
        Me.RichTextBox21.TabIndex = 1
        Me.RichTextBox21.Text = ""
        '
        'RichTextBox20
        '
        Me.RichTextBox20.Font = New System.Drawing.Font("Courier New", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RichTextBox20.Location = New System.Drawing.Point(113, 592)
        Me.RichTextBox20.Name = "RichTextBox20"
        Me.RichTextBox20.ReadOnly = True
        Me.RichTextBox20.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.None
        Me.RichTextBox20.Size = New System.Drawing.Size(338, 23)
        Me.RichTextBox20.TabIndex = 1
        Me.RichTextBox20.Text = ""
        '
        'RichTextBox19
        '
        Me.RichTextBox19.Font = New System.Drawing.Font("Courier New", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RichTextBox19.Location = New System.Drawing.Point(111, 563)
        Me.RichTextBox19.Name = "RichTextBox19"
        Me.RichTextBox19.ReadOnly = True
        Me.RichTextBox19.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.None
        Me.RichTextBox19.Size = New System.Drawing.Size(340, 23)
        Me.RichTextBox19.TabIndex = 1
        Me.RichTextBox19.Text = ""
        '
        'RichTextBox18
        '
        Me.RichTextBox18.Font = New System.Drawing.Font("Courier New", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RichTextBox18.Location = New System.Drawing.Point(101, 534)
        Me.RichTextBox18.Name = "RichTextBox18"
        Me.RichTextBox18.ReadOnly = True
        Me.RichTextBox18.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.None
        Me.RichTextBox18.Size = New System.Drawing.Size(350, 23)
        Me.RichTextBox18.TabIndex = 1
        Me.RichTextBox18.Text = ""
        '
        'RichTextBox17
        '
        Me.RichTextBox17.Font = New System.Drawing.Font("Courier New", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RichTextBox17.Location = New System.Drawing.Point(101, 505)
        Me.RichTextBox17.Name = "RichTextBox17"
        Me.RichTextBox17.ReadOnly = True
        Me.RichTextBox17.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.None
        Me.RichTextBox17.Size = New System.Drawing.Size(350, 23)
        Me.RichTextBox17.TabIndex = 1
        Me.RichTextBox17.Text = ""
        '
        'RichTextBox16
        '
        Me.RichTextBox16.Font = New System.Drawing.Font("Courier New", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RichTextBox16.Location = New System.Drawing.Point(103, 476)
        Me.RichTextBox16.Name = "RichTextBox16"
        Me.RichTextBox16.ReadOnly = True
        Me.RichTextBox16.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.None
        Me.RichTextBox16.Size = New System.Drawing.Size(348, 23)
        Me.RichTextBox16.TabIndex = 1
        Me.RichTextBox16.Text = ""
        '
        'RichTextBox15
        '
        Me.RichTextBox15.Font = New System.Drawing.Font("Courier New", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RichTextBox15.Location = New System.Drawing.Point(108, 447)
        Me.RichTextBox15.Name = "RichTextBox15"
        Me.RichTextBox15.ReadOnly = True
        Me.RichTextBox15.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.None
        Me.RichTextBox15.Size = New System.Drawing.Size(343, 23)
        Me.RichTextBox15.TabIndex = 1
        Me.RichTextBox15.Text = ""
        '
        'RichTextBox14
        '
        Me.RichTextBox14.Font = New System.Drawing.Font("Courier New", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RichTextBox14.Location = New System.Drawing.Point(105, 418)
        Me.RichTextBox14.Name = "RichTextBox14"
        Me.RichTextBox14.ReadOnly = True
        Me.RichTextBox14.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.None
        Me.RichTextBox14.Size = New System.Drawing.Size(346, 23)
        Me.RichTextBox14.TabIndex = 1
        Me.RichTextBox14.Text = ""
        '
        'RichTextBox13
        '
        Me.RichTextBox13.Font = New System.Drawing.Font("Courier New", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RichTextBox13.Location = New System.Drawing.Point(86, 389)
        Me.RichTextBox13.Name = "RichTextBox13"
        Me.RichTextBox13.ReadOnly = True
        Me.RichTextBox13.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.None
        Me.RichTextBox13.Size = New System.Drawing.Size(365, 23)
        Me.RichTextBox13.TabIndex = 1
        Me.RichTextBox13.Text = ""
        '
        'RichTextBox12
        '
        Me.RichTextBox12.Font = New System.Drawing.Font("Courier New", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RichTextBox12.Location = New System.Drawing.Point(93, 360)
        Me.RichTextBox12.Name = "RichTextBox12"
        Me.RichTextBox12.ReadOnly = True
        Me.RichTextBox12.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.None
        Me.RichTextBox12.Size = New System.Drawing.Size(358, 23)
        Me.RichTextBox12.TabIndex = 1
        Me.RichTextBox12.Text = ""
        '
        'RichTextBox11
        '
        Me.RichTextBox11.Font = New System.Drawing.Font("Courier New", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RichTextBox11.Location = New System.Drawing.Point(115, 331)
        Me.RichTextBox11.Name = "RichTextBox11"
        Me.RichTextBox11.ReadOnly = True
        Me.RichTextBox11.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.None
        Me.RichTextBox11.Size = New System.Drawing.Size(336, 23)
        Me.RichTextBox11.TabIndex = 1
        Me.RichTextBox11.Text = ""
        '
        'RichTextBox10
        '
        Me.RichTextBox10.Font = New System.Drawing.Font("Courier New", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RichTextBox10.Location = New System.Drawing.Point(124, 302)
        Me.RichTextBox10.Name = "RichTextBox10"
        Me.RichTextBox10.ReadOnly = True
        Me.RichTextBox10.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.None
        Me.RichTextBox10.Size = New System.Drawing.Size(327, 23)
        Me.RichTextBox10.TabIndex = 1
        Me.RichTextBox10.Text = ""
        '
        'RichTextBox9
        '
        Me.RichTextBox9.Font = New System.Drawing.Font("Courier New", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RichTextBox9.Location = New System.Drawing.Point(98, 273)
        Me.RichTextBox9.Name = "RichTextBox9"
        Me.RichTextBox9.ReadOnly = True
        Me.RichTextBox9.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.None
        Me.RichTextBox9.Size = New System.Drawing.Size(353, 23)
        Me.RichTextBox9.TabIndex = 1
        Me.RichTextBox9.Text = ""
        '
        'RichTextBox8
        '
        Me.RichTextBox8.Font = New System.Drawing.Font("Courier New", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RichTextBox8.Location = New System.Drawing.Point(106, 244)
        Me.RichTextBox8.Name = "RichTextBox8"
        Me.RichTextBox8.ReadOnly = True
        Me.RichTextBox8.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.None
        Me.RichTextBox8.Size = New System.Drawing.Size(345, 23)
        Me.RichTextBox8.TabIndex = 1
        Me.RichTextBox8.Text = ""
        '
        'RichTextBox7
        '
        Me.RichTextBox7.Font = New System.Drawing.Font("Courier New", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RichTextBox7.Location = New System.Drawing.Point(125, 215)
        Me.RichTextBox7.Name = "RichTextBox7"
        Me.RichTextBox7.ReadOnly = True
        Me.RichTextBox7.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.None
        Me.RichTextBox7.Size = New System.Drawing.Size(326, 23)
        Me.RichTextBox7.TabIndex = 1
        Me.RichTextBox7.Text = ""
        '
        'RichTextBox6
        '
        Me.RichTextBox6.Font = New System.Drawing.Font("Courier New", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RichTextBox6.Location = New System.Drawing.Point(99, 186)
        Me.RichTextBox6.Name = "RichTextBox6"
        Me.RichTextBox6.ReadOnly = True
        Me.RichTextBox6.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.None
        Me.RichTextBox6.Size = New System.Drawing.Size(352, 23)
        Me.RichTextBox6.TabIndex = 1
        Me.RichTextBox6.Text = ""
        '
        'RichTextBox5
        '
        Me.RichTextBox5.Font = New System.Drawing.Font("Courier New", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RichTextBox5.Location = New System.Drawing.Point(87, 157)
        Me.RichTextBox5.Name = "RichTextBox5"
        Me.RichTextBox5.ReadOnly = True
        Me.RichTextBox5.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.None
        Me.RichTextBox5.Size = New System.Drawing.Size(364, 23)
        Me.RichTextBox5.TabIndex = 1
        Me.RichTextBox5.Text = ""
        '
        'EpochRTB1
        '
        Me.EpochRTB1.Font = New System.Drawing.Font("Courier New", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.EpochRTB1.Location = New System.Drawing.Point(264, 128)
        Me.EpochRTB1.Name = "EpochRTB1"
        Me.EpochRTB1.ReadOnly = True
        Me.EpochRTB1.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.None
        Me.EpochRTB1.Size = New System.Drawing.Size(187, 23)
        Me.EpochRTB1.TabIndex = 1
        Me.EpochRTB1.Text = ""
        '
        'RichTextBox4
        '
        Me.RichTextBox4.Font = New System.Drawing.Font("Courier New", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RichTextBox4.Location = New System.Drawing.Point(133, 128)
        Me.RichTextBox4.Name = "RichTextBox4"
        Me.RichTextBox4.ReadOnly = True
        Me.RichTextBox4.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.None
        Me.RichTextBox4.Size = New System.Drawing.Size(125, 23)
        Me.RichTextBox4.TabIndex = 1
        Me.RichTextBox4.Text = ""
        '
        'RichTextBox3
        '
        Me.RichTextBox3.Font = New System.Drawing.Font("Courier New", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RichTextBox3.Location = New System.Drawing.Point(81, 99)
        Me.RichTextBox3.Name = "RichTextBox3"
        Me.RichTextBox3.ReadOnly = True
        Me.RichTextBox3.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.None
        Me.RichTextBox3.Size = New System.Drawing.Size(370, 23)
        Me.RichTextBox3.TabIndex = 1
        Me.RichTextBox3.Text = ""
        '
        'RichTextBox2
        '
        Me.RichTextBox2.Font = New System.Drawing.Font("Courier New", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RichTextBox2.Location = New System.Drawing.Point(71, 70)
        Me.RichTextBox2.Name = "RichTextBox2"
        Me.RichTextBox2.ReadOnly = True
        Me.RichTextBox2.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.None
        Me.RichTextBox2.Size = New System.Drawing.Size(380, 23)
        Me.RichTextBox2.TabIndex = 1
        Me.RichTextBox2.Text = ""
        '
        'Label50
        '
        Me.Label50.AutoSize = True
        Me.Label50.Location = New System.Drawing.Point(13, 498)
        Me.Label50.Name = "Label50"
        Me.Label50.Size = New System.Drawing.Size(86, 13)
        Me.Label50.TabIndex = 0
        Me.Label50.Text = "New project file:"
        '
        'RichTextBox26
        '
        Me.RichTextBox26.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.RichTextBox26.Font = New System.Drawing.Font("Courier New", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RichTextBox26.Location = New System.Drawing.Point(16, 515)
        Me.RichTextBox26.Name = "RichTextBox26"
        Me.RichTextBox26.ReadOnly = True
        Me.RichTextBox26.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.ForcedVertical
        Me.RichTextBox26.Size = New System.Drawing.Size(377, 433)
        Me.RichTextBox26.TabIndex = 1
        Me.RichTextBox26.Text = ""
        '
        'Continue_Button
        '
        Me.Continue_Button.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Continue_Button.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.Continue_Button.Location = New System.Drawing.Point(1096, 954)
        Me.Continue_Button.Name = "Continue_Button"
        Me.Continue_Button.Size = New System.Drawing.Size(75, 23)
        Me.Continue_Button.TabIndex = 2
        Me.Continue_Button.Text = "Continue"
        Me.Continue_Button.UseVisualStyleBackColor = True
        '
        'ProjectValueLoadForm
        '
        Me.AcceptButton = Me.Continue_Button
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1264, 985)
        Me.ControlBox = False
        Me.Controls.Add(Me.Continue_Button)
        Me.Controls.Add(Me.Exit_Button)
        Me.Controls.Add(Me.RichTextBox26)
        Me.Controls.Add(Me.RichTextBox1)
        Me.Controls.Add(Me.Label50)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.GroupBox1)
        Me.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Name = "ProjectValueLoadForm"
        Me.Text = "Project values"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents RichTextBox1 As System.Windows.Forms.RichTextBox
    Friend WithEvents Exit_Button As System.Windows.Forms.Button
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents Label25 As System.Windows.Forms.Label
    Friend WithEvents Label26 As System.Windows.Forms.Label
    Friend WithEvents Label24 As System.Windows.Forms.Label
    Friend WithEvents Label23 As System.Windows.Forms.Label
    Friend WithEvents Label22 As System.Windows.Forms.Label
    Friend WithEvents Label21 As System.Windows.Forms.Label
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label48 As System.Windows.Forms.Label
    Friend WithEvents Label47 As System.Windows.Forms.Label
    Friend WithEvents Label49 As System.Windows.Forms.Label
    Friend WithEvents Label46 As System.Windows.Forms.Label
    Friend WithEvents Label45 As System.Windows.Forms.Label
    Friend WithEvents Label44 As System.Windows.Forms.Label
    Friend WithEvents Label43 As System.Windows.Forms.Label
    Friend WithEvents Label42 As System.Windows.Forms.Label
    Friend WithEvents Label41 As System.Windows.Forms.Label
    Friend WithEvents Label40 As System.Windows.Forms.Label
    Friend WithEvents Label39 As System.Windows.Forms.Label
    Friend WithEvents Label38 As System.Windows.Forms.Label
    Friend WithEvents Label37 As System.Windows.Forms.Label
    Friend WithEvents Label36 As System.Windows.Forms.Label
    Friend WithEvents Label35 As System.Windows.Forms.Label
    Friend WithEvents Label34 As System.Windows.Forms.Label
    Friend WithEvents Label33 As System.Windows.Forms.Label
    Friend WithEvents Label32 As System.Windows.Forms.Label
    Friend WithEvents Label31 As System.Windows.Forms.Label
    Friend WithEvents Label30 As System.Windows.Forms.Label
    Friend WithEvents Label29 As System.Windows.Forms.Label
    Friend WithEvents Label28 As System.Windows.Forms.Label
    Friend WithEvents Label27 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents RichTextBox24 As System.Windows.Forms.RichTextBox
    Friend WithEvents RichTextBox25 As System.Windows.Forms.RichTextBox
    Friend WithEvents RichTextBox23 As System.Windows.Forms.RichTextBox
    Friend WithEvents RichTextBox22 As System.Windows.Forms.RichTextBox
    Friend WithEvents RichTextBox21 As System.Windows.Forms.RichTextBox
    Friend WithEvents RichTextBox20 As System.Windows.Forms.RichTextBox
    Friend WithEvents RichTextBox19 As System.Windows.Forms.RichTextBox
    Friend WithEvents RichTextBox18 As System.Windows.Forms.RichTextBox
    Friend WithEvents RichTextBox17 As System.Windows.Forms.RichTextBox
    Friend WithEvents RichTextBox16 As System.Windows.Forms.RichTextBox
    Friend WithEvents RichTextBox15 As System.Windows.Forms.RichTextBox
    Friend WithEvents RichTextBox14 As System.Windows.Forms.RichTextBox
    Friend WithEvents RichTextBox13 As System.Windows.Forms.RichTextBox
    Friend WithEvents RichTextBox12 As System.Windows.Forms.RichTextBox
    Friend WithEvents RichTextBox11 As System.Windows.Forms.RichTextBox
    Friend WithEvents RichTextBox10 As System.Windows.Forms.RichTextBox
    Friend WithEvents RichTextBox9 As System.Windows.Forms.RichTextBox
    Friend WithEvents RichTextBox8 As System.Windows.Forms.RichTextBox
    Friend WithEvents RichTextBox7 As System.Windows.Forms.RichTextBox
    Friend WithEvents RichTextBox6 As System.Windows.Forms.RichTextBox
    Friend WithEvents RichTextBox5 As System.Windows.Forms.RichTextBox
    Friend WithEvents RichTextBox4 As System.Windows.Forms.RichTextBox
    Friend WithEvents RichTextBox3 As System.Windows.Forms.RichTextBox
    Friend WithEvents RichTextBox2 As System.Windows.Forms.RichTextBox
    Friend WithEvents EpochRTB3 As System.Windows.Forms.RichTextBox
    Friend WithEvents EpochRTB2 As System.Windows.Forms.RichTextBox
    Friend WithEvents EpochRTB1 As System.Windows.Forms.RichTextBox
    Friend WithEvents Label50 As System.Windows.Forms.Label
    Friend WithEvents RichTextBox26 As System.Windows.Forms.RichTextBox
    Friend WithEvents Continue_Button As System.Windows.Forms.Button
End Class
