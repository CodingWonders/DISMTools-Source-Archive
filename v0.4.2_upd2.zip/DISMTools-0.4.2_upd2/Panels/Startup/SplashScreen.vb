﻿Imports System.Drawing.Drawing2D
Public Class SplashScreen

    Dim opacityFade As Single

    Private Sub SplashScreen_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        If MainForm.dtBranch.Contains("preview") Then PreviewFlag.Visible = True
        Timer1.Enabled = True
        Refresh()
    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        For Me.opacityFade = 0 To 1 Step 0.05
            Opacity = opacityFade
            Refresh()
        Next opacityFade
        Opacity = 1
        Refresh()
        Timer1.Enabled = False
        Timer1.Stop()
    End Sub
End Class