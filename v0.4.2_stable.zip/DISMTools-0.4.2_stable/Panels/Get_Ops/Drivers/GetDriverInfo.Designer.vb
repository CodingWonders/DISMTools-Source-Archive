﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class GetDriverInfo
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Win10Title = New System.Windows.Forms.Panel()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.DriverInfoContainerPanel = New System.Windows.Forms.Panel()
        Me.DriverInfoPanel = New System.Windows.Forms.Panel()
        Me.Button9 = New System.Windows.Forms.Button()
        Me.Panel6 = New System.Windows.Forms.Panel()
        Me.Button7 = New System.Windows.Forms.Button()
        Me.Label48 = New System.Windows.Forms.Label()
        Me.Button8 = New System.Windows.Forms.Button()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.DriverContainerPanel = New System.Windows.Forms.Panel()
        Me.InfoFromInstalledDrvsPanel = New System.Windows.Forms.Panel()
        Me.SplitContainer2 = New System.Windows.Forms.SplitContainer()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.ListView1 = New System.Windows.Forms.ListView()
        Me.ColumnHeader1 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader2 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.Panel4 = New System.Windows.Forms.Panel()
        Me.FlowLayoutPanel3 = New System.Windows.Forms.FlowLayoutPanel()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.Label35 = New System.Windows.Forms.Label()
        Me.Label31 = New System.Windows.Forms.Label()
        Me.Label32 = New System.Windows.Forms.Label()
        Me.Label41 = New System.Windows.Forms.Label()
        Me.Label40 = New System.Windows.Forms.Label()
        Me.Label43 = New System.Windows.Forms.Label()
        Me.Label42 = New System.Windows.Forms.Label()
        Me.Label47 = New System.Windows.Forms.Label()
        Me.Label46 = New System.Windows.Forms.Label()
        Me.Label33 = New System.Windows.Forms.Label()
        Me.Label34 = New System.Windows.Forms.Label()
        Me.Label28 = New System.Windows.Forms.Label()
        Me.Label27 = New System.Windows.Forms.Label()
        Me.Label30 = New System.Windows.Forms.Label()
        Me.Label29 = New System.Windows.Forms.Label()
        Me.Label39 = New System.Windows.Forms.Label()
        Me.Label38 = New System.Windows.Forms.Label()
        Me.Label45 = New System.Windows.Forms.Label()
        Me.Label44 = New System.Windows.Forms.Label()
        Me.Label55 = New System.Windows.Forms.Label()
        Me.Panel5 = New System.Windows.Forms.Panel()
        Me.Label36 = New System.Windows.Forms.Label()
        Me.Panel7 = New System.Windows.Forms.Panel()
        Me.Label37 = New System.Windows.Forms.Label()
        Me.FlowLayoutPanel4 = New System.Windows.Forms.FlowLayoutPanel()
        Me.InfoFromDrvPackagesPanel = New System.Windows.Forms.Panel()
        Me.SplitContainer1 = New System.Windows.Forms.SplitContainer()
        Me.DrvPackagesPanel = New System.Windows.Forms.Panel()
        Me.ListBox1 = New System.Windows.Forms.ListBox()
        Me.TableLayoutPanel2 = New System.Windows.Forms.TableLayoutPanel()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.DrvPackageContainerPanel = New System.Windows.Forms.Panel()
        Me.DrvPackageInfoPanel = New System.Windows.Forms.Panel()
        Me.FlowLayoutPanel2 = New System.Windows.Forms.FlowLayoutPanel()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.Label49 = New System.Windows.Forms.Label()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.JumpToPanel = New System.Windows.Forms.Panel()
        Me.ComboBox1 = New System.Windows.Forms.ComboBox()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.Button6 = New System.Windows.Forms.Button()
        Me.Button5 = New System.Windows.Forms.Button()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.NoDrvPanel = New System.Windows.Forms.Panel()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.FlowLayoutPanel1 = New System.Windows.Forms.FlowLayoutPanel()
        Me.LinkLabel1 = New System.Windows.Forms.LinkLabel()
        Me.MenuPanel = New System.Windows.Forms.Panel()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.PictureBox3 = New System.Windows.Forms.PictureBox()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.InstalledDriverLink = New System.Windows.Forms.LinkLabel()
        Me.DriverFileLink = New System.Windows.Forms.LinkLabel()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.OpenFileDialog1 = New System.Windows.Forms.OpenFileDialog()
        Me.Win10Title.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.DriverInfoContainerPanel.SuspendLayout()
        Me.DriverInfoPanel.SuspendLayout()
        Me.Panel6.SuspendLayout()
        Me.DriverContainerPanel.SuspendLayout()
        Me.InfoFromInstalledDrvsPanel.SuspendLayout()
        CType(Me.SplitContainer2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SplitContainer2.Panel1.SuspendLayout()
        Me.SplitContainer2.Panel2.SuspendLayout()
        Me.SplitContainer2.SuspendLayout()
        Me.Panel2.SuspendLayout()
        Me.Panel3.SuspendLayout()
        Me.Panel4.SuspendLayout()
        Me.FlowLayoutPanel3.SuspendLayout()
        Me.Panel5.SuspendLayout()
        Me.Panel7.SuspendLayout()
        Me.InfoFromDrvPackagesPanel.SuspendLayout()
        CType(Me.SplitContainer1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SplitContainer1.Panel1.SuspendLayout()
        Me.SplitContainer1.Panel2.SuspendLayout()
        Me.SplitContainer1.SuspendLayout()
        Me.DrvPackagesPanel.SuspendLayout()
        Me.TableLayoutPanel2.SuspendLayout()
        Me.DrvPackageContainerPanel.SuspendLayout()
        Me.DrvPackageInfoPanel.SuspendLayout()
        Me.FlowLayoutPanel2.SuspendLayout()
        Me.Panel1.SuspendLayout()
        Me.JumpToPanel.SuspendLayout()
        Me.NoDrvPanel.SuspendLayout()
        Me.MenuPanel.SuspendLayout()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Win10Title
        '
        Me.Win10Title.BackColor = System.Drawing.Color.White
        Me.Win10Title.Controls.Add(Me.PictureBox1)
        Me.Win10Title.Controls.Add(Me.Label1)
        Me.Win10Title.Dock = System.Windows.Forms.DockStyle.Top
        Me.Win10Title.Location = New System.Drawing.Point(0, 0)
        Me.Win10Title.Name = "Win10Title"
        Me.Win10Title.Size = New System.Drawing.Size(1008, 48)
        Me.Win10Title.TabIndex = 7
        Me.Win10Title.Visible = False
        '
        'PictureBox1
        '
        Me.PictureBox1.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.PictureBox1.Image = Global.DISMTools.My.Resources.Resources.get_drv_info
        Me.PictureBox1.Location = New System.Drawing.Point(964, 8)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(32, 32)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.PictureBox1.TabIndex = 1
        Me.PictureBox1.TabStop = False
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Segoe UI", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(12, 9)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(217, 30)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Get driver information"
        '
        'DriverInfoContainerPanel
        '
        Me.DriverInfoContainerPanel.Controls.Add(Me.DriverInfoPanel)
        Me.DriverInfoContainerPanel.Controls.Add(Me.MenuPanel)
        Me.DriverInfoContainerPanel.Dock = System.Windows.Forms.DockStyle.Fill
        Me.DriverInfoContainerPanel.Location = New System.Drawing.Point(0, 48)
        Me.DriverInfoContainerPanel.Name = "DriverInfoContainerPanel"
        Me.DriverInfoContainerPanel.Size = New System.Drawing.Size(1008, 513)
        Me.DriverInfoContainerPanel.TabIndex = 9
        '
        'DriverInfoPanel
        '
        Me.DriverInfoPanel.Controls.Add(Me.Button9)
        Me.DriverInfoPanel.Controls.Add(Me.Panel6)
        Me.DriverInfoPanel.Controls.Add(Me.Button8)
        Me.DriverInfoPanel.Controls.Add(Me.Label5)
        Me.DriverInfoPanel.Controls.Add(Me.DriverContainerPanel)
        Me.DriverInfoPanel.Controls.Add(Me.LinkLabel1)
        Me.DriverInfoPanel.Dock = System.Windows.Forms.DockStyle.Fill
        Me.DriverInfoPanel.Location = New System.Drawing.Point(0, 0)
        Me.DriverInfoPanel.Name = "DriverInfoPanel"
        Me.DriverInfoPanel.Size = New System.Drawing.Size(1008, 513)
        Me.DriverInfoPanel.TabIndex = 3
        Me.DriverInfoPanel.Visible = False
        '
        'Button9
        '
        Me.Button9.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.Button9.Location = New System.Drawing.Point(601, 438)
        Me.Button9.Name = "Button9"
        Me.Button9.Size = New System.Drawing.Size(241, 23)
        Me.Button9.TabIndex = 14
        Me.Button9.Text = "View driver file information"
        Me.Button9.UseVisualStyleBackColor = True
        '
        'Panel6
        '
        Me.Panel6.Controls.Add(Me.Button7)
        Me.Panel6.Controls.Add(Me.Label48)
        Me.Panel6.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.Panel6.Location = New System.Drawing.Point(0, 465)
        Me.Panel6.Name = "Panel6"
        Me.Panel6.Size = New System.Drawing.Size(1008, 48)
        Me.Panel6.TabIndex = 5
        Me.Panel6.Visible = False
        '
        'Button7
        '
        Me.Button7.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Button7.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.Button7.Location = New System.Drawing.Point(911, 13)
        Me.Button7.Name = "Button7"
        Me.Button7.Size = New System.Drawing.Size(75, 23)
        Me.Button7.TabIndex = 1
        Me.Button7.Text = "Change"
        Me.Button7.UseVisualStyleBackColor = True
        '
        'Label48
        '
        Me.Label48.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom), System.Windows.Forms.AnchorStyles)
        Me.Label48.AutoEllipsis = True
        Me.Label48.Location = New System.Drawing.Point(22, 0)
        Me.Label48.Name = "Label48"
        Me.Label48.Size = New System.Drawing.Size(863, 48)
        Me.Label48.TabIndex = 0
        Me.Label48.Text = "You have configured the background processes to not show all drivers present in t" & _
    "his image, which includes drivers part of the Windows distribution, so you may n" & _
    "ot see the driver you're interested in."
        Me.Label48.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Button8
        '
        Me.Button8.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button8.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.Button8.Location = New System.Drawing.Point(848, 438)
        Me.Button8.Name = "Button8"
        Me.Button8.Size = New System.Drawing.Size(96, 23)
        Me.Button8.TabIndex = 13
        Me.Button8.Text = "Save..."
        Me.Button8.UseVisualStyleBackColor = True
        '
        'Label5
        '
        Me.Label5.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(20, 460)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(38, 13)
        Me.Label5.TabIndex = 4
        Me.Label5.Text = "Status"
        '
        'DriverContainerPanel
        '
        Me.DriverContainerPanel.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.DriverContainerPanel.Controls.Add(Me.InfoFromInstalledDrvsPanel)
        Me.DriverContainerPanel.Controls.Add(Me.InfoFromDrvPackagesPanel)
        Me.DriverContainerPanel.Location = New System.Drawing.Point(64, 68)
        Me.DriverContainerPanel.Name = "DriverContainerPanel"
        Me.DriverContainerPanel.Size = New System.Drawing.Size(880, 364)
        Me.DriverContainerPanel.TabIndex = 3
        '
        'InfoFromInstalledDrvsPanel
        '
        Me.InfoFromInstalledDrvsPanel.Controls.Add(Me.SplitContainer2)
        Me.InfoFromInstalledDrvsPanel.Dock = System.Windows.Forms.DockStyle.Fill
        Me.InfoFromInstalledDrvsPanel.Location = New System.Drawing.Point(0, 0)
        Me.InfoFromInstalledDrvsPanel.Name = "InfoFromInstalledDrvsPanel"
        Me.InfoFromInstalledDrvsPanel.Size = New System.Drawing.Size(880, 364)
        Me.InfoFromInstalledDrvsPanel.TabIndex = 0
        Me.InfoFromInstalledDrvsPanel.Visible = False
        '
        'SplitContainer2
        '
        Me.SplitContainer2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SplitContainer2.IsSplitterFixed = True
        Me.SplitContainer2.Location = New System.Drawing.Point(0, 0)
        Me.SplitContainer2.Name = "SplitContainer2"
        '
        'SplitContainer2.Panel1
        '
        Me.SplitContainer2.Panel1.Controls.Add(Me.Panel2)
        '
        'SplitContainer2.Panel2
        '
        Me.SplitContainer2.Panel2.Controls.Add(Me.Panel3)
        Me.SplitContainer2.Panel2.Controls.Add(Me.FlowLayoutPanel4)
        Me.SplitContainer2.Size = New System.Drawing.Size(880, 364)
        Me.SplitContainer2.SplitterDistance = 440
        Me.SplitContainer2.TabIndex = 1
        '
        'Panel2
        '
        Me.Panel2.Controls.Add(Me.ListView1)
        Me.Panel2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel2.Location = New System.Drawing.Point(0, 0)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(440, 364)
        Me.Panel2.TabIndex = 1
        '
        'ListView1
        '
        Me.ListView1.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.ColumnHeader1, Me.ColumnHeader2})
        Me.ListView1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.ListView1.FullRowSelect = True
        Me.ListView1.Location = New System.Drawing.Point(0, 0)
        Me.ListView1.Name = "ListView1"
        Me.ListView1.Size = New System.Drawing.Size(440, 364)
        Me.ListView1.TabIndex = 0
        Me.ListView1.UseCompatibleStateImageBehavior = False
        Me.ListView1.View = System.Windows.Forms.View.Details
        '
        'ColumnHeader1
        '
        Me.ColumnHeader1.Text = "Published name"
        Me.ColumnHeader1.Width = 188
        '
        'ColumnHeader2
        '
        Me.ColumnHeader2.Text = "Original file name"
        Me.ColumnHeader2.Width = 220
        '
        'Panel3
        '
        Me.Panel3.Controls.Add(Me.Panel4)
        Me.Panel3.Controls.Add(Me.Panel7)
        Me.Panel3.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel3.Location = New System.Drawing.Point(0, 0)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(436, 364)
        Me.Panel3.TabIndex = 1
        '
        'Panel4
        '
        Me.Panel4.Controls.Add(Me.FlowLayoutPanel3)
        Me.Panel4.Controls.Add(Me.Panel5)
        Me.Panel4.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel4.Location = New System.Drawing.Point(0, 0)
        Me.Panel4.Name = "Panel4"
        Me.Panel4.Size = New System.Drawing.Size(436, 364)
        Me.Panel4.TabIndex = 2
        Me.Panel4.Visible = False
        '
        'FlowLayoutPanel3
        '
        Me.FlowLayoutPanel3.AutoScroll = True
        Me.FlowLayoutPanel3.Controls.Add(Me.Label22)
        Me.FlowLayoutPanel3.Controls.Add(Me.Label23)
        Me.FlowLayoutPanel3.Controls.Add(Me.Label24)
        Me.FlowLayoutPanel3.Controls.Add(Me.Label25)
        Me.FlowLayoutPanel3.Controls.Add(Me.Label26)
        Me.FlowLayoutPanel3.Controls.Add(Me.Label35)
        Me.FlowLayoutPanel3.Controls.Add(Me.Label31)
        Me.FlowLayoutPanel3.Controls.Add(Me.Label32)
        Me.FlowLayoutPanel3.Controls.Add(Me.Label41)
        Me.FlowLayoutPanel3.Controls.Add(Me.Label40)
        Me.FlowLayoutPanel3.Controls.Add(Me.Label43)
        Me.FlowLayoutPanel3.Controls.Add(Me.Label42)
        Me.FlowLayoutPanel3.Controls.Add(Me.Label47)
        Me.FlowLayoutPanel3.Controls.Add(Me.Label46)
        Me.FlowLayoutPanel3.Controls.Add(Me.Label33)
        Me.FlowLayoutPanel3.Controls.Add(Me.Label34)
        Me.FlowLayoutPanel3.Controls.Add(Me.Label28)
        Me.FlowLayoutPanel3.Controls.Add(Me.Label27)
        Me.FlowLayoutPanel3.Controls.Add(Me.Label30)
        Me.FlowLayoutPanel3.Controls.Add(Me.Label29)
        Me.FlowLayoutPanel3.Controls.Add(Me.Label39)
        Me.FlowLayoutPanel3.Controls.Add(Me.Label38)
        Me.FlowLayoutPanel3.Controls.Add(Me.Label45)
        Me.FlowLayoutPanel3.Controls.Add(Me.Label44)
        Me.FlowLayoutPanel3.Controls.Add(Me.Label55)
        Me.FlowLayoutPanel3.Dock = System.Windows.Forms.DockStyle.Fill
        Me.FlowLayoutPanel3.FlowDirection = System.Windows.Forms.FlowDirection.TopDown
        Me.FlowLayoutPanel3.Location = New System.Drawing.Point(0, 36)
        Me.FlowLayoutPanel3.Name = "FlowLayoutPanel3"
        Me.FlowLayoutPanel3.Padding = New System.Windows.Forms.Padding(4, 6, 0, 0)
        Me.FlowLayoutPanel3.Size = New System.Drawing.Size(436, 328)
        Me.FlowLayoutPanel3.TabIndex = 1
        Me.FlowLayoutPanel3.WrapContents = False
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.Location = New System.Drawing.Point(7, 6)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(85, 13)
        Me.Label22.TabIndex = 0
        Me.Label22.Text = "Published name:"
        '
        'Label23
        '
        Me.Label23.AutoEllipsis = True
        Me.Label23.AutoSize = True
        Me.Label23.Location = New System.Drawing.Point(7, 19)
        Me.Label23.Name = "Label23"
        Me.Label23.Padding = New System.Windows.Forms.Padding(0, 2, 0, 0)
        Me.Label23.Size = New System.Drawing.Size(38, 15)
        Me.Label23.TabIndex = 0
        Me.Label23.Text = "Label8"
        Me.Label23.UseMnemonic = False
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.Location = New System.Drawing.Point(7, 34)
        Me.Label24.Name = "Label24"
        Me.Label24.Padding = New System.Windows.Forms.Padding(0, 4, 0, 0)
        Me.Label24.Size = New System.Drawing.Size(93, 17)
        Me.Label24.TabIndex = 0
        Me.Label24.Text = "Original file name:"
        '
        'Label25
        '
        Me.Label25.AutoEllipsis = True
        Me.Label25.AutoSize = True
        Me.Label25.Location = New System.Drawing.Point(7, 51)
        Me.Label25.Name = "Label25"
        Me.Label25.Padding = New System.Windows.Forms.Padding(0, 2, 0, 0)
        Me.Label25.Size = New System.Drawing.Size(38, 15)
        Me.Label25.TabIndex = 0
        Me.Label25.Text = "Label8"
        Me.Label25.UseMnemonic = False
        '
        'Label26
        '
        Me.Label26.AutoSize = True
        Me.Label26.Location = New System.Drawing.Point(7, 66)
        Me.Label26.Name = "Label26"
        Me.Label26.Padding = New System.Windows.Forms.Padding(0, 4, 0, 0)
        Me.Label26.Size = New System.Drawing.Size(80, 17)
        Me.Label26.TabIndex = 0
        Me.Label26.Text = "Provider name:"
        '
        'Label35
        '
        Me.Label35.AutoEllipsis = True
        Me.Label35.AutoSize = True
        Me.Label35.Location = New System.Drawing.Point(7, 83)
        Me.Label35.Name = "Label35"
        Me.Label35.Padding = New System.Windows.Forms.Padding(0, 2, 0, 0)
        Me.Label35.Size = New System.Drawing.Size(38, 15)
        Me.Label35.TabIndex = 0
        Me.Label35.Text = "Label8"
        Me.Label35.UseMnemonic = False
        '
        'Label31
        '
        Me.Label31.AutoSize = True
        Me.Label31.Location = New System.Drawing.Point(7, 98)
        Me.Label31.Name = "Label31"
        Me.Label31.Padding = New System.Windows.Forms.Padding(0, 4, 0, 0)
        Me.Label31.Size = New System.Drawing.Size(65, 17)
        Me.Label31.TabIndex = 0
        Me.Label31.Text = "Class name:"
        '
        'Label32
        '
        Me.Label32.AutoEllipsis = True
        Me.Label32.AutoSize = True
        Me.Label32.Location = New System.Drawing.Point(7, 115)
        Me.Label32.Name = "Label32"
        Me.Label32.Padding = New System.Windows.Forms.Padding(0, 2, 0, 0)
        Me.Label32.Size = New System.Drawing.Size(38, 15)
        Me.Label32.TabIndex = 0
        Me.Label32.Text = "Label8"
        Me.Label32.UseMnemonic = False
        '
        'Label41
        '
        Me.Label41.AutoSize = True
        Me.Label41.Location = New System.Drawing.Point(7, 130)
        Me.Label41.Name = "Label41"
        Me.Label41.Padding = New System.Windows.Forms.Padding(0, 4, 0, 0)
        Me.Label41.Size = New System.Drawing.Size(91, 17)
        Me.Label41.TabIndex = 0
        Me.Label41.Text = "Class description:"
        '
        'Label40
        '
        Me.Label40.AutoEllipsis = True
        Me.Label40.AutoSize = True
        Me.Label40.Location = New System.Drawing.Point(7, 147)
        Me.Label40.Name = "Label40"
        Me.Label40.Padding = New System.Windows.Forms.Padding(0, 2, 0, 0)
        Me.Label40.Size = New System.Drawing.Size(38, 15)
        Me.Label40.TabIndex = 0
        Me.Label40.Text = "Label8"
        Me.Label40.UseMnemonic = False
        '
        'Label43
        '
        Me.Label43.AutoSize = True
        Me.Label43.Location = New System.Drawing.Point(7, 162)
        Me.Label43.Name = "Label43"
        Me.Label43.Padding = New System.Windows.Forms.Padding(0, 4, 0, 0)
        Me.Label43.Size = New System.Drawing.Size(64, 17)
        Me.Label43.TabIndex = 0
        Me.Label43.Text = "Class GUID:"
        '
        'Label42
        '
        Me.Label42.AutoEllipsis = True
        Me.Label42.AutoSize = True
        Me.Label42.Location = New System.Drawing.Point(7, 179)
        Me.Label42.Name = "Label42"
        Me.Label42.Padding = New System.Windows.Forms.Padding(0, 2, 0, 0)
        Me.Label42.Size = New System.Drawing.Size(38, 15)
        Me.Label42.TabIndex = 0
        Me.Label42.Text = "Label8"
        Me.Label42.UseMnemonic = False
        '
        'Label47
        '
        Me.Label47.AutoSize = True
        Me.Label47.Location = New System.Drawing.Point(7, 194)
        Me.Label47.Name = "Label47"
        Me.Label47.Padding = New System.Windows.Forms.Padding(0, 4, 0, 0)
        Me.Label47.Size = New System.Drawing.Size(90, 17)
        Me.Label47.TabIndex = 0
        Me.Label47.Text = "Catalog file path:"
        '
        'Label46
        '
        Me.Label46.AutoEllipsis = True
        Me.Label46.AutoSize = True
        Me.Label46.Location = New System.Drawing.Point(7, 211)
        Me.Label46.Name = "Label46"
        Me.Label46.Padding = New System.Windows.Forms.Padding(0, 2, 0, 0)
        Me.Label46.Size = New System.Drawing.Size(38, 15)
        Me.Label46.TabIndex = 0
        Me.Label46.Text = "Label8"
        Me.Label46.UseMnemonic = False
        '
        'Label33
        '
        Me.Label33.AutoSize = True
        Me.Label33.Location = New System.Drawing.Point(7, 226)
        Me.Label33.Name = "Label33"
        Me.Label33.Padding = New System.Windows.Forms.Padding(0, 4, 0, 0)
        Me.Label33.Size = New System.Drawing.Size(166, 17)
        Me.Label33.TabIndex = 0
        Me.Label33.Text = "Part of the Windows distribution?"
        '
        'Label34
        '
        Me.Label34.AutoEllipsis = True
        Me.Label34.AutoSize = True
        Me.Label34.Location = New System.Drawing.Point(7, 243)
        Me.Label34.Name = "Label34"
        Me.Label34.Padding = New System.Windows.Forms.Padding(0, 2, 0, 0)
        Me.Label34.Size = New System.Drawing.Size(38, 15)
        Me.Label34.TabIndex = 0
        Me.Label34.Text = "Label8"
        Me.Label34.UseMnemonic = False
        '
        'Label28
        '
        Me.Label28.AutoSize = True
        Me.Label28.Location = New System.Drawing.Point(7, 258)
        Me.Label28.Name = "Label28"
        Me.Label28.Padding = New System.Windows.Forms.Padding(0, 4, 0, 0)
        Me.Label28.Size = New System.Drawing.Size(151, 17)
        Me.Label28.TabIndex = 0
        Me.Label28.Text = "Is critical to the boot process?"
        '
        'Label27
        '
        Me.Label27.AutoEllipsis = True
        Me.Label27.AutoSize = True
        Me.Label27.Location = New System.Drawing.Point(7, 275)
        Me.Label27.Name = "Label27"
        Me.Label27.Padding = New System.Windows.Forms.Padding(0, 2, 0, 0)
        Me.Label27.Size = New System.Drawing.Size(38, 15)
        Me.Label27.TabIndex = 0
        Me.Label27.Text = "Label8"
        Me.Label27.UseMnemonic = False
        '
        'Label30
        '
        Me.Label30.AutoSize = True
        Me.Label30.Location = New System.Drawing.Point(7, 290)
        Me.Label30.Name = "Label30"
        Me.Label30.Padding = New System.Windows.Forms.Padding(0, 4, 0, 0)
        Me.Label30.Size = New System.Drawing.Size(46, 17)
        Me.Label30.TabIndex = 0
        Me.Label30.Text = "Version:"
        '
        'Label29
        '
        Me.Label29.AutoEllipsis = True
        Me.Label29.AutoSize = True
        Me.Label29.Location = New System.Drawing.Point(7, 307)
        Me.Label29.Name = "Label29"
        Me.Label29.Padding = New System.Windows.Forms.Padding(0, 2, 0, 0)
        Me.Label29.Size = New System.Drawing.Size(38, 15)
        Me.Label29.TabIndex = 0
        Me.Label29.Text = "Label8"
        Me.Label29.UseMnemonic = False
        '
        'Label39
        '
        Me.Label39.AutoSize = True
        Me.Label39.Location = New System.Drawing.Point(7, 322)
        Me.Label39.Name = "Label39"
        Me.Label39.Padding = New System.Windows.Forms.Padding(0, 4, 0, 0)
        Me.Label39.Size = New System.Drawing.Size(34, 17)
        Me.Label39.TabIndex = 0
        Me.Label39.Text = "Date:"
        '
        'Label38
        '
        Me.Label38.AutoEllipsis = True
        Me.Label38.AutoSize = True
        Me.Label38.Location = New System.Drawing.Point(7, 339)
        Me.Label38.Name = "Label38"
        Me.Label38.Padding = New System.Windows.Forms.Padding(0, 2, 0, 0)
        Me.Label38.Size = New System.Drawing.Size(38, 15)
        Me.Label38.TabIndex = 0
        Me.Label38.Text = "Label8"
        Me.Label38.UseMnemonic = False
        '
        'Label45
        '
        Me.Label45.AutoSize = True
        Me.Label45.Location = New System.Drawing.Point(7, 354)
        Me.Label45.Name = "Label45"
        Me.Label45.Padding = New System.Windows.Forms.Padding(0, 4, 0, 0)
        Me.Label45.Size = New System.Drawing.Size(121, 17)
        Me.Label45.TabIndex = 0
        Me.Label45.Text = "Driver signature status:"
        '
        'Label44
        '
        Me.Label44.AutoEllipsis = True
        Me.Label44.AutoSize = True
        Me.Label44.Location = New System.Drawing.Point(7, 371)
        Me.Label44.Name = "Label44"
        Me.Label44.Padding = New System.Windows.Forms.Padding(0, 2, 0, 0)
        Me.Label44.Size = New System.Drawing.Size(38, 15)
        Me.Label44.TabIndex = 0
        Me.Label44.Text = "Label8"
        Me.Label44.UseMnemonic = False
        '
        'Label55
        '
        Me.Label55.AutoEllipsis = True
        Me.Label55.Location = New System.Drawing.Point(7, 386)
        Me.Label55.Name = "Label55"
        Me.Label55.Padding = New System.Windows.Forms.Padding(0, 2, 0, 0)
        Me.Label55.Size = New System.Drawing.Size(405, 16)
        Me.Label55.TabIndex = 1
        Me.Label55.UseMnemonic = False
        '
        'Panel5
        '
        Me.Panel5.Controls.Add(Me.Label36)
        Me.Panel5.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel5.Location = New System.Drawing.Point(0, 0)
        Me.Panel5.Name = "Panel5"
        Me.Panel5.Size = New System.Drawing.Size(436, 36)
        Me.Panel5.TabIndex = 0
        '
        'Label36
        '
        Me.Label36.AutoEllipsis = True
        Me.Label36.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Label36.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label36.Location = New System.Drawing.Point(0, 0)
        Me.Label36.Name = "Label36"
        Me.Label36.Size = New System.Drawing.Size(436, 36)
        Me.Label36.TabIndex = 0
        Me.Label36.Text = "Driver information"
        Me.Label36.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Panel7
        '
        Me.Panel7.Controls.Add(Me.Label37)
        Me.Panel7.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel7.Location = New System.Drawing.Point(0, 0)
        Me.Panel7.Name = "Panel7"
        Me.Panel7.Size = New System.Drawing.Size(436, 364)
        Me.Panel7.TabIndex = 1
        '
        'Label37
        '
        Me.Label37.AutoEllipsis = True
        Me.Label37.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Label37.Location = New System.Drawing.Point(0, 0)
        Me.Label37.Name = "Label37"
        Me.Label37.Size = New System.Drawing.Size(436, 364)
        Me.Label37.TabIndex = 0
        Me.Label37.Text = "Select an installed driver to view its information here"
        Me.Label37.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'FlowLayoutPanel4
        '
        Me.FlowLayoutPanel4.Location = New System.Drawing.Point(106, 163)
        Me.FlowLayoutPanel4.Name = "FlowLayoutPanel4"
        Me.FlowLayoutPanel4.Size = New System.Drawing.Size(200, 100)
        Me.FlowLayoutPanel4.TabIndex = 0
        '
        'InfoFromDrvPackagesPanel
        '
        Me.InfoFromDrvPackagesPanel.Controls.Add(Me.SplitContainer1)
        Me.InfoFromDrvPackagesPanel.Dock = System.Windows.Forms.DockStyle.Fill
        Me.InfoFromDrvPackagesPanel.Location = New System.Drawing.Point(0, 0)
        Me.InfoFromDrvPackagesPanel.Name = "InfoFromDrvPackagesPanel"
        Me.InfoFromDrvPackagesPanel.Size = New System.Drawing.Size(880, 364)
        Me.InfoFromDrvPackagesPanel.TabIndex = 1
        '
        'SplitContainer1
        '
        Me.SplitContainer1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SplitContainer1.IsSplitterFixed = True
        Me.SplitContainer1.Location = New System.Drawing.Point(0, 0)
        Me.SplitContainer1.Name = "SplitContainer1"
        '
        'SplitContainer1.Panel1
        '
        Me.SplitContainer1.Panel1.Controls.Add(Me.DrvPackagesPanel)
        '
        'SplitContainer1.Panel2
        '
        Me.SplitContainer1.Panel2.Controls.Add(Me.DrvPackageContainerPanel)
        Me.SplitContainer1.Panel2.Controls.Add(Me.FlowLayoutPanel1)
        Me.SplitContainer1.Size = New System.Drawing.Size(880, 364)
        Me.SplitContainer1.SplitterDistance = 440
        Me.SplitContainer1.TabIndex = 0
        '
        'DrvPackagesPanel
        '
        Me.DrvPackagesPanel.Controls.Add(Me.ListBox1)
        Me.DrvPackagesPanel.Controls.Add(Me.TableLayoutPanel2)
        Me.DrvPackagesPanel.Dock = System.Windows.Forms.DockStyle.Fill
        Me.DrvPackagesPanel.Location = New System.Drawing.Point(0, 0)
        Me.DrvPackagesPanel.Name = "DrvPackagesPanel"
        Me.DrvPackagesPanel.Size = New System.Drawing.Size(440, 364)
        Me.DrvPackagesPanel.TabIndex = 1
        '
        'ListBox1
        '
        Me.ListBox1.AllowDrop = True
        Me.ListBox1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.ListBox1.FormattingEnabled = True
        Me.ListBox1.Location = New System.Drawing.Point(0, 0)
        Me.ListBox1.Name = "ListBox1"
        Me.ListBox1.Size = New System.Drawing.Size(440, 336)
        Me.ListBox1.TabIndex = 0
        '
        'TableLayoutPanel2
        '
        Me.TableLayoutPanel2.ColumnCount = 3
        Me.TableLayoutPanel2.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333!))
        Me.TableLayoutPanel2.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333!))
        Me.TableLayoutPanel2.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333!))
        Me.TableLayoutPanel2.Controls.Add(Me.Button3, 2, 0)
        Me.TableLayoutPanel2.Controls.Add(Me.Button2, 1, 0)
        Me.TableLayoutPanel2.Controls.Add(Me.Button1, 0, 0)
        Me.TableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.TableLayoutPanel2.Location = New System.Drawing.Point(0, 336)
        Me.TableLayoutPanel2.Name = "TableLayoutPanel2"
        Me.TableLayoutPanel2.RowCount = 1
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel2.Size = New System.Drawing.Size(440, 28)
        Me.TableLayoutPanel2.TabIndex = 1
        '
        'Button3
        '
        Me.Button3.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Button3.Enabled = False
        Me.Button3.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.Button3.Location = New System.Drawing.Point(295, 3)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(142, 22)
        Me.Button3.TabIndex = 2
        Me.Button3.Text = "Remove all"
        Me.Button3.UseVisualStyleBackColor = True
        '
        'Button2
        '
        Me.Button2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Button2.Enabled = False
        Me.Button2.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.Button2.Location = New System.Drawing.Point(149, 3)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(140, 22)
        Me.Button2.TabIndex = 1
        Me.Button2.Text = "Remove selected"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'Button1
        '
        Me.Button1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Button1.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.Button1.Location = New System.Drawing.Point(3, 3)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(140, 22)
        Me.Button1.TabIndex = 0
        Me.Button1.Text = "Add driver..."
        Me.Button1.UseVisualStyleBackColor = True
        '
        'DrvPackageContainerPanel
        '
        Me.DrvPackageContainerPanel.Controls.Add(Me.DrvPackageInfoPanel)
        Me.DrvPackageContainerPanel.Controls.Add(Me.NoDrvPanel)
        Me.DrvPackageContainerPanel.Dock = System.Windows.Forms.DockStyle.Fill
        Me.DrvPackageContainerPanel.Location = New System.Drawing.Point(0, 0)
        Me.DrvPackageContainerPanel.Name = "DrvPackageContainerPanel"
        Me.DrvPackageContainerPanel.Size = New System.Drawing.Size(436, 364)
        Me.DrvPackageContainerPanel.TabIndex = 1
        '
        'DrvPackageInfoPanel
        '
        Me.DrvPackageInfoPanel.Controls.Add(Me.FlowLayoutPanel2)
        Me.DrvPackageInfoPanel.Controls.Add(Me.Panel1)
        Me.DrvPackageInfoPanel.Dock = System.Windows.Forms.DockStyle.Fill
        Me.DrvPackageInfoPanel.Location = New System.Drawing.Point(0, 0)
        Me.DrvPackageInfoPanel.Name = "DrvPackageInfoPanel"
        Me.DrvPackageInfoPanel.Size = New System.Drawing.Size(436, 364)
        Me.DrvPackageInfoPanel.TabIndex = 2
        Me.DrvPackageInfoPanel.Visible = False
        '
        'FlowLayoutPanel2
        '
        Me.FlowLayoutPanel2.AutoScroll = True
        Me.FlowLayoutPanel2.Controls.Add(Me.Label8)
        Me.FlowLayoutPanel2.Controls.Add(Me.Label9)
        Me.FlowLayoutPanel2.Controls.Add(Me.Label10)
        Me.FlowLayoutPanel2.Controls.Add(Me.Label11)
        Me.FlowLayoutPanel2.Controls.Add(Me.Label12)
        Me.FlowLayoutPanel2.Controls.Add(Me.Label13)
        Me.FlowLayoutPanel2.Controls.Add(Me.Label14)
        Me.FlowLayoutPanel2.Controls.Add(Me.Label16)
        Me.FlowLayoutPanel2.Controls.Add(Me.Label15)
        Me.FlowLayoutPanel2.Controls.Add(Me.Label17)
        Me.FlowLayoutPanel2.Controls.Add(Me.Label18)
        Me.FlowLayoutPanel2.Controls.Add(Me.Label20)
        Me.FlowLayoutPanel2.Controls.Add(Me.Label19)
        Me.FlowLayoutPanel2.Controls.Add(Me.Label49)
        Me.FlowLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.FlowLayoutPanel2.FlowDirection = System.Windows.Forms.FlowDirection.TopDown
        Me.FlowLayoutPanel2.Location = New System.Drawing.Point(0, 36)
        Me.FlowLayoutPanel2.Name = "FlowLayoutPanel2"
        Me.FlowLayoutPanel2.Padding = New System.Windows.Forms.Padding(4, 6, 0, 0)
        Me.FlowLayoutPanel2.Size = New System.Drawing.Size(436, 328)
        Me.FlowLayoutPanel2.TabIndex = 1
        Me.FlowLayoutPanel2.WrapContents = False
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(7, 6)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(113, 13)
        Me.Label8.TabIndex = 0
        Me.Label8.Text = "Hardware description:"
        '
        'Label9
        '
        Me.Label9.AutoEllipsis = True
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(7, 19)
        Me.Label9.Name = "Label9"
        Me.Label9.Padding = New System.Windows.Forms.Padding(0, 2, 0, 0)
        Me.Label9.Size = New System.Drawing.Size(38, 15)
        Me.Label9.TabIndex = 0
        Me.Label9.Text = "Label8"
        Me.Label9.UseMnemonic = False
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(7, 34)
        Me.Label10.Name = "Label10"
        Me.Label10.Padding = New System.Windows.Forms.Padding(0, 4, 0, 0)
        Me.Label10.Size = New System.Drawing.Size(72, 17)
        Me.Label10.TabIndex = 0
        Me.Label10.Text = "Hardware ID:"
        '
        'Label11
        '
        Me.Label11.AutoEllipsis = True
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(7, 51)
        Me.Label11.Name = "Label11"
        Me.Label11.Padding = New System.Windows.Forms.Padding(0, 2, 0, 0)
        Me.Label11.Size = New System.Drawing.Size(38, 15)
        Me.Label11.TabIndex = 0
        Me.Label11.Text = "Label8"
        Me.Label11.UseMnemonic = False
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(7, 66)
        Me.Label12.Name = "Label12"
        Me.Label12.Padding = New System.Windows.Forms.Padding(0, 4, 0, 0)
        Me.Label12.Size = New System.Drawing.Size(77, 17)
        Me.Label12.TabIndex = 0
        Me.Label12.Text = "Additional IDs:"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(7, 83)
        Me.Label13.Name = "Label13"
        Me.Label13.Padding = New System.Windows.Forms.Padding(12, 4, 0, 0)
        Me.Label13.Size = New System.Drawing.Size(95, 17)
        Me.Label13.TabIndex = 0
        Me.Label13.Text = "Compatible IDs:"
        '
        'Label14
        '
        Me.Label14.AutoEllipsis = True
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(7, 100)
        Me.Label14.Name = "Label14"
        Me.Label14.Padding = New System.Windows.Forms.Padding(12, 2, 0, 0)
        Me.Label14.Size = New System.Drawing.Size(50, 15)
        Me.Label14.TabIndex = 0
        Me.Label14.Text = "Label8"
        Me.Label14.UseMnemonic = False
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Location = New System.Drawing.Point(7, 115)
        Me.Label16.Name = "Label16"
        Me.Label16.Padding = New System.Windows.Forms.Padding(12, 4, 0, 0)
        Me.Label16.Size = New System.Drawing.Size(79, 17)
        Me.Label16.TabIndex = 0
        Me.Label16.Text = "Exclude IDs:"
        '
        'Label15
        '
        Me.Label15.AutoEllipsis = True
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(7, 132)
        Me.Label15.Name = "Label15"
        Me.Label15.Padding = New System.Windows.Forms.Padding(12, 2, 0, 0)
        Me.Label15.Size = New System.Drawing.Size(50, 15)
        Me.Label15.TabIndex = 0
        Me.Label15.Text = "Label8"
        Me.Label15.UseMnemonic = False
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Location = New System.Drawing.Point(7, 147)
        Me.Label17.Name = "Label17"
        Me.Label17.Padding = New System.Windows.Forms.Padding(0, 4, 0, 0)
        Me.Label17.Size = New System.Drawing.Size(126, 17)
        Me.Label17.TabIndex = 0
        Me.Label17.Text = "Hardware manufacturer:"
        '
        'Label18
        '
        Me.Label18.AutoEllipsis = True
        Me.Label18.AutoSize = True
        Me.Label18.Location = New System.Drawing.Point(7, 164)
        Me.Label18.Name = "Label18"
        Me.Label18.Padding = New System.Windows.Forms.Padding(0, 2, 0, 0)
        Me.Label18.Size = New System.Drawing.Size(38, 15)
        Me.Label18.TabIndex = 0
        Me.Label18.Text = "Label8"
        Me.Label18.UseMnemonic = False
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Location = New System.Drawing.Point(7, 179)
        Me.Label20.Name = "Label20"
        Me.Label20.Padding = New System.Windows.Forms.Padding(0, 4, 0, 0)
        Me.Label20.Size = New System.Drawing.Size(70, 17)
        Me.Label20.TabIndex = 0
        Me.Label20.Text = "Architecture:"
        '
        'Label19
        '
        Me.Label19.AutoEllipsis = True
        Me.Label19.AutoSize = True
        Me.Label19.Location = New System.Drawing.Point(7, 196)
        Me.Label19.Name = "Label19"
        Me.Label19.Padding = New System.Windows.Forms.Padding(0, 2, 0, 0)
        Me.Label19.Size = New System.Drawing.Size(38, 15)
        Me.Label19.TabIndex = 0
        Me.Label19.Text = "Label8"
        Me.Label19.UseMnemonic = False
        '
        'Label49
        '
        Me.Label49.AutoEllipsis = True
        Me.Label49.Location = New System.Drawing.Point(7, 211)
        Me.Label49.Name = "Label49"
        Me.Label49.Padding = New System.Windows.Forms.Padding(0, 2, 0, 0)
        Me.Label49.Size = New System.Drawing.Size(405, 16)
        Me.Label49.TabIndex = 1
        Me.Label49.UseMnemonic = False
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.JumpToPanel)
        Me.Panel1.Controls.Add(Me.Button6)
        Me.Panel1.Controls.Add(Me.Button5)
        Me.Panel1.Controls.Add(Me.Button4)
        Me.Panel1.Controls.Add(Me.Label7)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel1.Location = New System.Drawing.Point(0, 0)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(436, 36)
        Me.Panel1.TabIndex = 0
        '
        'JumpToPanel
        '
        Me.JumpToPanel.Controls.Add(Me.ComboBox1)
        Me.JumpToPanel.Controls.Add(Me.Label21)
        Me.JumpToPanel.Location = New System.Drawing.Point(0, 0)
        Me.JumpToPanel.Name = "JumpToPanel"
        Me.JumpToPanel.Size = New System.Drawing.Size(436, 36)
        Me.JumpToPanel.TabIndex = 2
        Me.JumpToPanel.Visible = False
        '
        'ComboBox1
        '
        Me.ComboBox1.FormattingEnabled = True
        Me.ComboBox1.Location = New System.Drawing.Point(105, 9)
        Me.ComboBox1.Name = "ComboBox1"
        Me.ComboBox1.Size = New System.Drawing.Size(314, 21)
        Me.ComboBox1.TabIndex = 2
        '
        'Label21
        '
        Me.Label21.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label21.AutoEllipsis = True
        Me.Label21.AutoSize = True
        Me.Label21.Font = New System.Drawing.Font("Tahoma", 8.25!)
        Me.Label21.Location = New System.Drawing.Point(17, 12)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(82, 13)
        Me.Label21.TabIndex = 1
        Me.Label21.Text = "Jump to target:"
        Me.Label21.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Button6
        '
        Me.Button6.Image = Global.DISMTools.My.Resources.Resources.jumpto
        Me.Button6.Location = New System.Drawing.Point(370, 4)
        Me.Button6.Name = "Button6"
        Me.Button6.Size = New System.Drawing.Size(28, 28)
        Me.Button6.TabIndex = 1
        Me.Button6.UseVisualStyleBackColor = True
        '
        'Button5
        '
        Me.Button5.Image = Global.DISMTools.My.Resources.Resources.next_element
        Me.Button5.Location = New System.Drawing.Point(404, 4)
        Me.Button5.Name = "Button5"
        Me.Button5.Size = New System.Drawing.Size(28, 28)
        Me.Button5.TabIndex = 1
        Me.Button5.UseVisualStyleBackColor = True
        '
        'Button4
        '
        Me.Button4.Image = Global.DISMTools.My.Resources.Resources.prev_element
        Me.Button4.Location = New System.Drawing.Point(4, 4)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(28, 28)
        Me.Button4.TabIndex = 1
        Me.Button4.UseVisualStyleBackColor = True
        '
        'Label7
        '
        Me.Label7.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label7.AutoEllipsis = True
        Me.Label7.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(90, 0)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(257, 36)
        Me.Label7.TabIndex = 0
        Me.Label7.Text = "Hardware targets"
        Me.Label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'NoDrvPanel
        '
        Me.NoDrvPanel.Controls.Add(Me.Label6)
        Me.NoDrvPanel.Dock = System.Windows.Forms.DockStyle.Fill
        Me.NoDrvPanel.Location = New System.Drawing.Point(0, 0)
        Me.NoDrvPanel.Name = "NoDrvPanel"
        Me.NoDrvPanel.Size = New System.Drawing.Size(436, 364)
        Me.NoDrvPanel.TabIndex = 1
        '
        'Label6
        '
        Me.Label6.AutoEllipsis = True
        Me.Label6.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Label6.Location = New System.Drawing.Point(0, 0)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(436, 364)
        Me.Label6.TabIndex = 0
        Me.Label6.Text = "Add or select a driver package to view its information here"
        Me.Label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'FlowLayoutPanel1
        '
        Me.FlowLayoutPanel1.Location = New System.Drawing.Point(106, 163)
        Me.FlowLayoutPanel1.Name = "FlowLayoutPanel1"
        Me.FlowLayoutPanel1.Size = New System.Drawing.Size(200, 100)
        Me.FlowLayoutPanel1.TabIndex = 0
        '
        'LinkLabel1
        '
        Me.LinkLabel1.AutoSize = True
        Me.LinkLabel1.Font = New System.Drawing.Font("Tahoma", 8.25!)
        Me.LinkLabel1.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline
        Me.LinkLabel1.LinkColor = System.Drawing.Color.DodgerBlue
        Me.LinkLabel1.Location = New System.Drawing.Point(17, 12)
        Me.LinkLabel1.Name = "LinkLabel1"
        Me.LinkLabel1.Size = New System.Drawing.Size(60, 13)
        Me.LinkLabel1.TabIndex = 2
        Me.LinkLabel1.TabStop = True
        Me.LinkLabel1.Text = "<- Go back"
        '
        'MenuPanel
        '
        Me.MenuPanel.Controls.Add(Me.Label4)
        Me.MenuPanel.Controls.Add(Me.Label3)
        Me.MenuPanel.Controls.Add(Me.PictureBox3)
        Me.MenuPanel.Controls.Add(Me.PictureBox2)
        Me.MenuPanel.Controls.Add(Me.InstalledDriverLink)
        Me.MenuPanel.Controls.Add(Me.DriverFileLink)
        Me.MenuPanel.Controls.Add(Me.Label2)
        Me.MenuPanel.Dock = System.Windows.Forms.DockStyle.Fill
        Me.MenuPanel.Location = New System.Drawing.Point(0, 0)
        Me.MenuPanel.Name = "MenuPanel"
        Me.MenuPanel.Size = New System.Drawing.Size(1008, 513)
        Me.MenuPanel.TabIndex = 2
        '
        'Label4
        '
        Me.Label4.AutoEllipsis = True
        Me.Label4.Location = New System.Drawing.Point(129, 231)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(791, 83)
        Me.Label4.TabIndex = 3
        Me.Label4.Text = "Click here to get information about drivers that you want to add to the Windows i" & _
    "mage you're servicing before proceeding with the driver addition process"
        '
        'Label3
        '
        Me.Label3.AutoEllipsis = True
        Me.Label3.Location = New System.Drawing.Point(129, 93)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(791, 83)
        Me.Label3.TabIndex = 3
        Me.Label3.Text = "Click here to get information about drivers that you've installed or that came wi" & _
    "th the Windows image you're servicing"
        '
        'PictureBox3
        '
        Me.PictureBox3.Image = Global.DISMTools.My.Resources.Resources.info_from_drv_file
        Me.PictureBox3.Location = New System.Drawing.Point(74, 214)
        Me.PictureBox3.Name = "PictureBox3"
        Me.PictureBox3.Size = New System.Drawing.Size(48, 48)
        Me.PictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.PictureBox3.TabIndex = 2
        Me.PictureBox3.TabStop = False
        '
        'PictureBox2
        '
        Me.PictureBox2.Image = Global.DISMTools.My.Resources.Resources.drv_info_from_image
        Me.PictureBox2.Location = New System.Drawing.Point(74, 76)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(48, 48)
        Me.PictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.PictureBox2.TabIndex = 2
        Me.PictureBox2.TabStop = False
        '
        'InstalledDriverLink
        '
        Me.InstalledDriverLink.AutoSize = True
        Me.InstalledDriverLink.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.InstalledDriverLink.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline
        Me.InstalledDriverLink.LinkColor = System.Drawing.Color.DodgerBlue
        Me.InstalledDriverLink.Location = New System.Drawing.Point(128, 76)
        Me.InstalledDriverLink.Name = "InstalledDriverLink"
        Me.InstalledDriverLink.Size = New System.Drawing.Size(352, 13)
        Me.InstalledDriverLink.TabIndex = 1
        Me.InstalledDriverLink.TabStop = True
        Me.InstalledDriverLink.Text = "I want to get information about installed drivers in the image"
        '
        'DriverFileLink
        '
        Me.DriverFileLink.AutoSize = True
        Me.DriverFileLink.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DriverFileLink.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline
        Me.DriverFileLink.LinkColor = System.Drawing.Color.DodgerBlue
        Me.DriverFileLink.Location = New System.Drawing.Point(128, 214)
        Me.DriverFileLink.Name = "DriverFileLink"
        Me.DriverFileLink.Size = New System.Drawing.Size(248, 13)
        Me.DriverFileLink.TabIndex = 1
        Me.DriverFileLink.TabStop = True
        Me.DriverFileLink.Text = "I want to get information about driver files"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(17, 12)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(221, 13)
        Me.Label2.TabIndex = 0
        Me.Label2.Text = "What do you want to get information about?"
        '
        'OpenFileDialog1
        '
        Me.OpenFileDialog1.Filter = "Driver files|*.inf"
        Me.OpenFileDialog1.SupportMultiDottedExtensions = True
        Me.OpenFileDialog1.Title = "Locate driver files"
        '
        'GetDriverInfo
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1008, 561)
        Me.Controls.Add(Me.DriverInfoContainerPanel)
        Me.Controls.Add(Me.Win10Title)
        Me.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "GetDriverInfo"
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "Get driver information"
        Me.Win10Title.ResumeLayout(False)
        Me.Win10Title.PerformLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.DriverInfoContainerPanel.ResumeLayout(False)
        Me.DriverInfoPanel.ResumeLayout(False)
        Me.DriverInfoPanel.PerformLayout()
        Me.Panel6.ResumeLayout(False)
        Me.DriverContainerPanel.ResumeLayout(False)
        Me.InfoFromInstalledDrvsPanel.ResumeLayout(False)
        Me.SplitContainer2.Panel1.ResumeLayout(False)
        Me.SplitContainer2.Panel2.ResumeLayout(False)
        CType(Me.SplitContainer2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.SplitContainer2.ResumeLayout(False)
        Me.Panel2.ResumeLayout(False)
        Me.Panel3.ResumeLayout(False)
        Me.Panel4.ResumeLayout(False)
        Me.FlowLayoutPanel3.ResumeLayout(False)
        Me.FlowLayoutPanel3.PerformLayout()
        Me.Panel5.ResumeLayout(False)
        Me.Panel7.ResumeLayout(False)
        Me.InfoFromDrvPackagesPanel.ResumeLayout(False)
        Me.SplitContainer1.Panel1.ResumeLayout(False)
        Me.SplitContainer1.Panel2.ResumeLayout(False)
        CType(Me.SplitContainer1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.SplitContainer1.ResumeLayout(False)
        Me.DrvPackagesPanel.ResumeLayout(False)
        Me.TableLayoutPanel2.ResumeLayout(False)
        Me.DrvPackageContainerPanel.ResumeLayout(False)
        Me.DrvPackageInfoPanel.ResumeLayout(False)
        Me.FlowLayoutPanel2.ResumeLayout(False)
        Me.FlowLayoutPanel2.PerformLayout()
        Me.Panel1.ResumeLayout(False)
        Me.JumpToPanel.ResumeLayout(False)
        Me.JumpToPanel.PerformLayout()
        Me.NoDrvPanel.ResumeLayout(False)
        Me.MenuPanel.ResumeLayout(False)
        Me.MenuPanel.PerformLayout()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Win10Title As System.Windows.Forms.Panel
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents DriverInfoContainerPanel As System.Windows.Forms.Panel
    Friend WithEvents MenuPanel As System.Windows.Forms.Panel
    Friend WithEvents PictureBox3 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox2 As System.Windows.Forms.PictureBox
    Friend WithEvents DriverFileLink As System.Windows.Forms.LinkLabel
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents DriverInfoPanel As System.Windows.Forms.Panel
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents DriverContainerPanel As System.Windows.Forms.Panel
    Friend WithEvents LinkLabel1 As System.Windows.Forms.LinkLabel
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents InfoFromDrvPackagesPanel As System.Windows.Forms.Panel
    Friend WithEvents SplitContainer1 As System.Windows.Forms.SplitContainer
    Friend WithEvents FlowLayoutPanel1 As System.Windows.Forms.FlowLayoutPanel
    Friend WithEvents InfoFromInstalledDrvsPanel As System.Windows.Forms.Panel
    Friend WithEvents ListBox1 As System.Windows.Forms.ListBox
    Friend WithEvents DrvPackageContainerPanel As System.Windows.Forms.Panel
    Friend WithEvents NoDrvPanel As System.Windows.Forms.Panel
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents DrvPackagesPanel As System.Windows.Forms.Panel
    Friend WithEvents TableLayoutPanel2 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents Button3 As System.Windows.Forms.Button
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents DrvPackageInfoPanel As System.Windows.Forms.Panel
    Friend WithEvents FlowLayoutPanel2 As System.Windows.Forms.FlowLayoutPanel
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents OpenFileDialog1 As System.Windows.Forms.OpenFileDialog
    Friend WithEvents InstalledDriverLink As System.Windows.Forms.LinkLabel
    Friend WithEvents Button4 As System.Windows.Forms.Button
    Friend WithEvents Button5 As System.Windows.Forms.Button
    Friend WithEvents Button6 As System.Windows.Forms.Button
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents JumpToPanel As System.Windows.Forms.Panel
    Friend WithEvents ComboBox1 As System.Windows.Forms.ComboBox
    Friend WithEvents Label21 As System.Windows.Forms.Label
    Friend WithEvents SplitContainer2 As System.Windows.Forms.SplitContainer
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents ListView1 As System.Windows.Forms.ListView
    Friend WithEvents ColumnHeader1 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader2 As System.Windows.Forms.ColumnHeader
    Friend WithEvents Panel3 As System.Windows.Forms.Panel
    Friend WithEvents Panel4 As System.Windows.Forms.Panel
    Friend WithEvents FlowLayoutPanel3 As System.Windows.Forms.FlowLayoutPanel
    Friend WithEvents Label22 As System.Windows.Forms.Label
    Friend WithEvents Label23 As System.Windows.Forms.Label
    Friend WithEvents Label24 As System.Windows.Forms.Label
    Friend WithEvents Label25 As System.Windows.Forms.Label
    Friend WithEvents Label26 As System.Windows.Forms.Label
    Friend WithEvents Label31 As System.Windows.Forms.Label
    Friend WithEvents Label32 As System.Windows.Forms.Label
    Friend WithEvents Label33 As System.Windows.Forms.Label
    Friend WithEvents Label34 As System.Windows.Forms.Label
    Friend WithEvents Panel5 As System.Windows.Forms.Panel
    Friend WithEvents Label36 As System.Windows.Forms.Label
    Friend WithEvents Panel7 As System.Windows.Forms.Panel
    Friend WithEvents Label37 As System.Windows.Forms.Label
    Friend WithEvents FlowLayoutPanel4 As System.Windows.Forms.FlowLayoutPanel
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents Label35 As System.Windows.Forms.Label
    Friend WithEvents Label41 As System.Windows.Forms.Label
    Friend WithEvents Label40 As System.Windows.Forms.Label
    Friend WithEvents Label43 As System.Windows.Forms.Label
    Friend WithEvents Label42 As System.Windows.Forms.Label
    Friend WithEvents Label47 As System.Windows.Forms.Label
    Friend WithEvents Label46 As System.Windows.Forms.Label
    Friend WithEvents Label28 As System.Windows.Forms.Label
    Friend WithEvents Label27 As System.Windows.Forms.Label
    Friend WithEvents Label30 As System.Windows.Forms.Label
    Friend WithEvents Label29 As System.Windows.Forms.Label
    Friend WithEvents Label39 As System.Windows.Forms.Label
    Friend WithEvents Label38 As System.Windows.Forms.Label
    Friend WithEvents Label45 As System.Windows.Forms.Label
    Friend WithEvents Label44 As System.Windows.Forms.Label
    Friend WithEvents Panel6 As System.Windows.Forms.Panel
    Friend WithEvents Button7 As System.Windows.Forms.Button
    Friend WithEvents Label48 As System.Windows.Forms.Label
    Friend WithEvents Label55 As System.Windows.Forms.Label
    Friend WithEvents Label49 As System.Windows.Forms.Label
    Friend WithEvents Button8 As System.Windows.Forms.Button
    Friend WithEvents Button9 As System.Windows.Forms.Button

End Class
