﻿Public Class GetImgInfoReport

End Class