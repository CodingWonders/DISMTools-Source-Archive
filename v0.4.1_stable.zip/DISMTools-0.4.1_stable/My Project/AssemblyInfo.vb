﻿Imports System
Imports System.Reflection
Imports System.Runtime.InteropServices

' La información general sobre un ensamblado se controla mediante el siguiente 
' conjunto de atributos. Cambie estos atributos para modificar la información
' asociada con un ensamblado.

' Revisar los valores de los atributos del ensamblado

<Assembly: AssemblyTitle("DISMTools")> 
<Assembly: AssemblyDescription("A GUI and automation tool for DISM operations")> 
<Assembly: AssemblyCompany("")> 
<Assembly: AssemblyProduct("DISMTools")> 
<Assembly: AssemblyCopyright("© 2022-2024 CodingWonders Software")> 
<Assembly: AssemblyTrademark("")> 

<Assembly: ComVisible(False)>

'El siguiente GUID sirve como identificador de typelib si este proyecto se expone a COM
<Assembly: Guid("f6f97856-b121-4274-afe6-ea40516b8192")> 

' La información de versión de un ensamblado consta de los cuatro valores siguientes:
'
'      Versión principal
'      Versión secundaria 
'      Número de compilación
'      Revisión
'
' Puede especificar todos los valores o usar los valores predeterminados de número de compilación y de revisión 
' mediante el asterisco ('*'), como se muestra a continuación:
' <Assembly: AssemblyVersion("1.0.*")> 

<Assembly: AssemblyVersion("0.4.1.2413")> 
<Assembly: AssemblyFileVersion("0.4.1.2413")> 
