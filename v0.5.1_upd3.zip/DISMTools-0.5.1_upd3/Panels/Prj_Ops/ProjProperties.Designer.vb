﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class ProjProperties
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.TableLayoutPanel1 = New System.Windows.Forms.TableLayoutPanel()
        Me.OK_Button = New System.Windows.Forms.Button()
        Me.Cancel_Button = New System.Windows.Forms.Button()
        Me.Win10Title = New System.Windows.Forms.Panel()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.TabControl1 = New System.Windows.Forms.TabControl()
        Me.TabPage1 = New System.Windows.Forms.TabPage()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.TabPage2 = New System.Windows.Forms.TabPage()
        Me.LanguageList = New System.Windows.Forms.ListBox()
        Me.RemountImgBtn = New System.Windows.Forms.Button()
        Me.RecoverButton = New System.Windows.Forms.Button()
        Me.RWRemountBtn = New System.Windows.Forms.Button()
        Me.imgLangText = New System.Windows.Forms.TextBox()
        Me.Label62 = New System.Windows.Forms.Label()
        Me.imgRW = New System.Windows.Forms.Label()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.LinkLabel2 = New System.Windows.Forms.LinkLabel()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label58 = New System.Windows.Forms.Label()
        Me.Label60 = New System.Windows.Forms.Label()
        Me.Label57 = New System.Windows.Forms.Label()
        Me.Label55 = New System.Windows.Forms.Label()
        Me.Label53 = New System.Windows.Forms.Label()
        Me.Label51 = New System.Windows.Forms.Label()
        Me.Label49 = New System.Windows.Forms.Label()
        Me.Label47 = New System.Windows.Forms.Label()
        Me.Label45 = New System.Windows.Forms.Label()
        Me.Label43 = New System.Windows.Forms.Label()
        Me.Label41 = New System.Windows.Forms.Label()
        Me.Label39 = New System.Windows.Forms.Label()
        Me.Label37 = New System.Windows.Forms.Label()
        Me.Label35 = New System.Windows.Forms.Label()
        Me.Label33 = New System.Windows.Forms.Label()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label31 = New System.Windows.Forms.Label()
        Me.Label29 = New System.Windows.Forms.Label()
        Me.Label27 = New System.Windows.Forms.Label()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.imgFormat = New System.Windows.Forms.Label()
        Me.imgModification = New System.Windows.Forms.Label()
        Me.imgCreation = New System.Windows.Forms.Label()
        Me.imgFiles = New System.Windows.Forms.Label()
        Me.imgDirs = New System.Windows.Forms.Label()
        Me.imgSysRoot = New System.Windows.Forms.Label()
        Me.imgPSuite = New System.Windows.Forms.Label()
        Me.imgPType = New System.Windows.Forms.Label()
        Me.imgEdition = New System.Windows.Forms.Label()
        Me.imgSPLvl = New System.Windows.Forms.Label()
        Me.imgSPBuild = New System.Windows.Forms.Label()
        Me.imgHal = New System.Windows.Forms.Label()
        Me.imgMountDir = New System.Windows.Forms.Label()
        Me.imgArch = New System.Windows.Forms.Label()
        Me.imgWimBootStatus = New System.Windows.Forms.Label()
        Me.imgMountedStatus = New System.Windows.Forms.Label()
        Me.imgSize = New System.Windows.Forms.Label()
        Me.imgMountedDesc = New System.Windows.Forms.Label()
        Me.imgMountedName = New System.Windows.Forms.Label()
        Me.imgVersion = New System.Windows.Forms.Label()
        Me.imgIndex = New System.Windows.Forms.Label()
        Me.imgName = New System.Windows.Forms.Label()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.TableLayoutPanel1.SuspendLayout()
        Me.Win10Title.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabControl1.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        Me.Panel1.SuspendLayout()
        Me.TabPage2.SuspendLayout()
        Me.Panel3.SuspendLayout()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel2.SuspendLayout()
        Me.SuspendLayout()
        '
        'TableLayoutPanel1
        '
        Me.TableLayoutPanel1.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TableLayoutPanel1.ColumnCount = 2
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel1.Controls.Add(Me.OK_Button, 0, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.Cancel_Button, 1, 0)
        Me.TableLayoutPanel1.Location = New System.Drawing.Point(850, 580)
        Me.TableLayoutPanel1.Name = "TableLayoutPanel1"
        Me.TableLayoutPanel1.RowCount = 1
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel1.Size = New System.Drawing.Size(146, 29)
        Me.TableLayoutPanel1.TabIndex = 0
        '
        'OK_Button
        '
        Me.OK_Button.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.OK_Button.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.OK_Button.Location = New System.Drawing.Point(3, 3)
        Me.OK_Button.Name = "OK_Button"
        Me.OK_Button.Size = New System.Drawing.Size(67, 23)
        Me.OK_Button.TabIndex = 0
        Me.OK_Button.Text = "OK"
        '
        'Cancel_Button
        '
        Me.Cancel_Button.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Cancel_Button.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.Cancel_Button.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.Cancel_Button.Location = New System.Drawing.Point(76, 3)
        Me.Cancel_Button.Name = "Cancel_Button"
        Me.Cancel_Button.Size = New System.Drawing.Size(67, 23)
        Me.Cancel_Button.TabIndex = 1
        Me.Cancel_Button.Text = "Cancel"
        '
        'Win10Title
        '
        Me.Win10Title.BackColor = System.Drawing.Color.White
        Me.Win10Title.Controls.Add(Me.PictureBox1)
        Me.Win10Title.Controls.Add(Me.Label1)
        Me.Win10Title.Dock = System.Windows.Forms.DockStyle.Top
        Me.Win10Title.Location = New System.Drawing.Point(0, 0)
        Me.Win10Title.Name = "Win10Title"
        Me.Win10Title.Size = New System.Drawing.Size(1008, 48)
        Me.Win10Title.TabIndex = 3
        Me.Win10Title.Visible = False
        '
        'PictureBox1
        '
        Me.PictureBox1.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.PictureBox1.Image = Global.DISMTools.My.Resources.Resources.icons8_info_32px
        Me.PictureBox1.Location = New System.Drawing.Point(964, 8)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(32, 32)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.PictureBox1.TabIndex = 1
        Me.PictureBox1.TabStop = False
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Segoe UI", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(12, 9)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(176, 30)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Project properties"
        '
        'TabControl1
        '
        Me.TabControl1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TabControl1.Controls.Add(Me.TabPage1)
        Me.TabControl1.Controls.Add(Me.TabPage2)
        Me.TabControl1.Location = New System.Drawing.Point(12, 54)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(984, 520)
        Me.TabControl1.TabIndex = 4
        '
        'TabPage1
        '
        Me.TabPage1.Controls.Add(Me.Label8)
        Me.TabPage1.Controls.Add(Me.Label7)
        Me.TabPage1.Controls.Add(Me.Label6)
        Me.TabPage1.Controls.Add(Me.Label12)
        Me.TabPage1.Controls.Add(Me.Label11)
        Me.TabPage1.Controls.Add(Me.Label10)
        Me.TabPage1.Controls.Add(Me.Label9)
        Me.TabPage1.Controls.Add(Me.Label5)
        Me.TabPage1.Controls.Add(Me.Panel1)
        Me.TabPage1.Location = New System.Drawing.Point(4, 22)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage1.Size = New System.Drawing.Size(976, 494)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "Project"
        Me.TabPage1.UseVisualStyleBackColor = True
        '
        'Label8
        '
        Me.Label8.Location = New System.Drawing.Point(237, 325)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(196, 13)
        Me.Label8.TabIndex = 5
        Me.Label8.Text = "Project GUID:"
        Me.Label8.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label7
        '
        Me.Label7.Location = New System.Drawing.Point(237, 305)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(196, 13)
        Me.Label7.TabIndex = 5
        Me.Label7.Text = "Creation date:"
        Me.Label7.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label6
        '
        Me.Label6.Location = New System.Drawing.Point(237, 197)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(196, 13)
        Me.Label6.TabIndex = 5
        Me.Label6.Text = "Location:"
        Me.Label6.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label12
        '
        Me.Label12.Location = New System.Drawing.Point(439, 325)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(301, 13)
        Me.Label12.TabIndex = 5
        Me.Label12.Text = "projGuid"
        '
        'Label11
        '
        Me.Label11.Location = New System.Drawing.Point(439, 305)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(301, 13)
        Me.Label11.TabIndex = 5
        Me.Label11.Text = "projTZData"
        '
        'Label10
        '
        Me.Label10.Location = New System.Drawing.Point(439, 197)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(301, 98)
        Me.Label10.TabIndex = 5
        Me.Label10.Text = "projPath"
        '
        'Label9
        '
        Me.Label9.Location = New System.Drawing.Point(439, 157)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(301, 29)
        Me.Label9.TabIndex = 5
        Me.Label9.Text = "projName"
        '
        'Label5
        '
        Me.Label5.Location = New System.Drawing.Point(237, 157)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(196, 13)
        Me.Label5.TabIndex = 5
        Me.Label5.Text = "Name:"
        Me.Label5.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.Label2)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel1.Location = New System.Drawing.Point(3, 3)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(970, 32)
        Me.Panel1.TabIndex = 0
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(8, 8)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(243, 13)
        Me.Label2.TabIndex = 0
        Me.Label2.Text = "View project properties, such as name or location"
        '
        'TabPage2
        '
        Me.TabPage2.Controls.Add(Me.LanguageList)
        Me.TabPage2.Controls.Add(Me.RemountImgBtn)
        Me.TabPage2.Controls.Add(Me.RecoverButton)
        Me.TabPage2.Controls.Add(Me.RWRemountBtn)
        Me.TabPage2.Controls.Add(Me.imgLangText)
        Me.TabPage2.Controls.Add(Me.Label62)
        Me.TabPage2.Controls.Add(Me.imgRW)
        Me.TabPage2.Controls.Add(Me.Panel3)
        Me.TabPage2.Controls.Add(Me.Label13)
        Me.TabPage2.Controls.Add(Me.Label58)
        Me.TabPage2.Controls.Add(Me.Label60)
        Me.TabPage2.Controls.Add(Me.Label57)
        Me.TabPage2.Controls.Add(Me.Label55)
        Me.TabPage2.Controls.Add(Me.Label53)
        Me.TabPage2.Controls.Add(Me.Label51)
        Me.TabPage2.Controls.Add(Me.Label49)
        Me.TabPage2.Controls.Add(Me.Label47)
        Me.TabPage2.Controls.Add(Me.Label45)
        Me.TabPage2.Controls.Add(Me.Label43)
        Me.TabPage2.Controls.Add(Me.Label41)
        Me.TabPage2.Controls.Add(Me.Label39)
        Me.TabPage2.Controls.Add(Me.Label37)
        Me.TabPage2.Controls.Add(Me.Label35)
        Me.TabPage2.Controls.Add(Me.Label33)
        Me.TabPage2.Controls.Add(Me.Label22)
        Me.TabPage2.Controls.Add(Me.Label14)
        Me.TabPage2.Controls.Add(Me.Label31)
        Me.TabPage2.Controls.Add(Me.Label29)
        Me.TabPage2.Controls.Add(Me.Label27)
        Me.TabPage2.Controls.Add(Me.Label25)
        Me.TabPage2.Controls.Add(Me.Label15)
        Me.TabPage2.Controls.Add(Me.imgFormat)
        Me.TabPage2.Controls.Add(Me.imgModification)
        Me.TabPage2.Controls.Add(Me.imgCreation)
        Me.TabPage2.Controls.Add(Me.imgFiles)
        Me.TabPage2.Controls.Add(Me.imgDirs)
        Me.TabPage2.Controls.Add(Me.imgSysRoot)
        Me.TabPage2.Controls.Add(Me.imgPSuite)
        Me.TabPage2.Controls.Add(Me.imgPType)
        Me.TabPage2.Controls.Add(Me.imgEdition)
        Me.TabPage2.Controls.Add(Me.imgSPLvl)
        Me.TabPage2.Controls.Add(Me.imgSPBuild)
        Me.TabPage2.Controls.Add(Me.imgHal)
        Me.TabPage2.Controls.Add(Me.imgMountDir)
        Me.TabPage2.Controls.Add(Me.imgArch)
        Me.TabPage2.Controls.Add(Me.imgWimBootStatus)
        Me.TabPage2.Controls.Add(Me.imgMountedStatus)
        Me.TabPage2.Controls.Add(Me.imgSize)
        Me.TabPage2.Controls.Add(Me.imgMountedDesc)
        Me.TabPage2.Controls.Add(Me.imgMountedName)
        Me.TabPage2.Controls.Add(Me.imgVersion)
        Me.TabPage2.Controls.Add(Me.imgIndex)
        Me.TabPage2.Controls.Add(Me.imgName)
        Me.TabPage2.Controls.Add(Me.Label19)
        Me.TabPage2.Controls.Add(Me.Label20)
        Me.TabPage2.Controls.Add(Me.Panel2)
        Me.TabPage2.Location = New System.Drawing.Point(4, 22)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage2.Size = New System.Drawing.Size(976, 494)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "Image"
        Me.TabPage2.UseVisualStyleBackColor = True
        '
        'LanguageList
        '
        Me.LanguageList.FormattingEnabled = True
        Me.LanguageList.Location = New System.Drawing.Point(613, 262)
        Me.LanguageList.Name = "LanguageList"
        Me.LanguageList.ScrollAlwaysVisible = True
        Me.LanguageList.Size = New System.Drawing.Size(278, 95)
        Me.LanguageList.TabIndex = 20
        '
        'RemountImgBtn
        '
        Me.RemountImgBtn.AutoEllipsis = True
        Me.RemountImgBtn.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.RemountImgBtn.Location = New System.Drawing.Point(342, 239)
        Me.RemountImgBtn.Name = "RemountImgBtn"
        Me.RemountImgBtn.Size = New System.Drawing.Size(75, 23)
        Me.RemountImgBtn.TabIndex = 19
        Me.RemountImgBtn.Text = "Reload"
        Me.RemountImgBtn.UseVisualStyleBackColor = True
        Me.RemountImgBtn.Visible = False
        '
        'RecoverButton
        '
        Me.RecoverButton.AutoEllipsis = True
        Me.RecoverButton.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.RecoverButton.Location = New System.Drawing.Point(342, 239)
        Me.RecoverButton.Name = "RecoverButton"
        Me.RecoverButton.Size = New System.Drawing.Size(75, 23)
        Me.RecoverButton.TabIndex = 19
        Me.RecoverButton.Text = "Recover"
        Me.RecoverButton.UseVisualStyleBackColor = True
        Me.RecoverButton.Visible = False
        '
        'RWRemountBtn
        '
        Me.RWRemountBtn.AutoEllipsis = True
        Me.RWRemountBtn.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.RWRemountBtn.Location = New System.Drawing.Point(722, 376)
        Me.RWRemountBtn.Name = "RWRemountBtn"
        Me.RWRemountBtn.Size = New System.Drawing.Size(169, 23)
        Me.RWRemountBtn.TabIndex = 18
        Me.RWRemountBtn.Text = "Remount with write permissions"
        Me.RWRemountBtn.UseVisualStyleBackColor = True
        Me.RWRemountBtn.Visible = False
        '
        'imgLangText
        '
        Me.imgLangText.Location = New System.Drawing.Point(613, 261)
        Me.imgLangText.Multiline = True
        Me.imgLangText.Name = "imgLangText"
        Me.imgLangText.ReadOnly = True
        Me.imgLangText.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.imgLangText.Size = New System.Drawing.Size(278, 96)
        Me.imgLangText.TabIndex = 17
        Me.imgLangText.Visible = False
        '
        'Label62
        '
        Me.Label62.Location = New System.Drawing.Point(423, 381)
        Me.Label62.Name = "Label62"
        Me.Label62.Size = New System.Drawing.Size(181, 13)
        Me.Label62.TabIndex = 7
        Me.Label62.Text = "Image R/W permissions:"
        Me.Label62.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'imgRW
        '
        Me.imgRW.Location = New System.Drawing.Point(610, 381)
        Me.imgRW.Name = "imgRW"
        Me.imgRW.Size = New System.Drawing.Size(106, 13)
        Me.imgRW.TabIndex = 10
        Me.imgRW.Text = "imgRW"
        '
        'Panel3
        '
        Me.Panel3.Controls.Add(Me.PictureBox2)
        Me.Panel3.Controls.Add(Me.LinkLabel2)
        Me.Panel3.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.Panel3.Location = New System.Drawing.Point(3, 443)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(970, 48)
        Me.Panel3.TabIndex = 15
        Me.Panel3.Visible = False
        '
        'PictureBox2
        '
        Me.PictureBox2.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.PictureBox2.Image = Global.DISMTools.My.Resources.Resources.caution
        Me.PictureBox2.Location = New System.Drawing.Point(10, 6)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(32, 32)
        Me.PictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.PictureBox2.TabIndex = 1
        Me.PictureBox2.TabStop = False
        '
        'LinkLabel2
        '
        Me.LinkLabel2.LinkArea = New System.Windows.Forms.LinkArea(134, 28)
        Me.LinkLabel2.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline
        Me.LinkLabel2.LinkColor = System.Drawing.Color.DodgerBlue
        Me.LinkLabel2.Location = New System.Drawing.Point(48, 6)
        Me.LinkLabel2.Name = "LinkLabel2"
        Me.LinkLabel2.Size = New System.Drawing.Size(919, 32)
        Me.LinkLabel2.TabIndex = 16
        Me.LinkLabel2.TabStop = True
        Me.LinkLabel2.Text = "Many properties cannot be seen because an image has not yet been mounted. Once yo" & _
    "u mount it, detailed information will be shown here. Click here to mount an imag" & _
    "e"
        Me.LinkLabel2.UseCompatibleTextRendering = True
        '
        'Label13
        '
        Me.Label13.Location = New System.Drawing.Point(86, 168)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(130, 13)
        Me.Label13.TabIndex = 6
        Me.Label13.Text = "Mount directory:"
        Me.Label13.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label58
        '
        Me.Label58.Location = New System.Drawing.Point(446, 264)
        Me.Label58.Name = "Label58"
        Me.Label58.Size = New System.Drawing.Size(158, 13)
        Me.Label58.TabIndex = 7
        Me.Label58.Text = "Installed languages:"
        Me.Label58.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label60
        '
        Me.Label60.Location = New System.Drawing.Point(423, 360)
        Me.Label60.Name = "Label60"
        Me.Label60.Size = New System.Drawing.Size(181, 13)
        Me.Label60.TabIndex = 7
        Me.Label60.Text = "File format:"
        Me.Label60.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label57
        '
        Me.Label57.Location = New System.Drawing.Point(423, 246)
        Me.Label57.Name = "Label57"
        Me.Label57.Size = New System.Drawing.Size(181, 13)
        Me.Label57.TabIndex = 7
        Me.Label57.Text = "Modification date:"
        Me.Label57.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label55
        '
        Me.Label55.Location = New System.Drawing.Point(423, 230)
        Me.Label55.Name = "Label55"
        Me.Label55.Size = New System.Drawing.Size(181, 13)
        Me.Label55.TabIndex = 7
        Me.Label55.Text = "Creation date:"
        Me.Label55.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label53
        '
        Me.Label53.Location = New System.Drawing.Point(423, 214)
        Me.Label53.Name = "Label53"
        Me.Label53.Size = New System.Drawing.Size(181, 13)
        Me.Label53.TabIndex = 7
        Me.Label53.Text = "File count:"
        Me.Label53.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label51
        '
        Me.Label51.Location = New System.Drawing.Point(423, 198)
        Me.Label51.Name = "Label51"
        Me.Label51.Size = New System.Drawing.Size(181, 13)
        Me.Label51.TabIndex = 7
        Me.Label51.Text = "Directory count:"
        Me.Label51.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label49
        '
        Me.Label49.Location = New System.Drawing.Point(423, 182)
        Me.Label49.Name = "Label49"
        Me.Label49.Size = New System.Drawing.Size(181, 13)
        Me.Label49.TabIndex = 7
        Me.Label49.Text = "System root directory:"
        Me.Label49.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label47
        '
        Me.Label47.Location = New System.Drawing.Point(423, 166)
        Me.Label47.Name = "Label47"
        Me.Label47.Size = New System.Drawing.Size(181, 13)
        Me.Label47.TabIndex = 7
        Me.Label47.Text = "Product suite:"
        Me.Label47.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label45
        '
        Me.Label45.Location = New System.Drawing.Point(423, 150)
        Me.Label45.Name = "Label45"
        Me.Label45.Size = New System.Drawing.Size(181, 13)
        Me.Label45.TabIndex = 7
        Me.Label45.Text = "Product type:"
        Me.Label45.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label43
        '
        Me.Label43.Location = New System.Drawing.Point(423, 134)
        Me.Label43.Name = "Label43"
        Me.Label43.Size = New System.Drawing.Size(181, 13)
        Me.Label43.TabIndex = 7
        Me.Label43.Text = "Edition:"
        Me.Label43.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label41
        '
        Me.Label41.Location = New System.Drawing.Point(423, 118)
        Me.Label41.Name = "Label41"
        Me.Label41.Size = New System.Drawing.Size(181, 13)
        Me.Label41.TabIndex = 7
        Me.Label41.Text = "Service Pack level:"
        Me.Label41.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label39
        '
        Me.Label39.Location = New System.Drawing.Point(423, 102)
        Me.Label39.Name = "Label39"
        Me.Label39.Size = New System.Drawing.Size(181, 13)
        Me.Label39.TabIndex = 7
        Me.Label39.Text = "Service Pack build:"
        Me.Label39.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label37
        '
        Me.Label37.Location = New System.Drawing.Point(423, 72)
        Me.Label37.Name = "Label37"
        Me.Label37.Size = New System.Drawing.Size(181, 13)
        Me.Label37.TabIndex = 7
        Me.Label37.Text = "HAL:"
        Me.Label37.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label35
        '
        Me.Label35.Location = New System.Drawing.Point(86, 402)
        Me.Label35.Name = "Label35"
        Me.Label35.Size = New System.Drawing.Size(130, 13)
        Me.Label35.TabIndex = 7
        Me.Label35.Text = "Architecture:"
        Me.Label35.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label33
        '
        Me.Label33.Location = New System.Drawing.Point(86, 386)
        Me.Label33.Name = "Label33"
        Me.Label33.Size = New System.Drawing.Size(130, 13)
        Me.Label33.TabIndex = 7
        Me.Label33.Text = "Supports WIMBoot?"
        Me.Label33.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label22
        '
        Me.Label22.Location = New System.Drawing.Point(86, 244)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(130, 13)
        Me.Label22.TabIndex = 7
        Me.Label22.Text = "Image status:"
        Me.Label22.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label14
        '
        Me.Label14.Location = New System.Drawing.Point(86, 148)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(130, 13)
        Me.Label14.TabIndex = 7
        Me.Label14.Text = "Image index:"
        Me.Label14.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label31
        '
        Me.Label31.Location = New System.Drawing.Point(86, 356)
        Me.Label31.Name = "Label31"
        Me.Label31.Size = New System.Drawing.Size(130, 13)
        Me.Label31.TabIndex = 8
        Me.Label31.Text = "Size:"
        Me.Label31.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label29
        '
        Me.Label29.Location = New System.Drawing.Point(86, 326)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(130, 13)
        Me.Label29.TabIndex = 8
        Me.Label29.Text = "Description:"
        Me.Label29.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label27
        '
        Me.Label27.Location = New System.Drawing.Point(86, 296)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(130, 13)
        Me.Label27.TabIndex = 8
        Me.Label27.Text = "Name:"
        Me.Label27.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label25
        '
        Me.Label25.Location = New System.Drawing.Point(86, 264)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(130, 13)
        Me.Label25.TabIndex = 8
        Me.Label25.Text = "Version:"
        Me.Label25.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label15
        '
        Me.Label15.Location = New System.Drawing.Point(86, 72)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(130, 13)
        Me.Label15.TabIndex = 8
        Me.Label15.Text = "Image file:"
        Me.Label15.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'imgFormat
        '
        Me.imgFormat.Location = New System.Drawing.Point(610, 360)
        Me.imgFormat.Name = "imgFormat"
        Me.imgFormat.Size = New System.Drawing.Size(281, 13)
        Me.imgFormat.TabIndex = 10
        Me.imgFormat.Text = "imgFormat"
        '
        'imgModification
        '
        Me.imgModification.Location = New System.Drawing.Point(610, 246)
        Me.imgModification.Name = "imgModification"
        Me.imgModification.Size = New System.Drawing.Size(281, 13)
        Me.imgModification.TabIndex = 10
        Me.imgModification.Text = "imgModification"
        '
        'imgCreation
        '
        Me.imgCreation.Location = New System.Drawing.Point(610, 230)
        Me.imgCreation.Name = "imgCreation"
        Me.imgCreation.Size = New System.Drawing.Size(281, 13)
        Me.imgCreation.TabIndex = 10
        Me.imgCreation.Text = "imgCreation"
        '
        'imgFiles
        '
        Me.imgFiles.Location = New System.Drawing.Point(610, 214)
        Me.imgFiles.Name = "imgFiles"
        Me.imgFiles.Size = New System.Drawing.Size(281, 13)
        Me.imgFiles.TabIndex = 10
        Me.imgFiles.Text = "imgFiles"
        '
        'imgDirs
        '
        Me.imgDirs.Location = New System.Drawing.Point(610, 198)
        Me.imgDirs.Name = "imgDirs"
        Me.imgDirs.Size = New System.Drawing.Size(281, 13)
        Me.imgDirs.TabIndex = 10
        Me.imgDirs.Text = "imgDirs"
        '
        'imgSysRoot
        '
        Me.imgSysRoot.Location = New System.Drawing.Point(610, 182)
        Me.imgSysRoot.Name = "imgSysRoot"
        Me.imgSysRoot.Size = New System.Drawing.Size(281, 13)
        Me.imgSysRoot.TabIndex = 10
        Me.imgSysRoot.Text = "imgSysRoot"
        '
        'imgPSuite
        '
        Me.imgPSuite.Location = New System.Drawing.Point(610, 166)
        Me.imgPSuite.Name = "imgPSuite"
        Me.imgPSuite.Size = New System.Drawing.Size(281, 13)
        Me.imgPSuite.TabIndex = 10
        Me.imgPSuite.Text = "imgPSuite"
        '
        'imgPType
        '
        Me.imgPType.Location = New System.Drawing.Point(610, 150)
        Me.imgPType.Name = "imgPType"
        Me.imgPType.Size = New System.Drawing.Size(281, 13)
        Me.imgPType.TabIndex = 10
        Me.imgPType.Text = "imgPType"
        '
        'imgEdition
        '
        Me.imgEdition.AutoEllipsis = True
        Me.imgEdition.Location = New System.Drawing.Point(610, 134)
        Me.imgEdition.Name = "imgEdition"
        Me.imgEdition.Size = New System.Drawing.Size(281, 13)
        Me.imgEdition.TabIndex = 10
        Me.imgEdition.Text = "imgEdition"
        '
        'imgSPLvl
        '
        Me.imgSPLvl.Location = New System.Drawing.Point(610, 118)
        Me.imgSPLvl.Name = "imgSPLvl"
        Me.imgSPLvl.Size = New System.Drawing.Size(281, 13)
        Me.imgSPLvl.TabIndex = 10
        Me.imgSPLvl.Text = "imgSPLvl"
        '
        'imgSPBuild
        '
        Me.imgSPBuild.Location = New System.Drawing.Point(610, 102)
        Me.imgSPBuild.Name = "imgSPBuild"
        Me.imgSPBuild.Size = New System.Drawing.Size(281, 13)
        Me.imgSPBuild.TabIndex = 10
        Me.imgSPBuild.Text = "imgSPBuild"
        '
        'imgHal
        '
        Me.imgHal.Location = New System.Drawing.Point(610, 72)
        Me.imgHal.Name = "imgHal"
        Me.imgHal.Size = New System.Drawing.Size(281, 27)
        Me.imgHal.TabIndex = 10
        Me.imgHal.Text = "imgHal"
        '
        'imgMountDir
        '
        Me.imgMountDir.Location = New System.Drawing.Point(222, 168)
        Me.imgMountDir.Name = "imgMountDir"
        Me.imgMountDir.Size = New System.Drawing.Size(172, 72)
        Me.imgMountDir.TabIndex = 9
        Me.imgMountDir.Text = "imgMountDir"
        '
        'imgArch
        '
        Me.imgArch.Location = New System.Drawing.Point(222, 402)
        Me.imgArch.Name = "imgArch"
        Me.imgArch.Size = New System.Drawing.Size(172, 13)
        Me.imgArch.TabIndex = 10
        Me.imgArch.Text = "imgArch"
        '
        'imgWimBootStatus
        '
        Me.imgWimBootStatus.Location = New System.Drawing.Point(222, 386)
        Me.imgWimBootStatus.Name = "imgWimBootStatus"
        Me.imgWimBootStatus.Size = New System.Drawing.Size(172, 13)
        Me.imgWimBootStatus.TabIndex = 10
        Me.imgWimBootStatus.Text = "imgWimBootStatus"
        '
        'imgMountedStatus
        '
        Me.imgMountedStatus.Location = New System.Drawing.Point(222, 244)
        Me.imgMountedStatus.Name = "imgMountedStatus"
        Me.imgMountedStatus.Size = New System.Drawing.Size(114, 13)
        Me.imgMountedStatus.TabIndex = 10
        Me.imgMountedStatus.Text = "imgMountedStatus"
        '
        'imgSize
        '
        Me.imgSize.Location = New System.Drawing.Point(222, 356)
        Me.imgSize.Name = "imgSize"
        Me.imgSize.Size = New System.Drawing.Size(172, 28)
        Me.imgSize.TabIndex = 11
        Me.imgSize.Text = "imgSize"
        '
        'imgMountedDesc
        '
        Me.imgMountedDesc.AutoEllipsis = True
        Me.imgMountedDesc.Location = New System.Drawing.Point(222, 326)
        Me.imgMountedDesc.Name = "imgMountedDesc"
        Me.imgMountedDesc.Size = New System.Drawing.Size(172, 28)
        Me.imgMountedDesc.TabIndex = 11
        Me.imgMountedDesc.Text = "imgMountedDesc"
        Me.imgMountedDesc.UseMnemonic = False
        '
        'imgMountedName
        '
        Me.imgMountedName.AutoEllipsis = True
        Me.imgMountedName.Location = New System.Drawing.Point(222, 296)
        Me.imgMountedName.Name = "imgMountedName"
        Me.imgMountedName.Size = New System.Drawing.Size(172, 28)
        Me.imgMountedName.TabIndex = 11
        Me.imgMountedName.Text = "imgMountedName"
        Me.imgMountedName.UseMnemonic = False
        '
        'imgVersion
        '
        Me.imgVersion.Location = New System.Drawing.Point(222, 264)
        Me.imgVersion.Name = "imgVersion"
        Me.imgVersion.Size = New System.Drawing.Size(218, 28)
        Me.imgVersion.TabIndex = 11
        Me.imgVersion.Text = "imgVersion"
        '
        'imgIndex
        '
        Me.imgIndex.Location = New System.Drawing.Point(222, 148)
        Me.imgIndex.Name = "imgIndex"
        Me.imgIndex.Size = New System.Drawing.Size(172, 13)
        Me.imgIndex.TabIndex = 10
        Me.imgIndex.Text = "imgIndex"
        '
        'imgName
        '
        Me.imgName.Location = New System.Drawing.Point(222, 72)
        Me.imgName.Name = "imgName"
        Me.imgName.Size = New System.Drawing.Size(172, 72)
        Me.imgName.TabIndex = 11
        Me.imgName.Text = "imgName"
        '
        'Label19
        '
        Me.Label19.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold)
        Me.Label19.Location = New System.Drawing.Point(510, 48)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(196, 13)
        Me.Label19.TabIndex = 12
        Me.Label19.Text = "imgStatus"
        '
        'Label20
        '
        Me.Label20.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold)
        Me.Label20.Location = New System.Drawing.Point(225, 48)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(279, 13)
        Me.Label20.TabIndex = 13
        Me.Label20.Text = "Image present on project?"
        Me.Label20.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Panel2
        '
        Me.Panel2.Controls.Add(Me.Label3)
        Me.Panel2.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel2.Location = New System.Drawing.Point(3, 3)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(970, 32)
        Me.Panel2.TabIndex = 0
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(8, 8)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(334, 13)
        Me.Label3.TabIndex = 1
        Me.Label3.Text = "View mounted image properties, such as name, description, or index"
        '
        'Label4
        '
        Me.Label4.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(16, 588)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(261, 13)
        Me.Label4.TabIndex = 5
        Me.Label4.Text = "Getting project and image information. Please wait..."
        '
        'ProjProperties
        '
        Me.AcceptButton = Me.OK_Button
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.CancelButton = Me.Cancel_Button
        Me.ClientSize = New System.Drawing.Size(1008, 621)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.TabControl1)
        Me.Controls.Add(Me.Win10Title)
        Me.Controls.Add(Me.TableLayoutPanel1)
        Me.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "ProjProperties"
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "Project properties"
        Me.TableLayoutPanel1.ResumeLayout(False)
        Me.Win10Title.ResumeLayout(False)
        Me.Win10Title.PerformLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabControl1.ResumeLayout(False)
        Me.TabPage1.ResumeLayout(False)
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.TabPage2.ResumeLayout(False)
        Me.TabPage2.PerformLayout()
        Me.Panel3.ResumeLayout(False)
        Me.Panel3.PerformLayout()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents TableLayoutPanel1 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents OK_Button As System.Windows.Forms.Button
    Friend WithEvents Cancel_Button As System.Windows.Forms.Button
    Friend WithEvents Win10Title As System.Windows.Forms.Panel
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents TabControl1 As System.Windows.Forms.TabControl
    Friend WithEvents TabPage1 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage2 As System.Windows.Forms.TabPage
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents RWRemountBtn As System.Windows.Forms.Button
    Friend WithEvents imgLangText As System.Windows.Forms.TextBox
    Friend WithEvents Label62 As System.Windows.Forms.Label
    Friend WithEvents imgRW As System.Windows.Forms.Label
    Friend WithEvents Panel3 As System.Windows.Forms.Panel
    Friend WithEvents PictureBox2 As System.Windows.Forms.PictureBox
    Friend WithEvents LinkLabel2 As System.Windows.Forms.LinkLabel
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents Label58 As System.Windows.Forms.Label
    Friend WithEvents Label60 As System.Windows.Forms.Label
    Friend WithEvents Label57 As System.Windows.Forms.Label
    Friend WithEvents Label55 As System.Windows.Forms.Label
    Friend WithEvents Label53 As System.Windows.Forms.Label
    Friend WithEvents Label51 As System.Windows.Forms.Label
    Friend WithEvents Label49 As System.Windows.Forms.Label
    Friend WithEvents Label47 As System.Windows.Forms.Label
    Friend WithEvents Label45 As System.Windows.Forms.Label
    Friend WithEvents Label43 As System.Windows.Forms.Label
    Friend WithEvents Label41 As System.Windows.Forms.Label
    Friend WithEvents Label39 As System.Windows.Forms.Label
    Friend WithEvents Label37 As System.Windows.Forms.Label
    Friend WithEvents Label35 As System.Windows.Forms.Label
    Friend WithEvents Label33 As System.Windows.Forms.Label
    Friend WithEvents Label22 As System.Windows.Forms.Label
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents Label31 As System.Windows.Forms.Label
    Friend WithEvents Label29 As System.Windows.Forms.Label
    Friend WithEvents Label27 As System.Windows.Forms.Label
    Friend WithEvents Label25 As System.Windows.Forms.Label
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents imgFormat As System.Windows.Forms.Label
    Friend WithEvents imgModification As System.Windows.Forms.Label
    Friend WithEvents imgCreation As System.Windows.Forms.Label
    Friend WithEvents imgFiles As System.Windows.Forms.Label
    Friend WithEvents imgDirs As System.Windows.Forms.Label
    Friend WithEvents imgSysRoot As System.Windows.Forms.Label
    Friend WithEvents imgPSuite As System.Windows.Forms.Label
    Friend WithEvents imgPType As System.Windows.Forms.Label
    Friend WithEvents imgEdition As System.Windows.Forms.Label
    Friend WithEvents imgSPLvl As System.Windows.Forms.Label
    Friend WithEvents imgSPBuild As System.Windows.Forms.Label
    Friend WithEvents imgHal As System.Windows.Forms.Label
    Friend WithEvents imgMountDir As System.Windows.Forms.Label
    Friend WithEvents imgArch As System.Windows.Forms.Label
    Friend WithEvents imgWimBootStatus As System.Windows.Forms.Label
    Friend WithEvents imgMountedStatus As System.Windows.Forms.Label
    Friend WithEvents imgSize As System.Windows.Forms.Label
    Friend WithEvents imgMountedDesc As System.Windows.Forms.Label
    Friend WithEvents imgMountedName As System.Windows.Forms.Label
    Friend WithEvents imgVersion As System.Windows.Forms.Label
    Friend WithEvents imgIndex As System.Windows.Forms.Label
    Friend WithEvents imgName As System.Windows.Forms.Label
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents RecoverButton As System.Windows.Forms.Button
    Friend WithEvents RemountImgBtn As System.Windows.Forms.Button
    Friend WithEvents LanguageList As System.Windows.Forms.ListBox

End Class
