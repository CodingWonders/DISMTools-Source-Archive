﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class GetPkgInfoDlg
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Win10Title = New System.Windows.Forms.Panel()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.MenuPanel = New System.Windows.Forms.Panel()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.PictureBox3 = New System.Windows.Forms.PictureBox()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.InstalledPackageLink = New System.Windows.Forms.LinkLabel()
        Me.PackageFileLink = New System.Windows.Forms.LinkLabel()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.PackageInfoPanel = New System.Windows.Forms.Panel()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.PackageContainerPanel = New System.Windows.Forms.Panel()
        Me.InfoFromInstalledPkgsPanel = New System.Windows.Forms.Panel()
        Me.SplitContainer2 = New System.Windows.Forms.SplitContainer()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.ListBox2 = New System.Windows.Forms.ListBox()
        Me.SearchPanel = New System.Windows.Forms.Panel()
        Me.Panel6 = New System.Windows.Forms.Panel()
        Me.SearchBox1 = New DISMTools.SearchBox()
        Me.SearchPic = New System.Windows.Forms.PictureBox()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.Panel4 = New System.Windows.Forms.Panel()
        Me.FlowLayoutPanel3 = New System.Windows.Forms.FlowLayoutPanel()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.Label35 = New System.Windows.Forms.Label()
        Me.Label31 = New System.Windows.Forms.Label()
        Me.Label32 = New System.Windows.Forms.Label()
        Me.Label41 = New System.Windows.Forms.Label()
        Me.Label40 = New System.Windows.Forms.Label()
        Me.Label43 = New System.Windows.Forms.Label()
        Me.Label42 = New System.Windows.Forms.Label()
        Me.Label47 = New System.Windows.Forms.Label()
        Me.Label46 = New System.Windows.Forms.Label()
        Me.Label33 = New System.Windows.Forms.Label()
        Me.Label34 = New System.Windows.Forms.Label()
        Me.Label28 = New System.Windows.Forms.Label()
        Me.Label27 = New System.Windows.Forms.Label()
        Me.Label30 = New System.Windows.Forms.Label()
        Me.Label29 = New System.Windows.Forms.Label()
        Me.Label39 = New System.Windows.Forms.Label()
        Me.Label38 = New System.Windows.Forms.Label()
        Me.Label45 = New System.Windows.Forms.Label()
        Me.Label44 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.Label48 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label50 = New System.Windows.Forms.Label()
        Me.Label49 = New System.Windows.Forms.Label()
        Me.Label52 = New System.Windows.Forms.Label()
        Me.Label51 = New System.Windows.Forms.Label()
        Me.Label54 = New System.Windows.Forms.Label()
        Me.Label53 = New System.Windows.Forms.Label()
        Me.Label61 = New System.Windows.Forms.Label()
        Me.Label56 = New System.Windows.Forms.Label()
        Me.Label58 = New System.Windows.Forms.Label()
        Me.Label57 = New System.Windows.Forms.Label()
        Me.CPropViewer = New System.Windows.Forms.Panel()
        Me.TableLayoutPanel1 = New System.Windows.Forms.TableLayoutPanel()
        Me.cPropPathView = New System.Windows.Forms.TreeView()
        Me.Panel8 = New System.Windows.Forms.Panel()
        Me.cPropValue = New System.Windows.Forms.TextBox()
        Me.cPropName = New System.Windows.Forms.Label()
        Me.Label60 = New System.Windows.Forms.Label()
        Me.Label59 = New System.Windows.Forms.Label()
        Me.Label55 = New System.Windows.Forms.Label()
        Me.Panel5 = New System.Windows.Forms.Panel()
        Me.Label36 = New System.Windows.Forms.Label()
        Me.Panel7 = New System.Windows.Forms.Panel()
        Me.Label37 = New System.Windows.Forms.Label()
        Me.FlowLayoutPanel4 = New System.Windows.Forms.FlowLayoutPanel()
        Me.InfoFromPackageFilesPanel = New System.Windows.Forms.Panel()
        Me.SplitContainer1 = New System.Windows.Forms.SplitContainer()
        Me.PkgFilesPanel = New System.Windows.Forms.Panel()
        Me.ListBox1 = New System.Windows.Forms.ListBox()
        Me.TableLayoutPanel2 = New System.Windows.Forms.TableLayoutPanel()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.PackageFileContainerPanel = New System.Windows.Forms.Panel()
        Me.PackageFileInfoPanel = New System.Windows.Forms.Panel()
        Me.FlowLayoutPanel2 = New System.Windows.Forms.FlowLayoutPanel()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.Label62 = New System.Windows.Forms.Label()
        Me.Label63 = New System.Windows.Forms.Label()
        Me.Label64 = New System.Windows.Forms.Label()
        Me.Label65 = New System.Windows.Forms.Label()
        Me.Label66 = New System.Windows.Forms.Label()
        Me.Label67 = New System.Windows.Forms.Label()
        Me.Label68 = New System.Windows.Forms.Label()
        Me.Label69 = New System.Windows.Forms.Label()
        Me.Label70 = New System.Windows.Forms.Label()
        Me.Label71 = New System.Windows.Forms.Label()
        Me.Label72 = New System.Windows.Forms.Label()
        Me.Label73 = New System.Windows.Forms.Label()
        Me.Label74 = New System.Windows.Forms.Label()
        Me.Label75 = New System.Windows.Forms.Label()
        Me.Label76 = New System.Windows.Forms.Label()
        Me.Label77 = New System.Windows.Forms.Label()
        Me.Label78 = New System.Windows.Forms.Label()
        Me.Label79 = New System.Windows.Forms.Label()
        Me.Label80 = New System.Windows.Forms.Label()
        Me.Label81 = New System.Windows.Forms.Label()
        Me.Label82 = New System.Windows.Forms.Label()
        Me.Label83 = New System.Windows.Forms.Label()
        Me.Label84 = New System.Windows.Forms.Label()
        Me.Label85 = New System.Windows.Forms.Label()
        Me.Label86 = New System.Windows.Forms.Label()
        Me.Label87 = New System.Windows.Forms.Label()
        Me.Label88 = New System.Windows.Forms.Label()
        Me.Label89 = New System.Windows.Forms.Label()
        Me.Label90 = New System.Windows.Forms.Label()
        Me.Label91 = New System.Windows.Forms.Label()
        Me.Label92 = New System.Windows.Forms.Label()
        Me.Label93 = New System.Windows.Forms.Label()
        Me.Label94 = New System.Windows.Forms.Label()
        Me.Label95 = New System.Windows.Forms.Label()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.NoPkgPanel = New System.Windows.Forms.Panel()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.FlowLayoutPanel1 = New System.Windows.Forms.FlowLayoutPanel()
        Me.LinkLabel1 = New System.Windows.Forms.LinkLabel()
        Me.OpenFileDialog1 = New System.Windows.Forms.OpenFileDialog()
        Me.Win10Title.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.MenuPanel.SuspendLayout()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.PackageInfoPanel.SuspendLayout()
        Me.PackageContainerPanel.SuspendLayout()
        Me.InfoFromInstalledPkgsPanel.SuspendLayout()
        CType(Me.SplitContainer2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SplitContainer2.Panel1.SuspendLayout()
        Me.SplitContainer2.Panel2.SuspendLayout()
        Me.SplitContainer2.SuspendLayout()
        Me.Panel2.SuspendLayout()
        Me.SearchPanel.SuspendLayout()
        Me.Panel6.SuspendLayout()
        CType(Me.SearchPic, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel3.SuspendLayout()
        Me.Panel4.SuspendLayout()
        Me.FlowLayoutPanel3.SuspendLayout()
        Me.CPropViewer.SuspendLayout()
        Me.TableLayoutPanel1.SuspendLayout()
        Me.Panel8.SuspendLayout()
        Me.Panel5.SuspendLayout()
        Me.Panel7.SuspendLayout()
        Me.InfoFromPackageFilesPanel.SuspendLayout()
        CType(Me.SplitContainer1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SplitContainer1.Panel1.SuspendLayout()
        Me.SplitContainer1.Panel2.SuspendLayout()
        Me.SplitContainer1.SuspendLayout()
        Me.PkgFilesPanel.SuspendLayout()
        Me.TableLayoutPanel2.SuspendLayout()
        Me.PackageFileContainerPanel.SuspendLayout()
        Me.PackageFileInfoPanel.SuspendLayout()
        Me.FlowLayoutPanel2.SuspendLayout()
        Me.Panel1.SuspendLayout()
        Me.NoPkgPanel.SuspendLayout()
        Me.SuspendLayout()
        '
        'Win10Title
        '
        Me.Win10Title.BackColor = System.Drawing.Color.White
        Me.Win10Title.Controls.Add(Me.PictureBox1)
        Me.Win10Title.Controls.Add(Me.Label1)
        Me.Win10Title.Dock = System.Windows.Forms.DockStyle.Top
        Me.Win10Title.Location = New System.Drawing.Point(0, 0)
        Me.Win10Title.Name = "Win10Title"
        Me.Win10Title.Size = New System.Drawing.Size(1008, 48)
        Me.Win10Title.TabIndex = 8
        Me.Win10Title.Visible = False
        '
        'PictureBox1
        '
        Me.PictureBox1.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.PictureBox1.Image = Global.DISMTools.My.Resources.Resources.get_pkg_info
        Me.PictureBox1.Location = New System.Drawing.Point(964, 8)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(32, 32)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.PictureBox1.TabIndex = 1
        Me.PictureBox1.TabStop = False
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Segoe UI", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(12, 9)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(242, 30)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Get package information"
        '
        'MenuPanel
        '
        Me.MenuPanel.Controls.Add(Me.Label4)
        Me.MenuPanel.Controls.Add(Me.Label3)
        Me.MenuPanel.Controls.Add(Me.PictureBox3)
        Me.MenuPanel.Controls.Add(Me.PictureBox2)
        Me.MenuPanel.Controls.Add(Me.InstalledPackageLink)
        Me.MenuPanel.Controls.Add(Me.PackageFileLink)
        Me.MenuPanel.Controls.Add(Me.Label2)
        Me.MenuPanel.Dock = System.Windows.Forms.DockStyle.Fill
        Me.MenuPanel.Location = New System.Drawing.Point(0, 48)
        Me.MenuPanel.Name = "MenuPanel"
        Me.MenuPanel.Size = New System.Drawing.Size(1008, 513)
        Me.MenuPanel.TabIndex = 9
        '
        'Label4
        '
        Me.Label4.AutoEllipsis = True
        Me.Label4.Location = New System.Drawing.Point(129, 231)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(791, 83)
        Me.Label4.TabIndex = 3
        Me.Label4.Text = "Click here to get information about packages that you want to add to the Windows " & _
    "image you're servicing before proceeding with the package addition process"
        '
        'Label3
        '
        Me.Label3.AutoEllipsis = True
        Me.Label3.Location = New System.Drawing.Point(129, 93)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(791, 83)
        Me.Label3.TabIndex = 3
        Me.Label3.Text = "Click here to get information about packages that you've installed or that came w" & _
    "ith the Windows image you're servicing"
        '
        'PictureBox3
        '
        Me.PictureBox3.Image = Global.DISMTools.My.Resources.Resources.info_from_pkg_file
        Me.PictureBox3.Location = New System.Drawing.Point(74, 214)
        Me.PictureBox3.Name = "PictureBox3"
        Me.PictureBox3.Size = New System.Drawing.Size(48, 48)
        Me.PictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.PictureBox3.TabIndex = 2
        Me.PictureBox3.TabStop = False
        '
        'PictureBox2
        '
        Me.PictureBox2.Image = Global.DISMTools.My.Resources.Resources.pkg_info_from_image
        Me.PictureBox2.Location = New System.Drawing.Point(74, 76)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(48, 48)
        Me.PictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.PictureBox2.TabIndex = 2
        Me.PictureBox2.TabStop = False
        '
        'InstalledPackageLink
        '
        Me.InstalledPackageLink.AutoSize = True
        Me.InstalledPackageLink.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.InstalledPackageLink.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline
        Me.InstalledPackageLink.LinkColor = System.Drawing.Color.DodgerBlue
        Me.InstalledPackageLink.Location = New System.Drawing.Point(128, 76)
        Me.InstalledPackageLink.Name = "InstalledPackageLink"
        Me.InstalledPackageLink.Size = New System.Drawing.Size(366, 13)
        Me.InstalledPackageLink.TabIndex = 1
        Me.InstalledPackageLink.TabStop = True
        Me.InstalledPackageLink.Text = "I want to get information about installed packages in the image"
        '
        'PackageFileLink
        '
        Me.PackageFileLink.AutoSize = True
        Me.PackageFileLink.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.PackageFileLink.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline
        Me.PackageFileLink.LinkColor = System.Drawing.Color.DodgerBlue
        Me.PackageFileLink.Location = New System.Drawing.Point(128, 214)
        Me.PackageFileLink.Name = "PackageFileLink"
        Me.PackageFileLink.Size = New System.Drawing.Size(262, 13)
        Me.PackageFileLink.TabIndex = 1
        Me.PackageFileLink.TabStop = True
        Me.PackageFileLink.Text = "I want to get information about package files"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(17, 12)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(221, 13)
        Me.Label2.TabIndex = 0
        Me.Label2.Text = "What do you want to get information about?"
        '
        'PackageInfoPanel
        '
        Me.PackageInfoPanel.Controls.Add(Me.Button4)
        Me.PackageInfoPanel.Controls.Add(Me.Label5)
        Me.PackageInfoPanel.Controls.Add(Me.PackageContainerPanel)
        Me.PackageInfoPanel.Controls.Add(Me.LinkLabel1)
        Me.PackageInfoPanel.Dock = System.Windows.Forms.DockStyle.Fill
        Me.PackageInfoPanel.Location = New System.Drawing.Point(0, 48)
        Me.PackageInfoPanel.Name = "PackageInfoPanel"
        Me.PackageInfoPanel.Size = New System.Drawing.Size(1008, 513)
        Me.PackageInfoPanel.TabIndex = 10
        Me.PackageInfoPanel.Visible = False
        '
        'Button4
        '
        Me.Button4.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button4.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.Button4.Location = New System.Drawing.Point(848, 450)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(96, 23)
        Me.Button4.TabIndex = 11
        Me.Button4.Text = "Save..."
        Me.Button4.UseVisualStyleBackColor = True
        '
        'Label5
        '
        Me.Label5.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Label5.AutoEllipsis = True
        Me.Label5.Location = New System.Drawing.Point(20, 460)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(822, 44)
        Me.Label5.TabIndex = 4
        Me.Label5.Text = "Status"
        '
        'PackageContainerPanel
        '
        Me.PackageContainerPanel.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.PackageContainerPanel.Controls.Add(Me.InfoFromInstalledPkgsPanel)
        Me.PackageContainerPanel.Controls.Add(Me.InfoFromPackageFilesPanel)
        Me.PackageContainerPanel.Location = New System.Drawing.Point(64, 68)
        Me.PackageContainerPanel.Name = "PackageContainerPanel"
        Me.PackageContainerPanel.Size = New System.Drawing.Size(880, 376)
        Me.PackageContainerPanel.TabIndex = 3
        '
        'InfoFromInstalledPkgsPanel
        '
        Me.InfoFromInstalledPkgsPanel.Controls.Add(Me.SplitContainer2)
        Me.InfoFromInstalledPkgsPanel.Dock = System.Windows.Forms.DockStyle.Fill
        Me.InfoFromInstalledPkgsPanel.Location = New System.Drawing.Point(0, 0)
        Me.InfoFromInstalledPkgsPanel.Name = "InfoFromInstalledPkgsPanel"
        Me.InfoFromInstalledPkgsPanel.Size = New System.Drawing.Size(880, 376)
        Me.InfoFromInstalledPkgsPanel.TabIndex = 0
        Me.InfoFromInstalledPkgsPanel.Visible = False
        '
        'SplitContainer2
        '
        Me.SplitContainer2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SplitContainer2.IsSplitterFixed = True
        Me.SplitContainer2.Location = New System.Drawing.Point(0, 0)
        Me.SplitContainer2.Name = "SplitContainer2"
        '
        'SplitContainer2.Panel1
        '
        Me.SplitContainer2.Panel1.Controls.Add(Me.Panel2)
        Me.SplitContainer2.Panel1.Controls.Add(Me.SearchPanel)
        '
        'SplitContainer2.Panel2
        '
        Me.SplitContainer2.Panel2.Controls.Add(Me.Panel3)
        Me.SplitContainer2.Panel2.Controls.Add(Me.FlowLayoutPanel4)
        Me.SplitContainer2.Size = New System.Drawing.Size(880, 376)
        Me.SplitContainer2.SplitterDistance = 440
        Me.SplitContainer2.TabIndex = 1
        '
        'Panel2
        '
        Me.Panel2.Controls.Add(Me.ListBox2)
        Me.Panel2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel2.Location = New System.Drawing.Point(0, 0)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(440, 352)
        Me.Panel2.TabIndex = 1
        '
        'ListBox2
        '
        Me.ListBox2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.ListBox2.FormattingEnabled = True
        Me.ListBox2.IntegralHeight = False
        Me.ListBox2.Location = New System.Drawing.Point(0, 0)
        Me.ListBox2.Name = "ListBox2"
        Me.ListBox2.ScrollAlwaysVisible = True
        Me.ListBox2.Size = New System.Drawing.Size(440, 352)
        Me.ListBox2.TabIndex = 0
        '
        'SearchPanel
        '
        Me.SearchPanel.Controls.Add(Me.Panel6)
        Me.SearchPanel.Controls.Add(Me.SearchPic)
        Me.SearchPanel.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.SearchPanel.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.SearchPanel.Location = New System.Drawing.Point(0, 352)
        Me.SearchPanel.Name = "SearchPanel"
        Me.SearchPanel.Size = New System.Drawing.Size(440, 24)
        Me.SearchPanel.TabIndex = 8
        '
        'Panel6
        '
        Me.Panel6.Controls.Add(Me.SearchBox1)
        Me.Panel6.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel6.Location = New System.Drawing.Point(24, 0)
        Me.Panel6.Name = "Panel6"
        Me.Panel6.Size = New System.Drawing.Size(416, 24)
        Me.Panel6.TabIndex = 3
        '
        'SearchBox1
        '
        Me.SearchBox1.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.SearchBox1.cueBanner = "Type here to search for a package..."
        Me.SearchBox1.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.SearchBox1.Location = New System.Drawing.Point(8, 3)
        Me.SearchBox1.Name = "SearchBox1"
        Me.SearchBox1.Size = New System.Drawing.Size(405, 18)
        Me.SearchBox1.TabIndex = 1
        '
        'SearchPic
        '
        Me.SearchPic.Dock = System.Windows.Forms.DockStyle.Left
        Me.SearchPic.Image = Global.DISMTools.My.Resources.Resources.search_light
        Me.SearchPic.Location = New System.Drawing.Point(0, 0)
        Me.SearchPic.Name = "SearchPic"
        Me.SearchPic.Size = New System.Drawing.Size(24, 24)
        Me.SearchPic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage
        Me.SearchPic.TabIndex = 2
        Me.SearchPic.TabStop = False
        '
        'Panel3
        '
        Me.Panel3.Controls.Add(Me.Panel4)
        Me.Panel3.Controls.Add(Me.Panel7)
        Me.Panel3.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel3.Location = New System.Drawing.Point(0, 0)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(436, 376)
        Me.Panel3.TabIndex = 1
        '
        'Panel4
        '
        Me.Panel4.Controls.Add(Me.FlowLayoutPanel3)
        Me.Panel4.Controls.Add(Me.Panel5)
        Me.Panel4.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel4.Location = New System.Drawing.Point(0, 0)
        Me.Panel4.Name = "Panel4"
        Me.Panel4.Size = New System.Drawing.Size(436, 376)
        Me.Panel4.TabIndex = 2
        Me.Panel4.Visible = False
        '
        'FlowLayoutPanel3
        '
        Me.FlowLayoutPanel3.AutoScroll = True
        Me.FlowLayoutPanel3.Controls.Add(Me.Label22)
        Me.FlowLayoutPanel3.Controls.Add(Me.Label23)
        Me.FlowLayoutPanel3.Controls.Add(Me.Label24)
        Me.FlowLayoutPanel3.Controls.Add(Me.Label25)
        Me.FlowLayoutPanel3.Controls.Add(Me.Label26)
        Me.FlowLayoutPanel3.Controls.Add(Me.Label35)
        Me.FlowLayoutPanel3.Controls.Add(Me.Label31)
        Me.FlowLayoutPanel3.Controls.Add(Me.Label32)
        Me.FlowLayoutPanel3.Controls.Add(Me.Label41)
        Me.FlowLayoutPanel3.Controls.Add(Me.Label40)
        Me.FlowLayoutPanel3.Controls.Add(Me.Label43)
        Me.FlowLayoutPanel3.Controls.Add(Me.Label42)
        Me.FlowLayoutPanel3.Controls.Add(Me.Label47)
        Me.FlowLayoutPanel3.Controls.Add(Me.Label46)
        Me.FlowLayoutPanel3.Controls.Add(Me.Label33)
        Me.FlowLayoutPanel3.Controls.Add(Me.Label34)
        Me.FlowLayoutPanel3.Controls.Add(Me.Label28)
        Me.FlowLayoutPanel3.Controls.Add(Me.Label27)
        Me.FlowLayoutPanel3.Controls.Add(Me.Label30)
        Me.FlowLayoutPanel3.Controls.Add(Me.Label29)
        Me.FlowLayoutPanel3.Controls.Add(Me.Label39)
        Me.FlowLayoutPanel3.Controls.Add(Me.Label38)
        Me.FlowLayoutPanel3.Controls.Add(Me.Label45)
        Me.FlowLayoutPanel3.Controls.Add(Me.Label44)
        Me.FlowLayoutPanel3.Controls.Add(Me.Label14)
        Me.FlowLayoutPanel3.Controls.Add(Me.Label15)
        Me.FlowLayoutPanel3.Controls.Add(Me.Label16)
        Me.FlowLayoutPanel3.Controls.Add(Me.Label21)
        Me.FlowLayoutPanel3.Controls.Add(Me.Label48)
        Me.FlowLayoutPanel3.Controls.Add(Me.Label13)
        Me.FlowLayoutPanel3.Controls.Add(Me.Label50)
        Me.FlowLayoutPanel3.Controls.Add(Me.Label49)
        Me.FlowLayoutPanel3.Controls.Add(Me.Label52)
        Me.FlowLayoutPanel3.Controls.Add(Me.Label51)
        Me.FlowLayoutPanel3.Controls.Add(Me.Label54)
        Me.FlowLayoutPanel3.Controls.Add(Me.Label53)
        Me.FlowLayoutPanel3.Controls.Add(Me.Label61)
        Me.FlowLayoutPanel3.Controls.Add(Me.Label56)
        Me.FlowLayoutPanel3.Controls.Add(Me.Label58)
        Me.FlowLayoutPanel3.Controls.Add(Me.Label57)
        Me.FlowLayoutPanel3.Controls.Add(Me.CPropViewer)
        Me.FlowLayoutPanel3.Controls.Add(Me.Label60)
        Me.FlowLayoutPanel3.Controls.Add(Me.Label59)
        Me.FlowLayoutPanel3.Controls.Add(Me.Label55)
        Me.FlowLayoutPanel3.Dock = System.Windows.Forms.DockStyle.Fill
        Me.FlowLayoutPanel3.FlowDirection = System.Windows.Forms.FlowDirection.TopDown
        Me.FlowLayoutPanel3.Location = New System.Drawing.Point(0, 36)
        Me.FlowLayoutPanel3.Name = "FlowLayoutPanel3"
        Me.FlowLayoutPanel3.Padding = New System.Windows.Forms.Padding(4, 6, 0, 0)
        Me.FlowLayoutPanel3.Size = New System.Drawing.Size(436, 340)
        Me.FlowLayoutPanel3.TabIndex = 1
        Me.FlowLayoutPanel3.WrapContents = False
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.Location = New System.Drawing.Point(7, 6)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(80, 13)
        Me.Label22.TabIndex = 0
        Me.Label22.Text = "Package name:"
        '
        'Label23
        '
        Me.Label23.AutoEllipsis = True
        Me.Label23.AutoSize = True
        Me.Label23.Location = New System.Drawing.Point(7, 19)
        Me.Label23.Name = "Label23"
        Me.Label23.Padding = New System.Windows.Forms.Padding(0, 2, 0, 0)
        Me.Label23.Size = New System.Drawing.Size(38, 15)
        Me.Label23.TabIndex = 0
        Me.Label23.Text = "Label8"
        Me.Label23.UseMnemonic = False
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.Location = New System.Drawing.Point(7, 34)
        Me.Label24.Name = "Label24"
        Me.Label24.Padding = New System.Windows.Forms.Padding(0, 4, 0, 0)
        Me.Label24.Size = New System.Drawing.Size(114, 17)
        Me.Label24.TabIndex = 0
        Me.Label24.Text = "Is package applicable?"
        '
        'Label25
        '
        Me.Label25.AutoEllipsis = True
        Me.Label25.AutoSize = True
        Me.Label25.Location = New System.Drawing.Point(7, 51)
        Me.Label25.Name = "Label25"
        Me.Label25.Padding = New System.Windows.Forms.Padding(0, 2, 0, 0)
        Me.Label25.Size = New System.Drawing.Size(38, 15)
        Me.Label25.TabIndex = 0
        Me.Label25.Text = "Label8"
        Me.Label25.UseMnemonic = False
        '
        'Label26
        '
        Me.Label26.AutoSize = True
        Me.Label26.Location = New System.Drawing.Point(7, 66)
        Me.Label26.Name = "Label26"
        Me.Label26.Padding = New System.Windows.Forms.Padding(0, 4, 0, 0)
        Me.Label26.Size = New System.Drawing.Size(58, 17)
        Me.Label26.TabIndex = 0
        Me.Label26.Text = "Copyright:"
        '
        'Label35
        '
        Me.Label35.AutoEllipsis = True
        Me.Label35.AutoSize = True
        Me.Label35.Location = New System.Drawing.Point(7, 83)
        Me.Label35.Name = "Label35"
        Me.Label35.Padding = New System.Windows.Forms.Padding(0, 2, 0, 0)
        Me.Label35.Size = New System.Drawing.Size(38, 15)
        Me.Label35.TabIndex = 0
        Me.Label35.Text = "Label8"
        Me.Label35.UseMnemonic = False
        '
        'Label31
        '
        Me.Label31.AutoSize = True
        Me.Label31.Location = New System.Drawing.Point(7, 98)
        Me.Label31.Name = "Label31"
        Me.Label31.Padding = New System.Windows.Forms.Padding(0, 4, 0, 0)
        Me.Label31.Size = New System.Drawing.Size(56, 17)
        Me.Label31.TabIndex = 0
        Me.Label31.Text = "Company:"
        '
        'Label32
        '
        Me.Label32.AutoEllipsis = True
        Me.Label32.AutoSize = True
        Me.Label32.Location = New System.Drawing.Point(7, 115)
        Me.Label32.Name = "Label32"
        Me.Label32.Padding = New System.Windows.Forms.Padding(0, 2, 0, 0)
        Me.Label32.Size = New System.Drawing.Size(38, 15)
        Me.Label32.TabIndex = 0
        Me.Label32.Text = "Label8"
        Me.Label32.UseMnemonic = False
        '
        'Label41
        '
        Me.Label41.AutoSize = True
        Me.Label41.Location = New System.Drawing.Point(7, 130)
        Me.Label41.Name = "Label41"
        Me.Label41.Padding = New System.Windows.Forms.Padding(0, 4, 0, 0)
        Me.Label41.Size = New System.Drawing.Size(75, 17)
        Me.Label41.TabIndex = 0
        Me.Label41.Text = "Creation time:"
        '
        'Label40
        '
        Me.Label40.AutoEllipsis = True
        Me.Label40.AutoSize = True
        Me.Label40.Location = New System.Drawing.Point(7, 147)
        Me.Label40.Name = "Label40"
        Me.Label40.Padding = New System.Windows.Forms.Padding(0, 2, 0, 0)
        Me.Label40.Size = New System.Drawing.Size(38, 15)
        Me.Label40.TabIndex = 0
        Me.Label40.Text = "Label8"
        Me.Label40.UseMnemonic = False
        '
        'Label43
        '
        Me.Label43.AutoSize = True
        Me.Label43.Location = New System.Drawing.Point(7, 162)
        Me.Label43.Name = "Label43"
        Me.Label43.Padding = New System.Windows.Forms.Padding(0, 4, 0, 0)
        Me.Label43.Size = New System.Drawing.Size(64, 17)
        Me.Label43.TabIndex = 0
        Me.Label43.Text = "Description:"
        '
        'Label42
        '
        Me.Label42.AutoEllipsis = True
        Me.Label42.AutoSize = True
        Me.Label42.Location = New System.Drawing.Point(7, 179)
        Me.Label42.Name = "Label42"
        Me.Label42.Padding = New System.Windows.Forms.Padding(0, 2, 0, 0)
        Me.Label42.Size = New System.Drawing.Size(38, 15)
        Me.Label42.TabIndex = 0
        Me.Label42.Text = "Label8"
        Me.Label42.UseMnemonic = False
        '
        'Label47
        '
        Me.Label47.AutoSize = True
        Me.Label47.Location = New System.Drawing.Point(7, 194)
        Me.Label47.Name = "Label47"
        Me.Label47.Padding = New System.Windows.Forms.Padding(0, 4, 0, 0)
        Me.Label47.Size = New System.Drawing.Size(68, 17)
        Me.Label47.TabIndex = 0
        Me.Label47.Text = "Install client:"
        '
        'Label46
        '
        Me.Label46.AutoEllipsis = True
        Me.Label46.AutoSize = True
        Me.Label46.Location = New System.Drawing.Point(7, 211)
        Me.Label46.Name = "Label46"
        Me.Label46.Padding = New System.Windows.Forms.Padding(0, 2, 0, 0)
        Me.Label46.Size = New System.Drawing.Size(38, 15)
        Me.Label46.TabIndex = 0
        Me.Label46.Text = "Label8"
        Me.Label46.UseMnemonic = False
        '
        'Label33
        '
        Me.Label33.AutoSize = True
        Me.Label33.Location = New System.Drawing.Point(7, 226)
        Me.Label33.Name = "Label33"
        Me.Label33.Padding = New System.Windows.Forms.Padding(0, 4, 0, 0)
        Me.Label33.Size = New System.Drawing.Size(112, 17)
        Me.Label33.TabIndex = 0
        Me.Label33.Text = "Install package name:"
        '
        'Label34
        '
        Me.Label34.AutoEllipsis = True
        Me.Label34.AutoSize = True
        Me.Label34.Location = New System.Drawing.Point(7, 243)
        Me.Label34.Name = "Label34"
        Me.Label34.Padding = New System.Windows.Forms.Padding(0, 2, 0, 0)
        Me.Label34.Size = New System.Drawing.Size(38, 15)
        Me.Label34.TabIndex = 0
        Me.Label34.Text = "Label8"
        Me.Label34.UseMnemonic = False
        '
        'Label28
        '
        Me.Label28.AutoSize = True
        Me.Label28.Location = New System.Drawing.Point(7, 258)
        Me.Label28.Name = "Label28"
        Me.Label28.Padding = New System.Windows.Forms.Padding(0, 4, 0, 0)
        Me.Label28.Size = New System.Drawing.Size(63, 17)
        Me.Label28.TabIndex = 0
        Me.Label28.Text = "Install time:"
        '
        'Label27
        '
        Me.Label27.AutoEllipsis = True
        Me.Label27.AutoSize = True
        Me.Label27.Location = New System.Drawing.Point(7, 275)
        Me.Label27.Name = "Label27"
        Me.Label27.Padding = New System.Windows.Forms.Padding(0, 2, 0, 0)
        Me.Label27.Size = New System.Drawing.Size(38, 15)
        Me.Label27.TabIndex = 0
        Me.Label27.Text = "Label8"
        Me.Label27.UseMnemonic = False
        '
        'Label30
        '
        Me.Label30.AutoSize = True
        Me.Label30.Location = New System.Drawing.Point(7, 290)
        Me.Label30.Name = "Label30"
        Me.Label30.Padding = New System.Windows.Forms.Padding(0, 4, 0, 0)
        Me.Label30.Size = New System.Drawing.Size(91, 17)
        Me.Label30.TabIndex = 0
        Me.Label30.Text = "Last update time:"
        '
        'Label29
        '
        Me.Label29.AutoEllipsis = True
        Me.Label29.AutoSize = True
        Me.Label29.Location = New System.Drawing.Point(7, 307)
        Me.Label29.Name = "Label29"
        Me.Label29.Padding = New System.Windows.Forms.Padding(0, 2, 0, 0)
        Me.Label29.Size = New System.Drawing.Size(38, 15)
        Me.Label29.TabIndex = 0
        Me.Label29.Text = "Label8"
        Me.Label29.UseMnemonic = False
        '
        'Label39
        '
        Me.Label39.AutoSize = True
        Me.Label39.Location = New System.Drawing.Point(7, 322)
        Me.Label39.Name = "Label39"
        Me.Label39.Padding = New System.Windows.Forms.Padding(0, 4, 0, 0)
        Me.Label39.Size = New System.Drawing.Size(74, 17)
        Me.Label39.TabIndex = 0
        Me.Label39.Text = "Display name:"
        '
        'Label38
        '
        Me.Label38.AutoEllipsis = True
        Me.Label38.AutoSize = True
        Me.Label38.Location = New System.Drawing.Point(7, 339)
        Me.Label38.Name = "Label38"
        Me.Label38.Padding = New System.Windows.Forms.Padding(0, 2, 0, 0)
        Me.Label38.Size = New System.Drawing.Size(38, 15)
        Me.Label38.TabIndex = 0
        Me.Label38.Text = "Label8"
        Me.Label38.UseMnemonic = False
        '
        'Label45
        '
        Me.Label45.AutoSize = True
        Me.Label45.Location = New System.Drawing.Point(7, 354)
        Me.Label45.Name = "Label45"
        Me.Label45.Padding = New System.Windows.Forms.Padding(0, 4, 0, 0)
        Me.Label45.Size = New System.Drawing.Size(77, 17)
        Me.Label45.TabIndex = 0
        Me.Label45.Text = "Product name:"
        '
        'Label44
        '
        Me.Label44.AutoEllipsis = True
        Me.Label44.AutoSize = True
        Me.Label44.Location = New System.Drawing.Point(7, 371)
        Me.Label44.Name = "Label44"
        Me.Label44.Padding = New System.Windows.Forms.Padding(0, 2, 0, 0)
        Me.Label44.Size = New System.Drawing.Size(38, 15)
        Me.Label44.TabIndex = 0
        Me.Label44.Text = "Label8"
        Me.Label44.UseMnemonic = False
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(7, 386)
        Me.Label14.Name = "Label14"
        Me.Label14.Padding = New System.Windows.Forms.Padding(0, 4, 0, 0)
        Me.Label14.Size = New System.Drawing.Size(86, 17)
        Me.Label14.TabIndex = 0
        Me.Label14.Text = "Product version:"
        '
        'Label15
        '
        Me.Label15.AutoEllipsis = True
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(7, 403)
        Me.Label15.Name = "Label15"
        Me.Label15.Padding = New System.Windows.Forms.Padding(0, 2, 0, 0)
        Me.Label15.Size = New System.Drawing.Size(38, 15)
        Me.Label15.TabIndex = 0
        Me.Label15.Text = "Label8"
        Me.Label15.UseMnemonic = False
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Location = New System.Drawing.Point(7, 418)
        Me.Label16.Name = "Label16"
        Me.Label16.Padding = New System.Windows.Forms.Padding(0, 4, 0, 0)
        Me.Label16.Size = New System.Drawing.Size(74, 17)
        Me.Label16.TabIndex = 0
        Me.Label16.Text = "Release type:"
        '
        'Label21
        '
        Me.Label21.AutoEllipsis = True
        Me.Label21.AutoSize = True
        Me.Label21.Location = New System.Drawing.Point(7, 435)
        Me.Label21.Name = "Label21"
        Me.Label21.Padding = New System.Windows.Forms.Padding(0, 2, 0, 0)
        Me.Label21.Size = New System.Drawing.Size(38, 15)
        Me.Label21.TabIndex = 0
        Me.Label21.Text = "Label8"
        Me.Label21.UseMnemonic = False
        '
        'Label48
        '
        Me.Label48.AutoSize = True
        Me.Label48.Location = New System.Drawing.Point(7, 450)
        Me.Label48.Name = "Label48"
        Me.Label48.Padding = New System.Windows.Forms.Padding(0, 4, 0, 0)
        Me.Label48.Size = New System.Drawing.Size(109, 17)
        Me.Label48.TabIndex = 0
        Me.Label48.Text = "Is a restart required?"
        '
        'Label13
        '
        Me.Label13.AutoEllipsis = True
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(7, 467)
        Me.Label13.Name = "Label13"
        Me.Label13.Padding = New System.Windows.Forms.Padding(0, 2, 0, 0)
        Me.Label13.Size = New System.Drawing.Size(38, 15)
        Me.Label13.TabIndex = 0
        Me.Label13.Text = "Label8"
        Me.Label13.UseMnemonic = False
        '
        'Label50
        '
        Me.Label50.AutoSize = True
        Me.Label50.Location = New System.Drawing.Point(7, 482)
        Me.Label50.Name = "Label50"
        Me.Label50.Padding = New System.Windows.Forms.Padding(0, 4, 0, 0)
        Me.Label50.Size = New System.Drawing.Size(106, 17)
        Me.Label50.TabIndex = 0
        Me.Label50.Text = "Support information:"
        '
        'Label49
        '
        Me.Label49.AutoEllipsis = True
        Me.Label49.AutoSize = True
        Me.Label49.Location = New System.Drawing.Point(7, 499)
        Me.Label49.Name = "Label49"
        Me.Label49.Padding = New System.Windows.Forms.Padding(0, 2, 0, 0)
        Me.Label49.Size = New System.Drawing.Size(38, 15)
        Me.Label49.TabIndex = 0
        Me.Label49.Text = "Label8"
        Me.Label49.UseMnemonic = False
        '
        'Label52
        '
        Me.Label52.AutoSize = True
        Me.Label52.Location = New System.Drawing.Point(7, 514)
        Me.Label52.Name = "Label52"
        Me.Label52.Padding = New System.Windows.Forms.Padding(0, 4, 0, 0)
        Me.Label52.Size = New System.Drawing.Size(37, 17)
        Me.Label52.TabIndex = 0
        Me.Label52.Text = "State:"
        '
        'Label51
        '
        Me.Label51.AutoEllipsis = True
        Me.Label51.AutoSize = True
        Me.Label51.Location = New System.Drawing.Point(7, 531)
        Me.Label51.Name = "Label51"
        Me.Label51.Padding = New System.Windows.Forms.Padding(0, 2, 0, 0)
        Me.Label51.Size = New System.Drawing.Size(38, 15)
        Me.Label51.TabIndex = 0
        Me.Label51.Text = "Label8"
        Me.Label51.UseMnemonic = False
        '
        'Label54
        '
        Me.Label54.AutoSize = True
        Me.Label54.Location = New System.Drawing.Point(7, 546)
        Me.Label54.Name = "Label54"
        Me.Label54.Padding = New System.Windows.Forms.Padding(0, 4, 0, 0)
        Me.Label54.Size = New System.Drawing.Size(201, 17)
        Me.Label54.TabIndex = 0
        Me.Label54.Text = "Is a boot up required for full installation?"
        '
        'Label53
        '
        Me.Label53.AutoEllipsis = True
        Me.Label53.AutoSize = True
        Me.Label53.Location = New System.Drawing.Point(7, 563)
        Me.Label53.Name = "Label53"
        Me.Label53.Padding = New System.Windows.Forms.Padding(0, 2, 0, 0)
        Me.Label53.Size = New System.Drawing.Size(38, 15)
        Me.Label53.TabIndex = 0
        Me.Label53.Text = "Label8"
        Me.Label53.UseMnemonic = False
        '
        'Label61
        '
        Me.Label61.AutoSize = True
        Me.Label61.Location = New System.Drawing.Point(7, 578)
        Me.Label61.Name = "Label61"
        Me.Label61.Padding = New System.Windows.Forms.Padding(0, 4, 0, 0)
        Me.Label61.Size = New System.Drawing.Size(97, 17)
        Me.Label61.TabIndex = 0
        Me.Label61.Text = "Capability identity:"
        '
        'Label56
        '
        Me.Label56.AutoEllipsis = True
        Me.Label56.AutoSize = True
        Me.Label56.Location = New System.Drawing.Point(7, 595)
        Me.Label56.Name = "Label56"
        Me.Label56.Padding = New System.Windows.Forms.Padding(0, 2, 0, 0)
        Me.Label56.Size = New System.Drawing.Size(38, 15)
        Me.Label56.TabIndex = 0
        Me.Label56.Text = "Label8"
        Me.Label56.UseMnemonic = False
        '
        'Label58
        '
        Me.Label58.AutoSize = True
        Me.Label58.Location = New System.Drawing.Point(7, 610)
        Me.Label58.Name = "Label58"
        Me.Label58.Padding = New System.Windows.Forms.Padding(0, 4, 0, 0)
        Me.Label58.Size = New System.Drawing.Size(99, 17)
        Me.Label58.TabIndex = 0
        Me.Label58.Text = "Custom properties:"
        '
        'Label57
        '
        Me.Label57.AutoEllipsis = True
        Me.Label57.AutoSize = True
        Me.Label57.Location = New System.Drawing.Point(7, 627)
        Me.Label57.Name = "Label57"
        Me.Label57.Padding = New System.Windows.Forms.Padding(0, 2, 0, 0)
        Me.Label57.Size = New System.Drawing.Size(38, 15)
        Me.Label57.TabIndex = 0
        Me.Label57.Text = "Label8"
        Me.Label57.UseMnemonic = False
        Me.Label57.Visible = False
        '
        'CPropViewer
        '
        Me.CPropViewer.Controls.Add(Me.TableLayoutPanel1)
        Me.CPropViewer.Location = New System.Drawing.Point(7, 645)
        Me.CPropViewer.Name = "CPropViewer"
        Me.CPropViewer.Padding = New System.Windows.Forms.Padding(0, 2, 0, 0)
        Me.CPropViewer.Size = New System.Drawing.Size(405, 306)
        Me.CPropViewer.TabIndex = 3
        '
        'TableLayoutPanel1
        '
        Me.TableLayoutPanel1.ColumnCount = 1
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel1.Controls.Add(Me.cPropPathView, 0, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.Panel8, 0, 1)
        Me.TableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel1.Location = New System.Drawing.Point(0, 2)
        Me.TableLayoutPanel1.Name = "TableLayoutPanel1"
        Me.TableLayoutPanel1.RowCount = 2
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel1.Size = New System.Drawing.Size(405, 304)
        Me.TableLayoutPanel1.TabIndex = 1
        '
        'cPropPathView
        '
        Me.cPropPathView.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.cPropPathView.Dock = System.Windows.Forms.DockStyle.Fill
        Me.cPropPathView.Location = New System.Drawing.Point(3, 3)
        Me.cPropPathView.Name = "cPropPathView"
        Me.cPropPathView.Size = New System.Drawing.Size(399, 146)
        Me.cPropPathView.TabIndex = 0
        '
        'Panel8
        '
        Me.Panel8.Controls.Add(Me.cPropValue)
        Me.Panel8.Controls.Add(Me.cPropName)
        Me.Panel8.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel8.Location = New System.Drawing.Point(3, 155)
        Me.Panel8.Name = "Panel8"
        Me.Panel8.Size = New System.Drawing.Size(399, 146)
        Me.Panel8.TabIndex = 1
        '
        'cPropValue
        '
        Me.cPropValue.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.cPropValue.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.cPropValue.Font = New System.Drawing.Font("Consolas", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cPropValue.Location = New System.Drawing.Point(1, 28)
        Me.cPropValue.Multiline = True
        Me.cPropValue.Name = "cPropValue"
        Me.cPropValue.ReadOnly = True
        Me.cPropValue.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.cPropValue.Size = New System.Drawing.Size(395, 115)
        Me.cPropValue.TabIndex = 1
        '
        'cPropName
        '
        Me.cPropName.AutoEllipsis = True
        Me.cPropName.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cPropName.Location = New System.Drawing.Point(4, 4)
        Me.cPropName.Name = "cPropName"
        Me.cPropName.Size = New System.Drawing.Size(392, 15)
        Me.cPropName.TabIndex = 0
        '
        'Label60
        '
        Me.Label60.AutoSize = True
        Me.Label60.Location = New System.Drawing.Point(7, 954)
        Me.Label60.Name = "Label60"
        Me.Label60.Padding = New System.Windows.Forms.Padding(0, 4, 0, 0)
        Me.Label60.Size = New System.Drawing.Size(54, 17)
        Me.Label60.TabIndex = 0
        Me.Label60.Text = "Features:"
        '
        'Label59
        '
        Me.Label59.AutoEllipsis = True
        Me.Label59.AutoSize = True
        Me.Label59.Location = New System.Drawing.Point(7, 971)
        Me.Label59.Name = "Label59"
        Me.Label59.Padding = New System.Windows.Forms.Padding(0, 2, 0, 0)
        Me.Label59.Size = New System.Drawing.Size(38, 15)
        Me.Label59.TabIndex = 0
        Me.Label59.Text = "Label8"
        Me.Label59.UseMnemonic = False
        '
        'Label55
        '
        Me.Label55.AutoEllipsis = True
        Me.Label55.Location = New System.Drawing.Point(7, 986)
        Me.Label55.Name = "Label55"
        Me.Label55.Padding = New System.Windows.Forms.Padding(0, 2, 0, 0)
        Me.Label55.Size = New System.Drawing.Size(405, 16)
        Me.Label55.TabIndex = 0
        Me.Label55.UseMnemonic = False
        '
        'Panel5
        '
        Me.Panel5.Controls.Add(Me.Label36)
        Me.Panel5.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel5.Location = New System.Drawing.Point(0, 0)
        Me.Panel5.Name = "Panel5"
        Me.Panel5.Size = New System.Drawing.Size(436, 36)
        Me.Panel5.TabIndex = 0
        '
        'Label36
        '
        Me.Label36.AutoEllipsis = True
        Me.Label36.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Label36.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label36.Location = New System.Drawing.Point(0, 0)
        Me.Label36.Name = "Label36"
        Me.Label36.Size = New System.Drawing.Size(436, 36)
        Me.Label36.TabIndex = 0
        Me.Label36.Text = "Package information"
        Me.Label36.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Panel7
        '
        Me.Panel7.Controls.Add(Me.Label37)
        Me.Panel7.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel7.Location = New System.Drawing.Point(0, 0)
        Me.Panel7.Name = "Panel7"
        Me.Panel7.Size = New System.Drawing.Size(436, 376)
        Me.Panel7.TabIndex = 1
        '
        'Label37
        '
        Me.Label37.AutoEllipsis = True
        Me.Label37.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Label37.Location = New System.Drawing.Point(0, 0)
        Me.Label37.Name = "Label37"
        Me.Label37.Size = New System.Drawing.Size(436, 376)
        Me.Label37.TabIndex = 0
        Me.Label37.Text = "Select an installed package to view its information here"
        Me.Label37.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'FlowLayoutPanel4
        '
        Me.FlowLayoutPanel4.Location = New System.Drawing.Point(106, 163)
        Me.FlowLayoutPanel4.Name = "FlowLayoutPanel4"
        Me.FlowLayoutPanel4.Size = New System.Drawing.Size(200, 100)
        Me.FlowLayoutPanel4.TabIndex = 0
        '
        'InfoFromPackageFilesPanel
        '
        Me.InfoFromPackageFilesPanel.Controls.Add(Me.SplitContainer1)
        Me.InfoFromPackageFilesPanel.Dock = System.Windows.Forms.DockStyle.Fill
        Me.InfoFromPackageFilesPanel.Location = New System.Drawing.Point(0, 0)
        Me.InfoFromPackageFilesPanel.Name = "InfoFromPackageFilesPanel"
        Me.InfoFromPackageFilesPanel.Size = New System.Drawing.Size(880, 376)
        Me.InfoFromPackageFilesPanel.TabIndex = 1
        '
        'SplitContainer1
        '
        Me.SplitContainer1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SplitContainer1.IsSplitterFixed = True
        Me.SplitContainer1.Location = New System.Drawing.Point(0, 0)
        Me.SplitContainer1.Name = "SplitContainer1"
        '
        'SplitContainer1.Panel1
        '
        Me.SplitContainer1.Panel1.Controls.Add(Me.PkgFilesPanel)
        '
        'SplitContainer1.Panel2
        '
        Me.SplitContainer1.Panel2.Controls.Add(Me.PackageFileContainerPanel)
        Me.SplitContainer1.Panel2.Controls.Add(Me.FlowLayoutPanel1)
        Me.SplitContainer1.Size = New System.Drawing.Size(880, 376)
        Me.SplitContainer1.SplitterDistance = 440
        Me.SplitContainer1.TabIndex = 0
        '
        'PkgFilesPanel
        '
        Me.PkgFilesPanel.Controls.Add(Me.ListBox1)
        Me.PkgFilesPanel.Controls.Add(Me.TableLayoutPanel2)
        Me.PkgFilesPanel.Dock = System.Windows.Forms.DockStyle.Fill
        Me.PkgFilesPanel.Location = New System.Drawing.Point(0, 0)
        Me.PkgFilesPanel.Name = "PkgFilesPanel"
        Me.PkgFilesPanel.Size = New System.Drawing.Size(440, 376)
        Me.PkgFilesPanel.TabIndex = 1
        '
        'ListBox1
        '
        Me.ListBox1.AllowDrop = True
        Me.ListBox1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.ListBox1.FormattingEnabled = True
        Me.ListBox1.Location = New System.Drawing.Point(0, 0)
        Me.ListBox1.Name = "ListBox1"
        Me.ListBox1.Size = New System.Drawing.Size(440, 348)
        Me.ListBox1.TabIndex = 0
        '
        'TableLayoutPanel2
        '
        Me.TableLayoutPanel2.ColumnCount = 3
        Me.TableLayoutPanel2.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333!))
        Me.TableLayoutPanel2.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333!))
        Me.TableLayoutPanel2.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333!))
        Me.TableLayoutPanel2.Controls.Add(Me.Button3, 2, 0)
        Me.TableLayoutPanel2.Controls.Add(Me.Button2, 1, 0)
        Me.TableLayoutPanel2.Controls.Add(Me.Button1, 0, 0)
        Me.TableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.TableLayoutPanel2.Location = New System.Drawing.Point(0, 348)
        Me.TableLayoutPanel2.Name = "TableLayoutPanel2"
        Me.TableLayoutPanel2.RowCount = 1
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel2.Size = New System.Drawing.Size(440, 28)
        Me.TableLayoutPanel2.TabIndex = 1
        '
        'Button3
        '
        Me.Button3.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Button3.Enabled = False
        Me.Button3.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.Button3.Location = New System.Drawing.Point(295, 3)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(142, 22)
        Me.Button3.TabIndex = 2
        Me.Button3.Text = "Remove all"
        Me.Button3.UseVisualStyleBackColor = True
        '
        'Button2
        '
        Me.Button2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Button2.Enabled = False
        Me.Button2.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.Button2.Location = New System.Drawing.Point(149, 3)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(140, 22)
        Me.Button2.TabIndex = 1
        Me.Button2.Text = "Remove selected"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'Button1
        '
        Me.Button1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Button1.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.Button1.Location = New System.Drawing.Point(3, 3)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(140, 22)
        Me.Button1.TabIndex = 0
        Me.Button1.Text = "Add package..."
        Me.Button1.UseVisualStyleBackColor = True
        '
        'PackageFileContainerPanel
        '
        Me.PackageFileContainerPanel.Controls.Add(Me.PackageFileInfoPanel)
        Me.PackageFileContainerPanel.Controls.Add(Me.NoPkgPanel)
        Me.PackageFileContainerPanel.Dock = System.Windows.Forms.DockStyle.Fill
        Me.PackageFileContainerPanel.Location = New System.Drawing.Point(0, 0)
        Me.PackageFileContainerPanel.Name = "PackageFileContainerPanel"
        Me.PackageFileContainerPanel.Size = New System.Drawing.Size(436, 376)
        Me.PackageFileContainerPanel.TabIndex = 1
        '
        'PackageFileInfoPanel
        '
        Me.PackageFileInfoPanel.Controls.Add(Me.FlowLayoutPanel2)
        Me.PackageFileInfoPanel.Controls.Add(Me.Panel1)
        Me.PackageFileInfoPanel.Dock = System.Windows.Forms.DockStyle.Fill
        Me.PackageFileInfoPanel.Location = New System.Drawing.Point(0, 0)
        Me.PackageFileInfoPanel.Name = "PackageFileInfoPanel"
        Me.PackageFileInfoPanel.Size = New System.Drawing.Size(436, 376)
        Me.PackageFileInfoPanel.TabIndex = 2
        Me.PackageFileInfoPanel.Visible = False
        '
        'FlowLayoutPanel2
        '
        Me.FlowLayoutPanel2.AutoScroll = True
        Me.FlowLayoutPanel2.Controls.Add(Me.Label8)
        Me.FlowLayoutPanel2.Controls.Add(Me.Label9)
        Me.FlowLayoutPanel2.Controls.Add(Me.Label10)
        Me.FlowLayoutPanel2.Controls.Add(Me.Label11)
        Me.FlowLayoutPanel2.Controls.Add(Me.Label12)
        Me.FlowLayoutPanel2.Controls.Add(Me.Label17)
        Me.FlowLayoutPanel2.Controls.Add(Me.Label18)
        Me.FlowLayoutPanel2.Controls.Add(Me.Label19)
        Me.FlowLayoutPanel2.Controls.Add(Me.Label20)
        Me.FlowLayoutPanel2.Controls.Add(Me.Label62)
        Me.FlowLayoutPanel2.Controls.Add(Me.Label63)
        Me.FlowLayoutPanel2.Controls.Add(Me.Label64)
        Me.FlowLayoutPanel2.Controls.Add(Me.Label65)
        Me.FlowLayoutPanel2.Controls.Add(Me.Label66)
        Me.FlowLayoutPanel2.Controls.Add(Me.Label67)
        Me.FlowLayoutPanel2.Controls.Add(Me.Label68)
        Me.FlowLayoutPanel2.Controls.Add(Me.Label69)
        Me.FlowLayoutPanel2.Controls.Add(Me.Label70)
        Me.FlowLayoutPanel2.Controls.Add(Me.Label71)
        Me.FlowLayoutPanel2.Controls.Add(Me.Label72)
        Me.FlowLayoutPanel2.Controls.Add(Me.Label73)
        Me.FlowLayoutPanel2.Controls.Add(Me.Label74)
        Me.FlowLayoutPanel2.Controls.Add(Me.Label75)
        Me.FlowLayoutPanel2.Controls.Add(Me.Label76)
        Me.FlowLayoutPanel2.Controls.Add(Me.Label77)
        Me.FlowLayoutPanel2.Controls.Add(Me.Label78)
        Me.FlowLayoutPanel2.Controls.Add(Me.Label79)
        Me.FlowLayoutPanel2.Controls.Add(Me.Label80)
        Me.FlowLayoutPanel2.Controls.Add(Me.Label81)
        Me.FlowLayoutPanel2.Controls.Add(Me.Label82)
        Me.FlowLayoutPanel2.Controls.Add(Me.Label83)
        Me.FlowLayoutPanel2.Controls.Add(Me.Label84)
        Me.FlowLayoutPanel2.Controls.Add(Me.Label85)
        Me.FlowLayoutPanel2.Controls.Add(Me.Label86)
        Me.FlowLayoutPanel2.Controls.Add(Me.Label87)
        Me.FlowLayoutPanel2.Controls.Add(Me.Label88)
        Me.FlowLayoutPanel2.Controls.Add(Me.Label89)
        Me.FlowLayoutPanel2.Controls.Add(Me.Label90)
        Me.FlowLayoutPanel2.Controls.Add(Me.Label91)
        Me.FlowLayoutPanel2.Controls.Add(Me.Label92)
        Me.FlowLayoutPanel2.Controls.Add(Me.Label93)
        Me.FlowLayoutPanel2.Controls.Add(Me.Label94)
        Me.FlowLayoutPanel2.Controls.Add(Me.Label95)
        Me.FlowLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.FlowLayoutPanel2.FlowDirection = System.Windows.Forms.FlowDirection.TopDown
        Me.FlowLayoutPanel2.Location = New System.Drawing.Point(0, 36)
        Me.FlowLayoutPanel2.Name = "FlowLayoutPanel2"
        Me.FlowLayoutPanel2.Padding = New System.Windows.Forms.Padding(4, 6, 0, 0)
        Me.FlowLayoutPanel2.Size = New System.Drawing.Size(436, 340)
        Me.FlowLayoutPanel2.TabIndex = 1
        Me.FlowLayoutPanel2.WrapContents = False
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(7, 6)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(80, 13)
        Me.Label8.TabIndex = 1
        Me.Label8.Text = "Package name:"
        '
        'Label9
        '
        Me.Label9.AutoEllipsis = True
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(7, 19)
        Me.Label9.Name = "Label9"
        Me.Label9.Padding = New System.Windows.Forms.Padding(0, 2, 0, 0)
        Me.Label9.Size = New System.Drawing.Size(38, 15)
        Me.Label9.TabIndex = 24
        Me.Label9.Text = "Label8"
        Me.Label9.UseMnemonic = False
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(7, 34)
        Me.Label10.Name = "Label10"
        Me.Label10.Padding = New System.Windows.Forms.Padding(0, 4, 0, 0)
        Me.Label10.Size = New System.Drawing.Size(114, 17)
        Me.Label10.TabIndex = 25
        Me.Label10.Text = "Is package applicable?"
        '
        'Label11
        '
        Me.Label11.AutoEllipsis = True
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(7, 51)
        Me.Label11.Name = "Label11"
        Me.Label11.Padding = New System.Windows.Forms.Padding(0, 2, 0, 0)
        Me.Label11.Size = New System.Drawing.Size(38, 15)
        Me.Label11.TabIndex = 26
        Me.Label11.Text = "Label8"
        Me.Label11.UseMnemonic = False
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(7, 66)
        Me.Label12.Name = "Label12"
        Me.Label12.Padding = New System.Windows.Forms.Padding(0, 4, 0, 0)
        Me.Label12.Size = New System.Drawing.Size(58, 17)
        Me.Label12.TabIndex = 27
        Me.Label12.Text = "Copyright:"
        '
        'Label17
        '
        Me.Label17.AutoEllipsis = True
        Me.Label17.AutoSize = True
        Me.Label17.Location = New System.Drawing.Point(7, 83)
        Me.Label17.Name = "Label17"
        Me.Label17.Padding = New System.Windows.Forms.Padding(0, 2, 0, 0)
        Me.Label17.Size = New System.Drawing.Size(38, 15)
        Me.Label17.TabIndex = 28
        Me.Label17.Text = "Label8"
        Me.Label17.UseMnemonic = False
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Location = New System.Drawing.Point(7, 98)
        Me.Label18.Name = "Label18"
        Me.Label18.Padding = New System.Windows.Forms.Padding(0, 4, 0, 0)
        Me.Label18.Size = New System.Drawing.Size(56, 17)
        Me.Label18.TabIndex = 29
        Me.Label18.Text = "Company:"
        '
        'Label19
        '
        Me.Label19.AutoEllipsis = True
        Me.Label19.AutoSize = True
        Me.Label19.Location = New System.Drawing.Point(7, 115)
        Me.Label19.Name = "Label19"
        Me.Label19.Padding = New System.Windows.Forms.Padding(0, 2, 0, 0)
        Me.Label19.Size = New System.Drawing.Size(38, 15)
        Me.Label19.TabIndex = 30
        Me.Label19.Text = "Label8"
        Me.Label19.UseMnemonic = False
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Location = New System.Drawing.Point(7, 130)
        Me.Label20.Name = "Label20"
        Me.Label20.Padding = New System.Windows.Forms.Padding(0, 4, 0, 0)
        Me.Label20.Size = New System.Drawing.Size(75, 17)
        Me.Label20.TabIndex = 31
        Me.Label20.Text = "Creation time:"
        '
        'Label62
        '
        Me.Label62.AutoEllipsis = True
        Me.Label62.AutoSize = True
        Me.Label62.Location = New System.Drawing.Point(7, 147)
        Me.Label62.Name = "Label62"
        Me.Label62.Padding = New System.Windows.Forms.Padding(0, 2, 0, 0)
        Me.Label62.Size = New System.Drawing.Size(38, 15)
        Me.Label62.TabIndex = 33
        Me.Label62.Text = "Label8"
        Me.Label62.UseMnemonic = False
        '
        'Label63
        '
        Me.Label63.AutoSize = True
        Me.Label63.Location = New System.Drawing.Point(7, 162)
        Me.Label63.Name = "Label63"
        Me.Label63.Padding = New System.Windows.Forms.Padding(0, 4, 0, 0)
        Me.Label63.Size = New System.Drawing.Size(64, 17)
        Me.Label63.TabIndex = 42
        Me.Label63.Text = "Description:"
        '
        'Label64
        '
        Me.Label64.AutoEllipsis = True
        Me.Label64.AutoSize = True
        Me.Label64.Location = New System.Drawing.Point(7, 179)
        Me.Label64.Name = "Label64"
        Me.Label64.Padding = New System.Windows.Forms.Padding(0, 2, 0, 0)
        Me.Label64.Size = New System.Drawing.Size(38, 15)
        Me.Label64.TabIndex = 34
        Me.Label64.Text = "Label8"
        Me.Label64.UseMnemonic = False
        '
        'Label65
        '
        Me.Label65.AutoSize = True
        Me.Label65.Location = New System.Drawing.Point(7, 194)
        Me.Label65.Name = "Label65"
        Me.Label65.Padding = New System.Windows.Forms.Padding(0, 4, 0, 0)
        Me.Label65.Size = New System.Drawing.Size(68, 17)
        Me.Label65.TabIndex = 35
        Me.Label65.Text = "Install client:"
        '
        'Label66
        '
        Me.Label66.AutoEllipsis = True
        Me.Label66.AutoSize = True
        Me.Label66.Location = New System.Drawing.Point(7, 211)
        Me.Label66.Name = "Label66"
        Me.Label66.Padding = New System.Windows.Forms.Padding(0, 2, 0, 0)
        Me.Label66.Size = New System.Drawing.Size(38, 15)
        Me.Label66.TabIndex = 36
        Me.Label66.Text = "Label8"
        Me.Label66.UseMnemonic = False
        '
        'Label67
        '
        Me.Label67.AutoSize = True
        Me.Label67.Location = New System.Drawing.Point(7, 226)
        Me.Label67.Name = "Label67"
        Me.Label67.Padding = New System.Windows.Forms.Padding(0, 4, 0, 0)
        Me.Label67.Size = New System.Drawing.Size(112, 17)
        Me.Label67.TabIndex = 37
        Me.Label67.Text = "Install package name:"
        '
        'Label68
        '
        Me.Label68.AutoEllipsis = True
        Me.Label68.AutoSize = True
        Me.Label68.Location = New System.Drawing.Point(7, 243)
        Me.Label68.Name = "Label68"
        Me.Label68.Padding = New System.Windows.Forms.Padding(0, 2, 0, 0)
        Me.Label68.Size = New System.Drawing.Size(38, 15)
        Me.Label68.TabIndex = 38
        Me.Label68.Text = "Label8"
        Me.Label68.UseMnemonic = False
        '
        'Label69
        '
        Me.Label69.AutoSize = True
        Me.Label69.Location = New System.Drawing.Point(7, 258)
        Me.Label69.Name = "Label69"
        Me.Label69.Padding = New System.Windows.Forms.Padding(0, 4, 0, 0)
        Me.Label69.Size = New System.Drawing.Size(63, 17)
        Me.Label69.TabIndex = 39
        Me.Label69.Text = "Install time:"
        '
        'Label70
        '
        Me.Label70.AutoEllipsis = True
        Me.Label70.AutoSize = True
        Me.Label70.Location = New System.Drawing.Point(7, 275)
        Me.Label70.Name = "Label70"
        Me.Label70.Padding = New System.Windows.Forms.Padding(0, 2, 0, 0)
        Me.Label70.Size = New System.Drawing.Size(38, 15)
        Me.Label70.TabIndex = 40
        Me.Label70.Text = "Label8"
        Me.Label70.UseMnemonic = False
        '
        'Label71
        '
        Me.Label71.AutoSize = True
        Me.Label71.Location = New System.Drawing.Point(7, 290)
        Me.Label71.Name = "Label71"
        Me.Label71.Padding = New System.Windows.Forms.Padding(0, 4, 0, 0)
        Me.Label71.Size = New System.Drawing.Size(91, 17)
        Me.Label71.TabIndex = 41
        Me.Label71.Text = "Last update time:"
        '
        'Label72
        '
        Me.Label72.AutoEllipsis = True
        Me.Label72.AutoSize = True
        Me.Label72.Location = New System.Drawing.Point(7, 307)
        Me.Label72.Name = "Label72"
        Me.Label72.Padding = New System.Windows.Forms.Padding(0, 2, 0, 0)
        Me.Label72.Size = New System.Drawing.Size(38, 15)
        Me.Label72.TabIndex = 23
        Me.Label72.Text = "Label8"
        Me.Label72.UseMnemonic = False
        '
        'Label73
        '
        Me.Label73.AutoSize = True
        Me.Label73.Location = New System.Drawing.Point(7, 322)
        Me.Label73.Name = "Label73"
        Me.Label73.Padding = New System.Windows.Forms.Padding(0, 4, 0, 0)
        Me.Label73.Size = New System.Drawing.Size(74, 17)
        Me.Label73.TabIndex = 32
        Me.Label73.Text = "Display name:"
        '
        'Label74
        '
        Me.Label74.AutoEllipsis = True
        Me.Label74.AutoSize = True
        Me.Label74.Location = New System.Drawing.Point(7, 339)
        Me.Label74.Name = "Label74"
        Me.Label74.Padding = New System.Windows.Forms.Padding(0, 2, 0, 0)
        Me.Label74.Size = New System.Drawing.Size(38, 15)
        Me.Label74.TabIndex = 22
        Me.Label74.Text = "Label8"
        Me.Label74.UseMnemonic = False
        '
        'Label75
        '
        Me.Label75.AutoSize = True
        Me.Label75.Location = New System.Drawing.Point(7, 354)
        Me.Label75.Name = "Label75"
        Me.Label75.Padding = New System.Windows.Forms.Padding(0, 4, 0, 0)
        Me.Label75.Size = New System.Drawing.Size(77, 17)
        Me.Label75.TabIndex = 10
        Me.Label75.Text = "Product name:"
        '
        'Label76
        '
        Me.Label76.AutoEllipsis = True
        Me.Label76.AutoSize = True
        Me.Label76.Location = New System.Drawing.Point(7, 371)
        Me.Label76.Name = "Label76"
        Me.Label76.Padding = New System.Windows.Forms.Padding(0, 2, 0, 0)
        Me.Label76.Size = New System.Drawing.Size(38, 15)
        Me.Label76.TabIndex = 2
        Me.Label76.Text = "Label8"
        Me.Label76.UseMnemonic = False
        '
        'Label77
        '
        Me.Label77.AutoSize = True
        Me.Label77.Location = New System.Drawing.Point(7, 386)
        Me.Label77.Name = "Label77"
        Me.Label77.Padding = New System.Windows.Forms.Padding(0, 4, 0, 0)
        Me.Label77.Size = New System.Drawing.Size(86, 17)
        Me.Label77.TabIndex = 3
        Me.Label77.Text = "Product version:"
        '
        'Label78
        '
        Me.Label78.AutoEllipsis = True
        Me.Label78.AutoSize = True
        Me.Label78.Location = New System.Drawing.Point(7, 403)
        Me.Label78.Name = "Label78"
        Me.Label78.Padding = New System.Windows.Forms.Padding(0, 2, 0, 0)
        Me.Label78.Size = New System.Drawing.Size(38, 15)
        Me.Label78.TabIndex = 4
        Me.Label78.Text = "Label8"
        Me.Label78.UseMnemonic = False
        '
        'Label79
        '
        Me.Label79.AutoSize = True
        Me.Label79.Location = New System.Drawing.Point(7, 418)
        Me.Label79.Name = "Label79"
        Me.Label79.Padding = New System.Windows.Forms.Padding(0, 4, 0, 0)
        Me.Label79.Size = New System.Drawing.Size(74, 17)
        Me.Label79.TabIndex = 5
        Me.Label79.Text = "Release type:"
        '
        'Label80
        '
        Me.Label80.AutoEllipsis = True
        Me.Label80.AutoSize = True
        Me.Label80.Location = New System.Drawing.Point(7, 435)
        Me.Label80.Name = "Label80"
        Me.Label80.Padding = New System.Windows.Forms.Padding(0, 2, 0, 0)
        Me.Label80.Size = New System.Drawing.Size(38, 15)
        Me.Label80.TabIndex = 6
        Me.Label80.Text = "Label8"
        Me.Label80.UseMnemonic = False
        '
        'Label81
        '
        Me.Label81.AutoSize = True
        Me.Label81.Location = New System.Drawing.Point(7, 450)
        Me.Label81.Name = "Label81"
        Me.Label81.Padding = New System.Windows.Forms.Padding(0, 4, 0, 0)
        Me.Label81.Size = New System.Drawing.Size(109, 17)
        Me.Label81.TabIndex = 7
        Me.Label81.Text = "Is a restart required?"
        '
        'Label82
        '
        Me.Label82.AutoEllipsis = True
        Me.Label82.AutoSize = True
        Me.Label82.Location = New System.Drawing.Point(7, 467)
        Me.Label82.Name = "Label82"
        Me.Label82.Padding = New System.Windows.Forms.Padding(0, 2, 0, 0)
        Me.Label82.Size = New System.Drawing.Size(38, 15)
        Me.Label82.TabIndex = 8
        Me.Label82.Text = "Label8"
        Me.Label82.UseMnemonic = False
        '
        'Label83
        '
        Me.Label83.AutoSize = True
        Me.Label83.Location = New System.Drawing.Point(7, 482)
        Me.Label83.Name = "Label83"
        Me.Label83.Padding = New System.Windows.Forms.Padding(0, 4, 0, 0)
        Me.Label83.Size = New System.Drawing.Size(106, 17)
        Me.Label83.TabIndex = 9
        Me.Label83.Text = "Support information:"
        '
        'Label84
        '
        Me.Label84.AutoEllipsis = True
        Me.Label84.AutoSize = True
        Me.Label84.Location = New System.Drawing.Point(7, 499)
        Me.Label84.Name = "Label84"
        Me.Label84.Padding = New System.Windows.Forms.Padding(0, 2, 0, 0)
        Me.Label84.Size = New System.Drawing.Size(38, 15)
        Me.Label84.TabIndex = 11
        Me.Label84.Text = "Label8"
        Me.Label84.UseMnemonic = False
        '
        'Label85
        '
        Me.Label85.AutoSize = True
        Me.Label85.Location = New System.Drawing.Point(7, 514)
        Me.Label85.Name = "Label85"
        Me.Label85.Padding = New System.Windows.Forms.Padding(0, 4, 0, 0)
        Me.Label85.Size = New System.Drawing.Size(37, 17)
        Me.Label85.TabIndex = 20
        Me.Label85.Text = "State:"
        '
        'Label86
        '
        Me.Label86.AutoEllipsis = True
        Me.Label86.AutoSize = True
        Me.Label86.Location = New System.Drawing.Point(7, 531)
        Me.Label86.Name = "Label86"
        Me.Label86.Padding = New System.Windows.Forms.Padding(0, 2, 0, 0)
        Me.Label86.Size = New System.Drawing.Size(38, 15)
        Me.Label86.TabIndex = 12
        Me.Label86.Text = "Label8"
        Me.Label86.UseMnemonic = False
        '
        'Label87
        '
        Me.Label87.AutoSize = True
        Me.Label87.Location = New System.Drawing.Point(7, 546)
        Me.Label87.Name = "Label87"
        Me.Label87.Padding = New System.Windows.Forms.Padding(0, 4, 0, 0)
        Me.Label87.Size = New System.Drawing.Size(201, 17)
        Me.Label87.TabIndex = 13
        Me.Label87.Text = "Is a boot up required for full installation?"
        '
        'Label88
        '
        Me.Label88.AutoEllipsis = True
        Me.Label88.AutoSize = True
        Me.Label88.Location = New System.Drawing.Point(7, 563)
        Me.Label88.Name = "Label88"
        Me.Label88.Padding = New System.Windows.Forms.Padding(0, 2, 0, 0)
        Me.Label88.Size = New System.Drawing.Size(38, 15)
        Me.Label88.TabIndex = 14
        Me.Label88.Text = "Label8"
        Me.Label88.UseMnemonic = False
        '
        'Label89
        '
        Me.Label89.AutoSize = True
        Me.Label89.Location = New System.Drawing.Point(7, 578)
        Me.Label89.Name = "Label89"
        Me.Label89.Padding = New System.Windows.Forms.Padding(0, 4, 0, 0)
        Me.Label89.Size = New System.Drawing.Size(97, 17)
        Me.Label89.TabIndex = 44
        Me.Label89.Text = "Capability identity:"
        '
        'Label90
        '
        Me.Label90.AutoEllipsis = True
        Me.Label90.AutoSize = True
        Me.Label90.Location = New System.Drawing.Point(7, 595)
        Me.Label90.Name = "Label90"
        Me.Label90.Padding = New System.Windows.Forms.Padding(0, 2, 0, 0)
        Me.Label90.Size = New System.Drawing.Size(38, 15)
        Me.Label90.TabIndex = 45
        Me.Label90.Text = "Label8"
        Me.Label90.UseMnemonic = False
        '
        'Label91
        '
        Me.Label91.AutoSize = True
        Me.Label91.Location = New System.Drawing.Point(7, 610)
        Me.Label91.Name = "Label91"
        Me.Label91.Padding = New System.Windows.Forms.Padding(0, 4, 0, 0)
        Me.Label91.Size = New System.Drawing.Size(99, 17)
        Me.Label91.TabIndex = 17
        Me.Label91.Text = "Custom properties:"
        '
        'Label92
        '
        Me.Label92.AutoEllipsis = True
        Me.Label92.AutoSize = True
        Me.Label92.Location = New System.Drawing.Point(7, 627)
        Me.Label92.Name = "Label92"
        Me.Label92.Padding = New System.Windows.Forms.Padding(0, 2, 0, 0)
        Me.Label92.Size = New System.Drawing.Size(38, 15)
        Me.Label92.TabIndex = 18
        Me.Label92.Text = "Label8"
        Me.Label92.UseMnemonic = False
        '
        'Label93
        '
        Me.Label93.AutoSize = True
        Me.Label93.Location = New System.Drawing.Point(7, 642)
        Me.Label93.Name = "Label93"
        Me.Label93.Padding = New System.Windows.Forms.Padding(0, 4, 0, 0)
        Me.Label93.Size = New System.Drawing.Size(54, 17)
        Me.Label93.TabIndex = 19
        Me.Label93.Text = "Features:"
        '
        'Label94
        '
        Me.Label94.AutoEllipsis = True
        Me.Label94.AutoSize = True
        Me.Label94.Location = New System.Drawing.Point(7, 659)
        Me.Label94.Name = "Label94"
        Me.Label94.Padding = New System.Windows.Forms.Padding(0, 2, 0, 0)
        Me.Label94.Size = New System.Drawing.Size(38, 15)
        Me.Label94.TabIndex = 21
        Me.Label94.Text = "Label8"
        Me.Label94.UseMnemonic = False
        '
        'Label95
        '
        Me.Label95.AutoEllipsis = True
        Me.Label95.Location = New System.Drawing.Point(7, 674)
        Me.Label95.Name = "Label95"
        Me.Label95.Padding = New System.Windows.Forms.Padding(0, 2, 0, 0)
        Me.Label95.Size = New System.Drawing.Size(405, 16)
        Me.Label95.TabIndex = 43
        Me.Label95.UseMnemonic = False
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.Label7)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel1.Location = New System.Drawing.Point(0, 0)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(436, 36)
        Me.Panel1.TabIndex = 0
        '
        'Label7
        '
        Me.Label7.AutoEllipsis = True
        Me.Label7.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Label7.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(0, 0)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(436, 36)
        Me.Label7.TabIndex = 0
        Me.Label7.Text = "Package information"
        Me.Label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'NoPkgPanel
        '
        Me.NoPkgPanel.Controls.Add(Me.Label6)
        Me.NoPkgPanel.Dock = System.Windows.Forms.DockStyle.Fill
        Me.NoPkgPanel.Location = New System.Drawing.Point(0, 0)
        Me.NoPkgPanel.Name = "NoPkgPanel"
        Me.NoPkgPanel.Size = New System.Drawing.Size(436, 376)
        Me.NoPkgPanel.TabIndex = 1
        '
        'Label6
        '
        Me.Label6.AutoEllipsis = True
        Me.Label6.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Label6.Location = New System.Drawing.Point(0, 0)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(436, 376)
        Me.Label6.TabIndex = 0
        Me.Label6.Text = "Add or select a package file to view its information here"
        Me.Label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'FlowLayoutPanel1
        '
        Me.FlowLayoutPanel1.Location = New System.Drawing.Point(106, 163)
        Me.FlowLayoutPanel1.Name = "FlowLayoutPanel1"
        Me.FlowLayoutPanel1.Size = New System.Drawing.Size(200, 100)
        Me.FlowLayoutPanel1.TabIndex = 0
        '
        'LinkLabel1
        '
        Me.LinkLabel1.AutoSize = True
        Me.LinkLabel1.Font = New System.Drawing.Font("Tahoma", 8.25!)
        Me.LinkLabel1.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline
        Me.LinkLabel1.LinkColor = System.Drawing.Color.DodgerBlue
        Me.LinkLabel1.Location = New System.Drawing.Point(17, 12)
        Me.LinkLabel1.Name = "LinkLabel1"
        Me.LinkLabel1.Size = New System.Drawing.Size(60, 13)
        Me.LinkLabel1.TabIndex = 2
        Me.LinkLabel1.TabStop = True
        Me.LinkLabel1.Text = "<- Go back"
        '
        'OpenFileDialog1
        '
        Me.OpenFileDialog1.Filter = "CAB files|*.cab"
        Me.OpenFileDialog1.Title = "Locate package files"
        '
        'GetPkgInfoDlg
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1008, 561)
        Me.Controls.Add(Me.PackageInfoPanel)
        Me.Controls.Add(Me.MenuPanel)
        Me.Controls.Add(Me.Win10Title)
        Me.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "GetPkgInfoDlg"
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "Get package information"
        Me.Win10Title.ResumeLayout(False)
        Me.Win10Title.PerformLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.MenuPanel.ResumeLayout(False)
        Me.MenuPanel.PerformLayout()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.PackageInfoPanel.ResumeLayout(False)
        Me.PackageInfoPanel.PerformLayout()
        Me.PackageContainerPanel.ResumeLayout(False)
        Me.InfoFromInstalledPkgsPanel.ResumeLayout(False)
        Me.SplitContainer2.Panel1.ResumeLayout(False)
        Me.SplitContainer2.Panel2.ResumeLayout(False)
        CType(Me.SplitContainer2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.SplitContainer2.ResumeLayout(False)
        Me.Panel2.ResumeLayout(False)
        Me.SearchPanel.ResumeLayout(False)
        Me.Panel6.ResumeLayout(False)
        Me.Panel6.PerformLayout()
        CType(Me.SearchPic, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel3.ResumeLayout(False)
        Me.Panel4.ResumeLayout(False)
        Me.FlowLayoutPanel3.ResumeLayout(False)
        Me.FlowLayoutPanel3.PerformLayout()
        Me.CPropViewer.ResumeLayout(False)
        Me.TableLayoutPanel1.ResumeLayout(False)
        Me.Panel8.ResumeLayout(False)
        Me.Panel8.PerformLayout()
        Me.Panel5.ResumeLayout(False)
        Me.Panel7.ResumeLayout(False)
        Me.InfoFromPackageFilesPanel.ResumeLayout(False)
        Me.SplitContainer1.Panel1.ResumeLayout(False)
        Me.SplitContainer1.Panel2.ResumeLayout(False)
        CType(Me.SplitContainer1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.SplitContainer1.ResumeLayout(False)
        Me.PkgFilesPanel.ResumeLayout(False)
        Me.TableLayoutPanel2.ResumeLayout(False)
        Me.PackageFileContainerPanel.ResumeLayout(False)
        Me.PackageFileInfoPanel.ResumeLayout(False)
        Me.FlowLayoutPanel2.ResumeLayout(False)
        Me.FlowLayoutPanel2.PerformLayout()
        Me.Panel1.ResumeLayout(False)
        Me.NoPkgPanel.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Win10Title As System.Windows.Forms.Panel
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents MenuPanel As System.Windows.Forms.Panel
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents PictureBox3 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox2 As System.Windows.Forms.PictureBox
    Friend WithEvents InstalledPackageLink As System.Windows.Forms.LinkLabel
    Friend WithEvents PackageFileLink As System.Windows.Forms.LinkLabel
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents PackageInfoPanel As System.Windows.Forms.Panel
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents PackageContainerPanel As System.Windows.Forms.Panel
    Friend WithEvents InfoFromPackageFilesPanel As System.Windows.Forms.Panel
    Friend WithEvents SplitContainer1 As System.Windows.Forms.SplitContainer
    Friend WithEvents PkgFilesPanel As System.Windows.Forms.Panel
    Friend WithEvents ListBox1 As System.Windows.Forms.ListBox
    Friend WithEvents TableLayoutPanel2 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents Button3 As System.Windows.Forms.Button
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents PackageFileContainerPanel As System.Windows.Forms.Panel
    Friend WithEvents PackageFileInfoPanel As System.Windows.Forms.Panel
    Friend WithEvents FlowLayoutPanel2 As System.Windows.Forms.FlowLayoutPanel
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents NoPkgPanel As System.Windows.Forms.Panel
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents FlowLayoutPanel1 As System.Windows.Forms.FlowLayoutPanel
    Friend WithEvents InfoFromInstalledPkgsPanel As System.Windows.Forms.Panel
    Friend WithEvents SplitContainer2 As System.Windows.Forms.SplitContainer
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents ListBox2 As System.Windows.Forms.ListBox
    Friend WithEvents Panel3 As System.Windows.Forms.Panel
    Friend WithEvents Panel4 As System.Windows.Forms.Panel
    Friend WithEvents FlowLayoutPanel3 As System.Windows.Forms.FlowLayoutPanel
    Friend WithEvents Label22 As System.Windows.Forms.Label
    Friend WithEvents Label23 As System.Windows.Forms.Label
    Friend WithEvents Label24 As System.Windows.Forms.Label
    Friend WithEvents Label25 As System.Windows.Forms.Label
    Friend WithEvents Label26 As System.Windows.Forms.Label
    Friend WithEvents Label35 As System.Windows.Forms.Label
    Friend WithEvents Label31 As System.Windows.Forms.Label
    Friend WithEvents Label32 As System.Windows.Forms.Label
    Friend WithEvents Label41 As System.Windows.Forms.Label
    Friend WithEvents Label40 As System.Windows.Forms.Label
    Friend WithEvents Label43 As System.Windows.Forms.Label
    Friend WithEvents Label42 As System.Windows.Forms.Label
    Friend WithEvents Label47 As System.Windows.Forms.Label
    Friend WithEvents Label46 As System.Windows.Forms.Label
    Friend WithEvents Label33 As System.Windows.Forms.Label
    Friend WithEvents Label34 As System.Windows.Forms.Label
    Friend WithEvents Label28 As System.Windows.Forms.Label
    Friend WithEvents Label27 As System.Windows.Forms.Label
    Friend WithEvents Label30 As System.Windows.Forms.Label
    Friend WithEvents Label29 As System.Windows.Forms.Label
    Friend WithEvents Label39 As System.Windows.Forms.Label
    Friend WithEvents Label38 As System.Windows.Forms.Label
    Friend WithEvents Label45 As System.Windows.Forms.Label
    Friend WithEvents Label44 As System.Windows.Forms.Label
    Friend WithEvents Panel5 As System.Windows.Forms.Panel
    Friend WithEvents Label36 As System.Windows.Forms.Label
    Friend WithEvents Panel7 As System.Windows.Forms.Panel
    Friend WithEvents Label37 As System.Windows.Forms.Label
    Friend WithEvents FlowLayoutPanel4 As System.Windows.Forms.FlowLayoutPanel
    Friend WithEvents LinkLabel1 As System.Windows.Forms.LinkLabel
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents Label21 As System.Windows.Forms.Label
    Friend WithEvents Label48 As System.Windows.Forms.Label
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents Label50 As System.Windows.Forms.Label
    Friend WithEvents Label49 As System.Windows.Forms.Label
    Friend WithEvents Label52 As System.Windows.Forms.Label
    Friend WithEvents Label51 As System.Windows.Forms.Label
    Friend WithEvents Label54 As System.Windows.Forms.Label
    Friend WithEvents Label53 As System.Windows.Forms.Label
    Friend WithEvents Label58 As System.Windows.Forms.Label
    Friend WithEvents Label57 As System.Windows.Forms.Label
    Friend WithEvents Label60 As System.Windows.Forms.Label
    Friend WithEvents Label59 As System.Windows.Forms.Label
    Friend WithEvents Label55 As System.Windows.Forms.Label
    Friend WithEvents Label61 As System.Windows.Forms.Label
    Friend WithEvents Label56 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents Label62 As System.Windows.Forms.Label
    Friend WithEvents Label63 As System.Windows.Forms.Label
    Friend WithEvents Label64 As System.Windows.Forms.Label
    Friend WithEvents Label65 As System.Windows.Forms.Label
    Friend WithEvents Label66 As System.Windows.Forms.Label
    Friend WithEvents Label67 As System.Windows.Forms.Label
    Friend WithEvents Label68 As System.Windows.Forms.Label
    Friend WithEvents Label69 As System.Windows.Forms.Label
    Friend WithEvents Label70 As System.Windows.Forms.Label
    Friend WithEvents Label71 As System.Windows.Forms.Label
    Friend WithEvents Label72 As System.Windows.Forms.Label
    Friend WithEvents Label73 As System.Windows.Forms.Label
    Friend WithEvents Label74 As System.Windows.Forms.Label
    Friend WithEvents Label75 As System.Windows.Forms.Label
    Friend WithEvents Label76 As System.Windows.Forms.Label
    Friend WithEvents Label77 As System.Windows.Forms.Label
    Friend WithEvents Label78 As System.Windows.Forms.Label
    Friend WithEvents Label79 As System.Windows.Forms.Label
    Friend WithEvents Label80 As System.Windows.Forms.Label
    Friend WithEvents Label81 As System.Windows.Forms.Label
    Friend WithEvents Label82 As System.Windows.Forms.Label
    Friend WithEvents Label83 As System.Windows.Forms.Label
    Friend WithEvents Label84 As System.Windows.Forms.Label
    Friend WithEvents Label85 As System.Windows.Forms.Label
    Friend WithEvents Label86 As System.Windows.Forms.Label
    Friend WithEvents Label87 As System.Windows.Forms.Label
    Friend WithEvents Label88 As System.Windows.Forms.Label
    Friend WithEvents Label91 As System.Windows.Forms.Label
    Friend WithEvents Label92 As System.Windows.Forms.Label
    Friend WithEvents Label93 As System.Windows.Forms.Label
    Friend WithEvents Label94 As System.Windows.Forms.Label
    Friend WithEvents Label95 As System.Windows.Forms.Label
    Friend WithEvents OpenFileDialog1 As System.Windows.Forms.OpenFileDialog
    Friend WithEvents Label89 As System.Windows.Forms.Label
    Friend WithEvents Label90 As System.Windows.Forms.Label
    Friend WithEvents Button4 As System.Windows.Forms.Button
    Friend WithEvents SearchPanel As System.Windows.Forms.Panel
    Friend WithEvents Panel6 As System.Windows.Forms.Panel
    Friend WithEvents SearchBox1 As DISMTools.SearchBox
    Friend WithEvents SearchPic As System.Windows.Forms.PictureBox
    Friend WithEvents CPropViewer As System.Windows.Forms.Panel
    Friend WithEvents TableLayoutPanel1 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents cPropPathView As System.Windows.Forms.TreeView
    Friend WithEvents Panel8 As System.Windows.Forms.Panel
    Friend WithEvents cPropValue As System.Windows.Forms.TextBox
    Friend WithEvents cPropName As System.Windows.Forms.Label

End Class
