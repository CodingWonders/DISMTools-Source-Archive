﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class MainForm
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(MainForm))
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.FileToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.NewProjectToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.OpenExistingProjectToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator26 = New System.Windows.Forms.ToolStripSeparator()
        Me.ManageOnlineInstallationToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ManageOfflineInstallationToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator37 = New System.Windows.Forms.ToolStripSeparator()
        Me.RecentProjectsListMenu = New System.Windows.Forms.ToolStripMenuItem()
        Me.RecentProject1ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.RecentProject2ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.RecentProject3ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.RecentProject4ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.RecentProject5ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.RecentProject6ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.RecentProject7ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.RecentProject8ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.RecentProject9ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.RecentProject10ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator1 = New System.Windows.Forms.ToolStripSeparator()
        Me.SaveProjectToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SaveProjectasToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator2 = New System.Windows.Forms.ToolStripSeparator()
        Me.ExitToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ProjectToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ViewProjectFilesInFileExplorerToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.UnloadProjectToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator3 = New System.Windows.Forms.ToolStripSeparator()
        Me.SwitchImageIndexesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator11 = New System.Windows.Forms.ToolStripSeparator()
        Me.ProjectPropertiesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ImagePropertiesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CommandsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ImageManagementToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AppendImage = New System.Windows.Forms.ToolStripMenuItem()
        Me.ApplyFFU = New System.Windows.Forms.ToolStripMenuItem()
        Me.ApplyImage = New System.Windows.Forms.ToolStripMenuItem()
        Me.CaptureCustomImage = New System.Windows.Forms.ToolStripMenuItem()
        Me.CaptureFFU = New System.Windows.Forms.ToolStripMenuItem()
        Me.CaptureImage = New System.Windows.Forms.ToolStripMenuItem()
        Me.CleanupMountpoints = New System.Windows.Forms.ToolStripMenuItem()
        Me.CommitImage = New System.Windows.Forms.ToolStripMenuItem()
        Me.DeleteImage = New System.Windows.Forms.ToolStripMenuItem()
        Me.ExportImage = New System.Windows.Forms.ToolStripMenuItem()
        Me.GetImageInfo = New System.Windows.Forms.ToolStripMenuItem()
        Me.GetWIMBootEntry = New System.Windows.Forms.ToolStripMenuItem()
        Me.ListImage = New System.Windows.Forms.ToolStripMenuItem()
        Me.MountImage = New System.Windows.Forms.ToolStripMenuItem()
        Me.OptimizeFFU = New System.Windows.Forms.ToolStripMenuItem()
        Me.OptimizeImage = New System.Windows.Forms.ToolStripMenuItem()
        Me.RemountImage = New System.Windows.Forms.ToolStripMenuItem()
        Me.SplitFFU = New System.Windows.Forms.ToolStripMenuItem()
        Me.SplitImage = New System.Windows.Forms.ToolStripMenuItem()
        Me.UnmountImage = New System.Windows.Forms.ToolStripMenuItem()
        Me.UpdateWIMBootEntry = New System.Windows.Forms.ToolStripMenuItem()
        Me.ApplySiloedPackage = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator34 = New System.Windows.Forms.ToolStripSeparator()
        Me.SaveImageInformationToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.OSPackagesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.GetPackages = New System.Windows.Forms.ToolStripMenuItem()
        Me.AddPackage = New System.Windows.Forms.ToolStripMenuItem()
        Me.RemovePackage = New System.Windows.Forms.ToolStripMenuItem()
        Me.GetFeatures = New System.Windows.Forms.ToolStripMenuItem()
        Me.EnableFeature = New System.Windows.Forms.ToolStripMenuItem()
        Me.DisableFeature = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator4 = New System.Windows.Forms.ToolStripSeparator()
        Me.CleanupImage = New System.Windows.Forms.ToolStripMenuItem()
        Me.ProvisioningPackagesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AddProvisioningPackage = New System.Windows.Forms.ToolStripMenuItem()
        Me.GetProvisioningPackageInfo = New System.Windows.Forms.ToolStripMenuItem()
        Me.ApplyCustomDataImage = New System.Windows.Forms.ToolStripMenuItem()
        Me.AppPackagesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.GetProvisionedAppxPackages = New System.Windows.Forms.ToolStripMenuItem()
        Me.AddProvisionedAppxPackage = New System.Windows.Forms.ToolStripMenuItem()
        Me.RemoveProvisionedAppxPackage = New System.Windows.Forms.ToolStripMenuItem()
        Me.OptimizeProvisionedAppxPackages = New System.Windows.Forms.ToolStripMenuItem()
        Me.SetProvisionedAppxDataFile = New System.Windows.Forms.ToolStripMenuItem()
        Me.AppPatchesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CheckAppPatch = New System.Windows.Forms.ToolStripMenuItem()
        Me.GetAppPatchInfo = New System.Windows.Forms.ToolStripMenuItem()
        Me.GetAppPatches = New System.Windows.Forms.ToolStripMenuItem()
        Me.GetAppInfo = New System.Windows.Forms.ToolStripMenuItem()
        Me.GetApps = New System.Windows.Forms.ToolStripMenuItem()
        Me.DefaultAppAssociationsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ExportDefaultAppAssociations = New System.Windows.Forms.ToolStripMenuItem()
        Me.GetDefaultAppAssociations = New System.Windows.Forms.ToolStripMenuItem()
        Me.ImportDefaultAppAssociations = New System.Windows.Forms.ToolStripMenuItem()
        Me.RemoveDefaultAppAssociations = New System.Windows.Forms.ToolStripMenuItem()
        Me.LanguagesAndRegionSettingsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.GetIntl = New System.Windows.Forms.ToolStripMenuItem()
        Me.SetUILang = New System.Windows.Forms.ToolStripMenuItem()
        Me.SetUILangFallback = New System.Windows.Forms.ToolStripMenuItem()
        Me.SetSysUILang = New System.Windows.Forms.ToolStripMenuItem()
        Me.SetSysLocale = New System.Windows.Forms.ToolStripMenuItem()
        Me.SetUserLocale = New System.Windows.Forms.ToolStripMenuItem()
        Me.SetInputLocale = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator5 = New System.Windows.Forms.ToolStripSeparator()
        Me.SetAllIntl = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator6 = New System.Windows.Forms.ToolStripSeparator()
        Me.SetTimeZone = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator7 = New System.Windows.Forms.ToolStripSeparator()
        Me.SetSKUIntlDefaults = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator8 = New System.Windows.Forms.ToolStripSeparator()
        Me.SetLayeredDriver = New System.Windows.Forms.ToolStripMenuItem()
        Me.GenLangINI = New System.Windows.Forms.ToolStripMenuItem()
        Me.SetSetupUILang = New System.Windows.Forms.ToolStripMenuItem()
        Me.CapabilitiesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AddCapability = New System.Windows.Forms.ToolStripMenuItem()
        Me.ExportSource = New System.Windows.Forms.ToolStripMenuItem()
        Me.GetCapabilities = New System.Windows.Forms.ToolStripMenuItem()
        Me.RemoveCapability = New System.Windows.Forms.ToolStripMenuItem()
        Me.WindowsEditionsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.GetCurrentEdition = New System.Windows.Forms.ToolStripMenuItem()
        Me.GetTargetEditions = New System.Windows.Forms.ToolStripMenuItem()
        Me.SetEdition = New System.Windows.Forms.ToolStripMenuItem()
        Me.SetProductKey = New System.Windows.Forms.ToolStripMenuItem()
        Me.DriversToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.GetDrivers = New System.Windows.Forms.ToolStripMenuItem()
        Me.AddDriver = New System.Windows.Forms.ToolStripMenuItem()
        Me.RemoveDriver = New System.Windows.Forms.ToolStripMenuItem()
        Me.ExportDriver = New System.Windows.Forms.ToolStripMenuItem()
        Me.ImportDriver = New System.Windows.Forms.ToolStripMenuItem()
        Me.UnattendedAnswerFilesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ApplyUnattend = New System.Windows.Forms.ToolStripMenuItem()
        Me.WindowsPEServicingToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.GetPESettings = New System.Windows.Forms.ToolStripMenuItem()
        Me.SetScratchSpace = New System.Windows.Forms.ToolStripMenuItem()
        Me.SetTargetPath = New System.Windows.Forms.ToolStripMenuItem()
        Me.OSUninstallToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.GetOSUninstallWindow = New System.Windows.Forms.ToolStripMenuItem()
        Me.InitiateOSUninstall = New System.Windows.Forms.ToolStripMenuItem()
        Me.RemoveOSUninstall = New System.Windows.Forms.ToolStripMenuItem()
        Me.SetOSUninstallWindow = New System.Windows.Forms.ToolStripMenuItem()
        Me.ReservedStorageToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SetReservedStorageState = New System.Windows.Forms.ToolStripMenuItem()
        Me.GetReservedStorageState = New System.Windows.Forms.ToolStripMenuItem()
        Me.MicrosoftEdgeToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AddEdge = New System.Windows.Forms.ToolStripMenuItem()
        Me.AddEdgeBrowser = New System.Windows.Forms.ToolStripMenuItem()
        Me.AddEdgeWebView = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ImageConversionToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.WIMESDToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator12 = New System.Windows.Forms.ToolStripSeparator()
        Me.MergeSWM = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator18 = New System.Windows.Forms.ToolStripSeparator()
        Me.RemountImageWithWritePermissionsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator13 = New System.Windows.Forms.ToolStripSeparator()
        Me.CommandShellToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator16 = New System.Windows.Forms.ToolStripSeparator()
        Me.UnattendedAnswerFileManagerToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.UnattendedAnswerFileCreatorToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator41 = New System.Windows.Forms.ToolStripSeparator()
        Me.ReportManagerToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MountedImageManagerTSMI = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator28 = New System.Windows.Forms.ToolStripSeparator()
        Me.CreateDiscImageToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CreateTestingEnvironmentToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator38 = New System.Windows.Forms.ToolStripSeparator()
        Me.WimScriptEditorCommand = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator9 = New System.Windows.Forms.ToolStripSeparator()
        Me.ActionEditorToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator22 = New System.Windows.Forms.ToolStripSeparator()
        Me.OptionsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.HelpToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.HelpTopicsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.GlossaryToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CommandHelpToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator10 = New System.Windows.Forms.ToolStripSeparator()
        Me.AboutDISMToolsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator21 = New System.Windows.Forms.ToolStripSeparator()
        Me.ReportFeedbackToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator35 = New System.Windows.Forms.ToolStripSeparator()
        Me.ContributeToTheHelpSystemToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.BranchTSMI = New System.Windows.Forms.ToolStripMenuItem()
        Me.VersionTSMI = New System.Windows.Forms.ToolStripMenuItem()
        Me.InvalidSettingsTSMI = New System.Windows.Forms.ToolStripMenuItem()
        Me.ISFix = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator19 = New System.Windows.Forms.ToolStripSeparator()
        Me.ISHelp = New System.Windows.Forms.ToolStripMenuItem()
        Me.HomePanel = New System.Windows.Forms.Panel()
        Me.WelcomePanel = New System.Windows.Forms.Panel()
        Me.StartPanel = New System.Windows.Forms.Panel()
        Me.StartPanelPContainer = New System.Windows.Forms.Panel()
        Me.GetStartedPanel = New System.Windows.Forms.Panel()
        Me.GetStartedContainer = New System.Windows.Forms.Panel()
        Me.Panel6 = New System.Windows.Forms.Panel()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.LinkLabel5 = New System.Windows.Forms.LinkLabel()
        Me.LinkLabel4 = New System.Windows.Forms.LinkLabel()
        Me.LinkLabel11 = New System.Windows.Forms.LinkLabel()
        Me.LinkLabel8 = New System.Windows.Forms.LinkLabel()
        Me.LinkLabel10 = New System.Windows.Forms.LinkLabel()
        Me.LinkLabel7 = New System.Windows.Forms.LinkLabel()
        Me.LinkLabel9 = New System.Windows.Forms.LinkLabel()
        Me.LinkLabel6 = New System.Windows.Forms.LinkLabel()
        Me.Label38 = New System.Windows.Forms.Label()
        Me.Label37 = New System.Windows.Forms.Label()
        Me.Label36 = New System.Windows.Forms.Label()
        Me.PictureBox8 = New System.Windows.Forms.PictureBox()
        Me.PictureBox7 = New System.Windows.Forms.PictureBox()
        Me.PictureBox6 = New System.Windows.Forms.PictureBox()
        Me.LatestNewsPanel = New System.Windows.Forms.Panel()
        Me.FeedContainer = New System.Windows.Forms.Panel()
        Me.FeedsPanel = New System.Windows.Forms.Panel()
        Me.ListView1 = New System.Windows.Forms.ListView()
        Me.ColumnHeader1 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader2 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.FeedErrorPanel = New System.Windows.Forms.Panel()
        Me.Button59 = New System.Windows.Forms.Button()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.Label35 = New System.Windows.Forms.Label()
        Me.Label34 = New System.Windows.Forms.Label()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.Panel4 = New System.Windows.Forms.Panel()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.LinkLabel25 = New System.Windows.Forms.LinkLabel()
        Me.TutorialVideoPanel = New System.Windows.Forms.Panel()
        Me.VideoContainer = New System.Windows.Forms.Panel()
        Me.VideosPanel = New System.Windows.Forms.Panel()
        Me.ListView2 = New System.Windows.Forms.ListView()
        Me.ColumnHeader4 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader5 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.VideoErrorPanel = New System.Windows.Forms.Panel()
        Me.Button17 = New System.Windows.Forms.Button()
        Me.TextBox2 = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.FlowLayoutPanel2 = New System.Windows.Forms.FlowLayoutPanel()
        Me.LinkLabel22 = New System.Windows.Forms.LinkLabel()
        Me.LinkLabel23 = New System.Windows.Forms.LinkLabel()
        Me.LinkLabel24 = New System.Windows.Forms.LinkLabel()
        Me.SidePanel = New System.Windows.Forms.Panel()
        Me.RecentsLV = New System.Windows.Forms.ListView()
        Me.ColumnHeader3 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.UpdatePanel = New System.Windows.Forms.Panel()
        Me.UpdateLink = New System.Windows.Forms.LinkLabel()
        Me.RecentRemoveLink = New System.Windows.Forms.LinkLabel()
        Me.OfflineInstMgmt = New System.Windows.Forms.LinkLabel()
        Me.OnlineInstMgmt = New System.Windows.Forms.LinkLabel()
        Me.ExistingProjLink = New System.Windows.Forms.LinkLabel()
        Me.NewProjLink = New System.Windows.Forms.LinkLabel()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.LabelHeader1 = New System.Windows.Forms.Label()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.PictureBox5 = New System.Windows.Forms.PictureBox()
        Me.PrjPanel = New System.Windows.Forms.Panel()
        Me.ProjectView = New System.Windows.Forms.Panel()
        Me.Panel11 = New System.Windows.Forms.Panel()
        Me.FlowLayoutPanel1 = New System.Windows.Forms.FlowLayoutPanel()
        Me.GroupBox4 = New System.Windows.Forms.GroupBox()
        Me.Button24 = New System.Windows.Forms.Button()
        Me.Button31 = New System.Windows.Forms.Button()
        Me.Button30 = New System.Windows.Forms.Button()
        Me.Button33 = New System.Windows.Forms.Button()
        Me.Button32 = New System.Windows.Forms.Button()
        Me.Button26 = New System.Windows.Forms.Button()
        Me.Button25 = New System.Windows.Forms.Button()
        Me.Button29 = New System.Windows.Forms.Button()
        Me.Button28 = New System.Windows.Forms.Button()
        Me.Button27 = New System.Windows.Forms.Button()
        Me.GroupBox5 = New System.Windows.Forms.GroupBox()
        Me.Button38 = New System.Windows.Forms.Button()
        Me.Button35 = New System.Windows.Forms.Button()
        Me.Button37 = New System.Windows.Forms.Button()
        Me.Button34 = New System.Windows.Forms.Button()
        Me.Button36 = New System.Windows.Forms.Button()
        Me.GroupBox6 = New System.Windows.Forms.GroupBox()
        Me.Button42 = New System.Windows.Forms.Button()
        Me.Button39 = New System.Windows.Forms.Button()
        Me.Button41 = New System.Windows.Forms.Button()
        Me.Button40 = New System.Windows.Forms.Button()
        Me.GroupBox7 = New System.Windows.Forms.GroupBox()
        Me.Button46 = New System.Windows.Forms.Button()
        Me.Button44 = New System.Windows.Forms.Button()
        Me.Button45 = New System.Windows.Forms.Button()
        Me.Button43 = New System.Windows.Forms.Button()
        Me.GroupBox8 = New System.Windows.Forms.GroupBox()
        Me.Button50 = New System.Windows.Forms.Button()
        Me.Button48 = New System.Windows.Forms.Button()
        Me.Button49 = New System.Windows.Forms.Button()
        Me.Button47 = New System.Windows.Forms.Button()
        Me.GroupBox9 = New System.Windows.Forms.GroupBox()
        Me.Button54 = New System.Windows.Forms.Button()
        Me.Button53 = New System.Windows.Forms.Button()
        Me.Button51 = New System.Windows.Forms.Button()
        Me.Button52 = New System.Windows.Forms.Button()
        Me.GroupBox10 = New System.Windows.Forms.GroupBox()
        Me.Button58 = New System.Windows.Forms.Button()
        Me.Button57 = New System.Windows.Forms.Button()
        Me.Button56 = New System.Windows.Forms.Button()
        Me.Button55 = New System.Windows.Forms.Button()
        Me.Button20 = New System.Windows.Forms.Button()
        Me.SpaceLabel = New System.Windows.Forms.Label()
        Me.ProjectSidePanel = New System.Windows.Forms.Panel()
        Me.ProjectSidePanelContainer = New System.Windows.Forms.Panel()
        Me.SidePanel_ProjectView = New System.Windows.Forms.Panel()
        Me.Label55 = New System.Windows.Forms.Label()
        Me.PrjTasks = New System.Windows.Forms.TableLayoutPanel()
        Me.LinkLabel17 = New System.Windows.Forms.LinkLabel()
        Me.PictureBox11 = New System.Windows.Forms.PictureBox()
        Me.LinkLabel16 = New System.Windows.Forms.LinkLabel()
        Me.PictureBox10 = New System.Windows.Forms.PictureBox()
        Me.LinkLabel15 = New System.Windows.Forms.LinkLabel()
        Me.PictureBox9 = New System.Windows.Forms.PictureBox()
        Me.Button21 = New System.Windows.Forms.Button()
        Me.Button22 = New System.Windows.Forms.Button()
        Me.Button23 = New System.Windows.Forms.Button()
        Me.TableLayoutPanel6 = New System.Windows.Forms.TableLayoutPanel()
        Me.LinkLabel14 = New System.Windows.Forms.LinkLabel()
        Me.Label50 = New System.Windows.Forms.Label()
        Me.Label51 = New System.Windows.Forms.Label()
        Me.Label52 = New System.Windows.Forms.Label()
        Me.Label53 = New System.Windows.Forms.Label()
        Me.Panel13 = New System.Windows.Forms.Panel()
        Me.Label54 = New System.Windows.Forms.Label()
        Me.Label49 = New System.Windows.Forms.Label()
        Me.SidePanel_ImageView = New System.Windows.Forms.Panel()
        Me.ImageView_NoImage = New System.Windows.Forms.Panel()
        Me.Label59 = New System.Windows.Forms.Label()
        Me.Label58 = New System.Windows.Forms.Label()
        Me.Label57 = New System.Windows.Forms.Label()
        Me.TableLayoutPanel7 = New System.Windows.Forms.TableLayoutPanel()
        Me.LinkLabel18 = New System.Windows.Forms.LinkLabel()
        Me.PictureBox12 = New System.Windows.Forms.PictureBox()
        Me.LinkLabel21 = New System.Windows.Forms.LinkLabel()
        Me.PictureBox15 = New System.Windows.Forms.PictureBox()
        Me.ImageView_BasicInfo = New System.Windows.Forms.Panel()
        Me.Label56 = New System.Windows.Forms.Label()
        Me.ImgTasks = New System.Windows.Forms.TableLayoutPanel()
        Me.LinkLabel19 = New System.Windows.Forms.LinkLabel()
        Me.PictureBox13 = New System.Windows.Forms.PictureBox()
        Me.LinkLabel20 = New System.Windows.Forms.LinkLabel()
        Me.PictureBox14 = New System.Windows.Forms.PictureBox()
        Me.TableLayoutPanel5 = New System.Windows.Forms.TableLayoutPanel()
        Me.Label39 = New System.Windows.Forms.Label()
        Me.Label40 = New System.Windows.Forms.Label()
        Me.Label41 = New System.Windows.Forms.Label()
        Me.Label42 = New System.Windows.Forms.Label()
        Me.Label43 = New System.Windows.Forms.Label()
        Me.Label44 = New System.Windows.Forms.Label()
        Me.Label45 = New System.Windows.Forms.Label()
        Me.Label46 = New System.Windows.Forms.Label()
        Me.Label47 = New System.Windows.Forms.Label()
        Me.Label48 = New System.Windows.Forms.Label()
        Me.Panel10 = New System.Windows.Forms.Panel()
        Me.TableLayoutPanel4 = New System.Windows.Forms.TableLayoutPanel()
        Me.LinkLabel12 = New System.Windows.Forms.LinkLabel()
        Me.LinkLabel13 = New System.Windows.Forms.LinkLabel()
        Me.ProjectViewHeader = New System.Windows.Forms.Panel()
        Me.TimeLabel = New System.Windows.Forms.Label()
        Me.GreetingLabel = New System.Windows.Forms.Label()
        Me.SplitPanels = New System.Windows.Forms.SplitContainer()
        Me.TabControl1 = New System.Windows.Forms.TabControl()
        Me.TabPage1 = New System.Windows.Forms.TabPage()
        Me.UnloadBtn = New System.Windows.Forms.Button()
        Me.ExplorerView = New System.Windows.Forms.Button()
        Me.Button14 = New System.Windows.Forms.Button()
        Me.TabTitleSummary1 = New System.Windows.Forms.Panel()
        Me.TabPageIcon1 = New System.Windows.Forms.PictureBox()
        Me.TabPageDescription1 = New System.Windows.Forms.Label()
        Me.TabPageTitle1 = New System.Windows.Forms.Label()
        Me.TableLayoutPanel2 = New System.Windows.Forms.TableLayoutPanel()
        Me.ProjNameEditBtn = New System.Windows.Forms.Button()
        Me.LinkLabel1 = New System.Windows.Forms.LinkLabel()
        Me.Panel8 = New System.Windows.Forms.Panel()
        Me.projName = New System.Windows.Forms.Label()
        Me.projNameText = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Panel9 = New System.Windows.Forms.Panel()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.TabPage2 = New System.Windows.Forms.TabPage()
        Me.ImageNotMountedPanel = New System.Windows.Forms.Panel()
        Me.LinkLabel3 = New System.Windows.Forms.LinkLabel()
        Me.LinkLabel2 = New System.Windows.Forms.LinkLabel()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.ImagePanel = New System.Windows.Forms.Panel()
        Me.Button16 = New System.Windows.Forms.Button()
        Me.TabTitleSummary2 = New System.Windows.Forms.Panel()
        Me.TabPageIcon2 = New System.Windows.Forms.PictureBox()
        Me.TabPageDescription2 = New System.Windows.Forms.Label()
        Me.TabPageTitle2 = New System.Windows.Forms.Label()
        Me.Button15 = New System.Windows.Forms.Button()
        Me.TableLayoutPanel1 = New System.Windows.Forms.TableLayoutPanel()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.TabControl2 = New System.Windows.Forms.TabControl()
        Me.TabPage3 = New System.Windows.Forms.TabPage()
        Me.OldActionPanel = New System.Windows.Forms.Panel()
        Me.Button19 = New System.Windows.Forms.Button()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.Button8 = New System.Windows.Forms.Button()
        Me.Button9 = New System.Windows.Forms.Button()
        Me.Button10 = New System.Windows.Forms.Button()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.Button13 = New System.Windows.Forms.Button()
        Me.Button11 = New System.Windows.Forms.Button()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.Button6 = New System.Windows.Forms.Button()
        Me.Button7 = New System.Windows.Forms.Button()
        Me.Button5 = New System.Windows.Forms.Button()
        Me.Button12 = New System.Windows.Forms.Button()
        Me.ToolStrip1 = New System.Windows.Forms.ToolStrip()
        Me.ToolStripButton1 = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripButton2 = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripSeparator14 = New System.Windows.Forms.ToolStripSeparator()
        Me.ToolStripButton3 = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripSeparator15 = New System.Windows.Forms.ToolStripSeparator()
        Me.ToolStripButton4 = New System.Windows.Forms.ToolStripButton()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.prjTreeView = New System.Windows.Forms.TreeView()
        Me.ToolStrip2 = New System.Windows.Forms.ToolStrip()
        Me.RefreshViewTSB = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripSeparator17 = New System.Windows.Forms.ToolStripSeparator()
        Me.ExpandCollapseTSB = New System.Windows.Forms.ToolStripButton()
        Me.prjTreeStatus = New System.Windows.Forms.StatusStrip()
        Me.ToolStripStatusLabel2 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.ToolStripProgressBar1 = New System.Windows.Forms.ToolStripProgressBar()
        Me.StatusStrip = New System.Windows.Forms.StatusStrip()
        Me.BackgroundProcessesButton = New System.Windows.Forms.ToolStripSplitButton()
        Me.MenuDesc = New System.Windows.Forms.ToolStripStatusLabel()
        Me.OpenFileDialog1 = New System.Windows.Forms.OpenFileDialog()
        Me.PkgInfoCMS = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.PkgBasicInfo = New System.Windows.Forms.ToolStripMenuItem()
        Me.PkgDetailedInfo = New System.Windows.Forms.ToolStripMenuItem()
        Me.ImgBW = New System.ComponentModel.BackgroundWorker()
        Me.ImgProcesses = New System.Diagnostics.Process()
        Me.LocalMountDirFBD = New System.Windows.Forms.FolderBrowserDialog()
        Me.MountedImageDetectorBW = New System.ComponentModel.BackgroundWorker()
        Me.ImgUMountPopupCMS = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.CommitAndUnmountTSMI = New System.Windows.Forms.ToolStripMenuItem()
        Me.DiscardAndUnmountTSMI = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator20 = New System.Windows.Forms.ToolStripSeparator()
        Me.UnmountSettingsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AppxPackagePopupCMS = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.ViewPackageDirectoryToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ResViewTSMI = New System.Windows.Forms.ToolStripMenuItem()
        Me.TreeViewCMS = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.ExpandToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AccessDirectoryToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator23 = New System.Windows.Forms.ToolStripSeparator()
        Me.UnloadProjectToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator24 = New System.Windows.Forms.ToolStripSeparator()
        Me.CopyDeploymentToolsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.OfAllArchitecturesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.OfSelectedArchitectureToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator25 = New System.Windows.Forms.ToolStripSeparator()
        Me.ForX86ArchitectureToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ForAmd64ArchitectureToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ForARMArchitectureToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ForARM64ArchitectureToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator27 = New System.Windows.Forms.ToolStripSeparator()
        Me.ImageOperationsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MountImageToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.UnmountImageToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator29 = New System.Windows.Forms.ToolStripSeparator()
        Me.RemoveVolumeImagesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SwitchImageIndexesToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator30 = New System.Windows.Forms.ToolStripSeparator()
        Me.UnattendedAnswerFilesToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ManageToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CreationWizardToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator31 = New System.Windows.Forms.ToolStripSeparator()
        Me.ScratchDirectorySettingsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator32 = New System.Windows.Forms.ToolStripSeparator()
        Me.ManageReportsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator33 = New System.Windows.Forms.ToolStripSeparator()
        Me.AddToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.NewFileToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ExistingFileToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ADKCopierBW = New System.ComponentModel.BackgroundWorker()
        Me.UpdCheckerBW = New System.ComponentModel.BackgroundWorker()
        Me.AppxResCMS = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.SaveResourceToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CopyToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AppxResSFD = New System.Windows.Forms.SaveFileDialog()
        Me.Notifications = New System.Windows.Forms.NotifyIcon(Me.components)
        Me.AppxRelatedLinksCMS = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.MicrosoftAppsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MicrosoftStoreGenerationProjectToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator36 = New System.Windows.Forms.ToolStripSeparator()
        Me.AppxDownloadHelpToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ImgInfoSFD = New System.Windows.Forms.SaveFileDialog()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.FeedWorker = New System.ComponentModel.BackgroundWorker()
        Me.Timer2 = New System.Windows.Forms.Timer(Me.components)
        Me.WatcherBW = New System.ComponentModel.BackgroundWorker()
        Me.WatcherTimer = New System.Windows.Forms.Timer(Me.components)
        Me.ImgSpecialToolsCMS = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.GetImageFileInformationToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator39 = New System.Windows.Forms.ToolStripSeparator()
        Me.SaveCompleteImageInformationToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator40 = New System.Windows.Forms.ToolStripSeparator()
        Me.CreateDiscImageWithThisFileToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.WIEDownloaderBW = New System.ComponentModel.BackgroundWorker()
        Me.VideoGetterBW = New System.ComponentModel.BackgroundWorker()
        Me.MountedImageDetectorBWRestarterTimer = New System.Windows.Forms.Timer(Me.components)
        Me.MenuStrip1.SuspendLayout()
        Me.HomePanel.SuspendLayout()
        Me.WelcomePanel.SuspendLayout()
        Me.StartPanel.SuspendLayout()
        Me.StartPanelPContainer.SuspendLayout()
        Me.GetStartedPanel.SuspendLayout()
        Me.GetStartedContainer.SuspendLayout()
        Me.Panel6.SuspendLayout()
        CType(Me.PictureBox8, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox7, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox6, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.LatestNewsPanel.SuspendLayout()
        Me.FeedContainer.SuspendLayout()
        Me.FeedsPanel.SuspendLayout()
        Me.FeedErrorPanel.SuspendLayout()
        Me.Panel4.SuspendLayout()
        Me.TutorialVideoPanel.SuspendLayout()
        Me.VideoContainer.SuspendLayout()
        Me.VideosPanel.SuspendLayout()
        Me.VideoErrorPanel.SuspendLayout()
        Me.Panel1.SuspendLayout()
        Me.FlowLayoutPanel2.SuspendLayout()
        Me.SidePanel.SuspendLayout()
        Me.UpdatePanel.SuspendLayout()
        Me.Panel3.SuspendLayout()
        CType(Me.PictureBox5, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.PrjPanel.SuspendLayout()
        Me.ProjectView.SuspendLayout()
        Me.Panel11.SuspendLayout()
        Me.FlowLayoutPanel1.SuspendLayout()
        Me.GroupBox4.SuspendLayout()
        Me.GroupBox5.SuspendLayout()
        Me.GroupBox6.SuspendLayout()
        Me.GroupBox7.SuspendLayout()
        Me.GroupBox8.SuspendLayout()
        Me.GroupBox9.SuspendLayout()
        Me.GroupBox10.SuspendLayout()
        Me.ProjectSidePanel.SuspendLayout()
        Me.ProjectSidePanelContainer.SuspendLayout()
        Me.SidePanel_ProjectView.SuspendLayout()
        Me.PrjTasks.SuspendLayout()
        CType(Me.PictureBox11, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox10, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox9, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TableLayoutPanel6.SuspendLayout()
        Me.Panel13.SuspendLayout()
        Me.SidePanel_ImageView.SuspendLayout()
        Me.ImageView_NoImage.SuspendLayout()
        Me.TableLayoutPanel7.SuspendLayout()
        CType(Me.PictureBox12, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox15, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.ImageView_BasicInfo.SuspendLayout()
        Me.ImgTasks.SuspendLayout()
        CType(Me.PictureBox13, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox14, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TableLayoutPanel5.SuspendLayout()
        Me.Panel10.SuspendLayout()
        Me.TableLayoutPanel4.SuspendLayout()
        Me.ProjectViewHeader.SuspendLayout()
        CType(Me.SplitPanels, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SplitPanels.Panel1.SuspendLayout()
        Me.SplitPanels.Panel2.SuspendLayout()
        Me.SplitPanels.SuspendLayout()
        Me.TabControl1.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        Me.TabTitleSummary1.SuspendLayout()
        CType(Me.TabPageIcon1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TableLayoutPanel2.SuspendLayout()
        Me.Panel8.SuspendLayout()
        Me.Panel9.SuspendLayout()
        Me.TabPage2.SuspendLayout()
        Me.ImageNotMountedPanel.SuspendLayout()
        Me.ImagePanel.SuspendLayout()
        Me.TabTitleSummary2.SuspendLayout()
        CType(Me.TabPageIcon2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TableLayoutPanel1.SuspendLayout()
        Me.TabControl2.SuspendLayout()
        Me.TabPage3.SuspendLayout()
        Me.OldActionPanel.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.ToolStrip1.SuspendLayout()
        Me.Panel2.SuspendLayout()
        Me.ToolStrip2.SuspendLayout()
        Me.prjTreeStatus.SuspendLayout()
        Me.StatusStrip.SuspendLayout()
        Me.PkgInfoCMS.SuspendLayout()
        Me.ImgUMountPopupCMS.SuspendLayout()
        Me.AppxPackagePopupCMS.SuspendLayout()
        Me.TreeViewCMS.SuspendLayout()
        Me.AppxResCMS.SuspendLayout()
        Me.AppxRelatedLinksCMS.SuspendLayout()
        Me.ImgSpecialToolsCMS.SuspendLayout()
        Me.SuspendLayout()
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.FileToolStripMenuItem, Me.ProjectToolStripMenuItem, Me.CommandsToolStripMenuItem, Me.ToolsToolStripMenuItem, Me.HelpToolStripMenuItem, Me.BranchTSMI, Me.VersionTSMI, Me.InvalidSettingsTSMI})
        Me.MenuStrip1.LayoutStyle = System.Windows.Forms.ToolStripLayoutStyle.HorizontalStackWithOverflow
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(1264, 24)
        Me.MenuStrip1.TabIndex = 1
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'FileToolStripMenuItem
        '
        Me.FileToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.NewProjectToolStripMenuItem, Me.OpenExistingProjectToolStripMenuItem, Me.ToolStripSeparator26, Me.ManageOnlineInstallationToolStripMenuItem, Me.ManageOfflineInstallationToolStripMenuItem, Me.ToolStripSeparator37, Me.RecentProjectsListMenu, Me.ToolStripSeparator1, Me.SaveProjectToolStripMenuItem, Me.SaveProjectasToolStripMenuItem, Me.ToolStripSeparator2, Me.ExitToolStripMenuItem})
        Me.FileToolStripMenuItem.Name = "FileToolStripMenuItem"
        Me.FileToolStripMenuItem.Size = New System.Drawing.Size(37, 20)
        Me.FileToolStripMenuItem.Text = "&File"
        '
        'NewProjectToolStripMenuItem
        '
        Me.NewProjectToolStripMenuItem.Name = "NewProjectToolStripMenuItem"
        Me.NewProjectToolStripMenuItem.Size = New System.Drawing.Size(224, 22)
        Me.NewProjectToolStripMenuItem.Text = "&New project..."
        '
        'OpenExistingProjectToolStripMenuItem
        '
        Me.OpenExistingProjectToolStripMenuItem.Name = "OpenExistingProjectToolStripMenuItem"
        Me.OpenExistingProjectToolStripMenuItem.Size = New System.Drawing.Size(224, 22)
        Me.OpenExistingProjectToolStripMenuItem.Text = "&Open existing project"
        '
        'ToolStripSeparator26
        '
        Me.ToolStripSeparator26.Name = "ToolStripSeparator26"
        Me.ToolStripSeparator26.Size = New System.Drawing.Size(221, 6)
        '
        'ManageOnlineInstallationToolStripMenuItem
        '
        Me.ManageOnlineInstallationToolStripMenuItem.Name = "ManageOnlineInstallationToolStripMenuItem"
        Me.ManageOnlineInstallationToolStripMenuItem.Size = New System.Drawing.Size(224, 22)
        Me.ManageOnlineInstallationToolStripMenuItem.Text = "&Manage online installation"
        '
        'ManageOfflineInstallationToolStripMenuItem
        '
        Me.ManageOfflineInstallationToolStripMenuItem.Name = "ManageOfflineInstallationToolStripMenuItem"
        Me.ManageOfflineInstallationToolStripMenuItem.Size = New System.Drawing.Size(224, 22)
        Me.ManageOfflineInstallationToolStripMenuItem.Text = "Manage o&ffline installation..."
        '
        'ToolStripSeparator37
        '
        Me.ToolStripSeparator37.Name = "ToolStripSeparator37"
        Me.ToolStripSeparator37.Size = New System.Drawing.Size(221, 6)
        '
        'RecentProjectsListMenu
        '
        Me.RecentProjectsListMenu.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.RecentProject1ToolStripMenuItem, Me.RecentProject2ToolStripMenuItem, Me.RecentProject3ToolStripMenuItem, Me.RecentProject4ToolStripMenuItem, Me.RecentProject5ToolStripMenuItem, Me.RecentProject6ToolStripMenuItem, Me.RecentProject7ToolStripMenuItem, Me.RecentProject8ToolStripMenuItem, Me.RecentProject9ToolStripMenuItem, Me.RecentProject10ToolStripMenuItem})
        Me.RecentProjectsListMenu.Name = "RecentProjectsListMenu"
        Me.RecentProjectsListMenu.Size = New System.Drawing.Size(224, 22)
        Me.RecentProjectsListMenu.Text = "Recent projects"
        '
        'RecentProject1ToolStripMenuItem
        '
        Me.RecentProject1ToolStripMenuItem.Name = "RecentProject1ToolStripMenuItem"
        Me.RecentProject1ToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.D1), System.Windows.Forms.Keys)
        Me.RecentProject1ToolStripMenuItem.Size = New System.Drawing.Size(107, 22)
        Me.RecentProject1ToolStripMenuItem.Visible = False
        '
        'RecentProject2ToolStripMenuItem
        '
        Me.RecentProject2ToolStripMenuItem.Name = "RecentProject2ToolStripMenuItem"
        Me.RecentProject2ToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.D2), System.Windows.Forms.Keys)
        Me.RecentProject2ToolStripMenuItem.Size = New System.Drawing.Size(107, 22)
        Me.RecentProject2ToolStripMenuItem.Visible = False
        '
        'RecentProject3ToolStripMenuItem
        '
        Me.RecentProject3ToolStripMenuItem.Name = "RecentProject3ToolStripMenuItem"
        Me.RecentProject3ToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.D3), System.Windows.Forms.Keys)
        Me.RecentProject3ToolStripMenuItem.Size = New System.Drawing.Size(107, 22)
        Me.RecentProject3ToolStripMenuItem.Visible = False
        '
        'RecentProject4ToolStripMenuItem
        '
        Me.RecentProject4ToolStripMenuItem.Name = "RecentProject4ToolStripMenuItem"
        Me.RecentProject4ToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.D4), System.Windows.Forms.Keys)
        Me.RecentProject4ToolStripMenuItem.Size = New System.Drawing.Size(107, 22)
        Me.RecentProject4ToolStripMenuItem.Visible = False
        '
        'RecentProject5ToolStripMenuItem
        '
        Me.RecentProject5ToolStripMenuItem.Name = "RecentProject5ToolStripMenuItem"
        Me.RecentProject5ToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.D5), System.Windows.Forms.Keys)
        Me.RecentProject5ToolStripMenuItem.Size = New System.Drawing.Size(107, 22)
        Me.RecentProject5ToolStripMenuItem.Visible = False
        '
        'RecentProject6ToolStripMenuItem
        '
        Me.RecentProject6ToolStripMenuItem.Name = "RecentProject6ToolStripMenuItem"
        Me.RecentProject6ToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.D6), System.Windows.Forms.Keys)
        Me.RecentProject6ToolStripMenuItem.Size = New System.Drawing.Size(107, 22)
        Me.RecentProject6ToolStripMenuItem.Visible = False
        '
        'RecentProject7ToolStripMenuItem
        '
        Me.RecentProject7ToolStripMenuItem.Name = "RecentProject7ToolStripMenuItem"
        Me.RecentProject7ToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.D7), System.Windows.Forms.Keys)
        Me.RecentProject7ToolStripMenuItem.Size = New System.Drawing.Size(107, 22)
        Me.RecentProject7ToolStripMenuItem.Visible = False
        '
        'RecentProject8ToolStripMenuItem
        '
        Me.RecentProject8ToolStripMenuItem.Name = "RecentProject8ToolStripMenuItem"
        Me.RecentProject8ToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.D8), System.Windows.Forms.Keys)
        Me.RecentProject8ToolStripMenuItem.Size = New System.Drawing.Size(107, 22)
        Me.RecentProject8ToolStripMenuItem.Visible = False
        '
        'RecentProject9ToolStripMenuItem
        '
        Me.RecentProject9ToolStripMenuItem.Name = "RecentProject9ToolStripMenuItem"
        Me.RecentProject9ToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.D9), System.Windows.Forms.Keys)
        Me.RecentProject9ToolStripMenuItem.Size = New System.Drawing.Size(107, 22)
        Me.RecentProject9ToolStripMenuItem.Visible = False
        '
        'RecentProject10ToolStripMenuItem
        '
        Me.RecentProject10ToolStripMenuItem.Name = "RecentProject10ToolStripMenuItem"
        Me.RecentProject10ToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.D0), System.Windows.Forms.Keys)
        Me.RecentProject10ToolStripMenuItem.Size = New System.Drawing.Size(107, 22)
        Me.RecentProject10ToolStripMenuItem.Visible = False
        '
        'ToolStripSeparator1
        '
        Me.ToolStripSeparator1.Name = "ToolStripSeparator1"
        Me.ToolStripSeparator1.Size = New System.Drawing.Size(221, 6)
        '
        'SaveProjectToolStripMenuItem
        '
        Me.SaveProjectToolStripMenuItem.Enabled = False
        Me.SaveProjectToolStripMenuItem.Name = "SaveProjectToolStripMenuItem"
        Me.SaveProjectToolStripMenuItem.Size = New System.Drawing.Size(224, 22)
        Me.SaveProjectToolStripMenuItem.Text = "&Save project..."
        '
        'SaveProjectasToolStripMenuItem
        '
        Me.SaveProjectasToolStripMenuItem.Enabled = False
        Me.SaveProjectasToolStripMenuItem.Name = "SaveProjectasToolStripMenuItem"
        Me.SaveProjectasToolStripMenuItem.Size = New System.Drawing.Size(224, 22)
        Me.SaveProjectasToolStripMenuItem.Text = "Save project &as..."
        '
        'ToolStripSeparator2
        '
        Me.ToolStripSeparator2.Name = "ToolStripSeparator2"
        Me.ToolStripSeparator2.Size = New System.Drawing.Size(221, 6)
        '
        'ExitToolStripMenuItem
        '
        Me.ExitToolStripMenuItem.Name = "ExitToolStripMenuItem"
        Me.ExitToolStripMenuItem.Size = New System.Drawing.Size(224, 22)
        Me.ExitToolStripMenuItem.Text = "E&xit"
        '
        'ProjectToolStripMenuItem
        '
        Me.ProjectToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ViewProjectFilesInFileExplorerToolStripMenuItem, Me.UnloadProjectToolStripMenuItem, Me.ToolStripSeparator3, Me.SwitchImageIndexesToolStripMenuItem, Me.ToolStripSeparator11, Me.ProjectPropertiesToolStripMenuItem, Me.ImagePropertiesToolStripMenuItem})
        Me.ProjectToolStripMenuItem.Name = "ProjectToolStripMenuItem"
        Me.ProjectToolStripMenuItem.Size = New System.Drawing.Size(56, 20)
        Me.ProjectToolStripMenuItem.Text = "&Project"
        Me.ProjectToolStripMenuItem.Visible = False
        '
        'ViewProjectFilesInFileExplorerToolStripMenuItem
        '
        Me.ViewProjectFilesInFileExplorerToolStripMenuItem.Name = "ViewProjectFilesInFileExplorerToolStripMenuItem"
        Me.ViewProjectFilesInFileExplorerToolStripMenuItem.Size = New System.Drawing.Size(243, 22)
        Me.ViewProjectFilesInFileExplorerToolStripMenuItem.Text = "View project files in File Explorer"
        '
        'UnloadProjectToolStripMenuItem
        '
        Me.UnloadProjectToolStripMenuItem.Name = "UnloadProjectToolStripMenuItem"
        Me.UnloadProjectToolStripMenuItem.Size = New System.Drawing.Size(243, 22)
        Me.UnloadProjectToolStripMenuItem.Text = "Unload project..."
        '
        'ToolStripSeparator3
        '
        Me.ToolStripSeparator3.Name = "ToolStripSeparator3"
        Me.ToolStripSeparator3.Size = New System.Drawing.Size(240, 6)
        '
        'SwitchImageIndexesToolStripMenuItem
        '
        Me.SwitchImageIndexesToolStripMenuItem.Name = "SwitchImageIndexesToolStripMenuItem"
        Me.SwitchImageIndexesToolStripMenuItem.Size = New System.Drawing.Size(243, 22)
        Me.SwitchImageIndexesToolStripMenuItem.Text = "Switch image indexes..."
        '
        'ToolStripSeparator11
        '
        Me.ToolStripSeparator11.Name = "ToolStripSeparator11"
        Me.ToolStripSeparator11.Size = New System.Drawing.Size(240, 6)
        '
        'ProjectPropertiesToolStripMenuItem
        '
        Me.ProjectPropertiesToolStripMenuItem.Name = "ProjectPropertiesToolStripMenuItem"
        Me.ProjectPropertiesToolStripMenuItem.Size = New System.Drawing.Size(243, 22)
        Me.ProjectPropertiesToolStripMenuItem.Text = "Project properties"
        '
        'ImagePropertiesToolStripMenuItem
        '
        Me.ImagePropertiesToolStripMenuItem.Name = "ImagePropertiesToolStripMenuItem"
        Me.ImagePropertiesToolStripMenuItem.Size = New System.Drawing.Size(243, 22)
        Me.ImagePropertiesToolStripMenuItem.Text = "Image properties"
        '
        'CommandsToolStripMenuItem
        '
        Me.CommandsToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ImageManagementToolStripMenuItem, Me.OSPackagesToolStripMenuItem, Me.ProvisioningPackagesToolStripMenuItem, Me.AppPackagesToolStripMenuItem, Me.AppPatchesToolStripMenuItem, Me.DefaultAppAssociationsToolStripMenuItem, Me.LanguagesAndRegionSettingsToolStripMenuItem, Me.CapabilitiesToolStripMenuItem, Me.WindowsEditionsToolStripMenuItem, Me.DriversToolStripMenuItem, Me.UnattendedAnswerFilesToolStripMenuItem, Me.WindowsPEServicingToolStripMenuItem, Me.OSUninstallToolStripMenuItem, Me.ReservedStorageToolStripMenuItem, Me.MicrosoftEdgeToolStripMenuItem})
        Me.CommandsToolStripMenuItem.Name = "CommandsToolStripMenuItem"
        Me.CommandsToolStripMenuItem.Size = New System.Drawing.Size(81, 20)
        Me.CommandsToolStripMenuItem.Text = "Com&mands"
        Me.CommandsToolStripMenuItem.Visible = False
        '
        'ImageManagementToolStripMenuItem
        '
        Me.ImageManagementToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.AppendImage, Me.ApplyFFU, Me.ApplyImage, Me.CaptureCustomImage, Me.CaptureFFU, Me.CaptureImage, Me.CleanupMountpoints, Me.CommitImage, Me.DeleteImage, Me.ExportImage, Me.GetImageInfo, Me.GetWIMBootEntry, Me.ListImage, Me.MountImage, Me.OptimizeFFU, Me.OptimizeImage, Me.RemountImage, Me.SplitFFU, Me.SplitImage, Me.UnmountImage, Me.UpdateWIMBootEntry, Me.ApplySiloedPackage, Me.ToolStripSeparator34, Me.SaveImageInformationToolStripMenuItem})
        Me.ImageManagementToolStripMenuItem.Name = "ImageManagementToolStripMenuItem"
        Me.ImageManagementToolStripMenuItem.Size = New System.Drawing.Size(244, 22)
        Me.ImageManagementToolStripMenuItem.Text = "Image management"
        '
        'AppendImage
        '
        Me.AppendImage.Name = "AppendImage"
        Me.AppendImage.Size = New System.Drawing.Size(289, 22)
        Me.AppendImage.Text = "Append capture directory to image..."
        '
        'ApplyFFU
        '
        Me.ApplyFFU.Name = "ApplyFFU"
        Me.ApplyFFU.Size = New System.Drawing.Size(289, 22)
        Me.ApplyFFU.Text = "Apply FFU or SFU file..."
        '
        'ApplyImage
        '
        Me.ApplyImage.Name = "ApplyImage"
        Me.ApplyImage.Size = New System.Drawing.Size(289, 22)
        Me.ApplyImage.Text = "Apply WIM or SWM file..."
        '
        'CaptureCustomImage
        '
        Me.CaptureCustomImage.Name = "CaptureCustomImage"
        Me.CaptureCustomImage.Size = New System.Drawing.Size(289, 22)
        Me.CaptureCustomImage.Text = "Capture incremental changes to file..."
        '
        'CaptureFFU
        '
        Me.CaptureFFU.Name = "CaptureFFU"
        Me.CaptureFFU.Size = New System.Drawing.Size(289, 22)
        Me.CaptureFFU.Text = "Capture partitions to FFU file..."
        '
        'CaptureImage
        '
        Me.CaptureImage.Name = "CaptureImage"
        Me.CaptureImage.Size = New System.Drawing.Size(289, 22)
        Me.CaptureImage.Text = "Capture image of a drive to WIM file..."
        '
        'CleanupMountpoints
        '
        Me.CleanupMountpoints.Name = "CleanupMountpoints"
        Me.CleanupMountpoints.Size = New System.Drawing.Size(289, 22)
        Me.CleanupMountpoints.Text = "Delete resources from corrupted image..."
        '
        'CommitImage
        '
        Me.CommitImage.Name = "CommitImage"
        Me.CommitImage.Size = New System.Drawing.Size(289, 22)
        Me.CommitImage.Text = "Apply changes to image..."
        '
        'DeleteImage
        '
        Me.DeleteImage.Name = "DeleteImage"
        Me.DeleteImage.Size = New System.Drawing.Size(289, 22)
        Me.DeleteImage.Text = "Delete volume image from WIM file..."
        '
        'ExportImage
        '
        Me.ExportImage.Name = "ExportImage"
        Me.ExportImage.Size = New System.Drawing.Size(289, 22)
        Me.ExportImage.Text = "Export image..."
        '
        'GetImageInfo
        '
        Me.GetImageInfo.Name = "GetImageInfo"
        Me.GetImageInfo.Size = New System.Drawing.Size(289, 22)
        Me.GetImageInfo.Text = "Get image information..."
        '
        'GetWIMBootEntry
        '
        Me.GetWIMBootEntry.Name = "GetWIMBootEntry"
        Me.GetWIMBootEntry.Size = New System.Drawing.Size(289, 22)
        Me.GetWIMBootEntry.Text = "Get WIMBoot configuration entries..."
        '
        'ListImage
        '
        Me.ListImage.Name = "ListImage"
        Me.ListImage.Size = New System.Drawing.Size(289, 22)
        Me.ListImage.Text = "List files and directories in image..."
        '
        'MountImage
        '
        Me.MountImage.Name = "MountImage"
        Me.MountImage.Size = New System.Drawing.Size(289, 22)
        Me.MountImage.Text = "Mount image..."
        '
        'OptimizeFFU
        '
        Me.OptimizeFFU.Name = "OptimizeFFU"
        Me.OptimizeFFU.Size = New System.Drawing.Size(289, 22)
        Me.OptimizeFFU.Text = "Optimize FFU file..."
        '
        'OptimizeImage
        '
        Me.OptimizeImage.Name = "OptimizeImage"
        Me.OptimizeImage.Size = New System.Drawing.Size(289, 22)
        Me.OptimizeImage.Text = "Optimize image..."
        '
        'RemountImage
        '
        Me.RemountImage.Name = "RemountImage"
        Me.RemountImage.Size = New System.Drawing.Size(289, 22)
        Me.RemountImage.Text = "Remount image for servicing..."
        '
        'SplitFFU
        '
        Me.SplitFFU.Name = "SplitFFU"
        Me.SplitFFU.Size = New System.Drawing.Size(289, 22)
        Me.SplitFFU.Text = "Splt FFU file into SFU files..."
        '
        'SplitImage
        '
        Me.SplitImage.Name = "SplitImage"
        Me.SplitImage.Size = New System.Drawing.Size(289, 22)
        Me.SplitImage.Text = "Split WIM file into SWM files..."
        '
        'UnmountImage
        '
        Me.UnmountImage.Name = "UnmountImage"
        Me.UnmountImage.Size = New System.Drawing.Size(289, 22)
        Me.UnmountImage.Text = "Unmount image..."
        '
        'UpdateWIMBootEntry
        '
        Me.UpdateWIMBootEntry.Name = "UpdateWIMBootEntry"
        Me.UpdateWIMBootEntry.Size = New System.Drawing.Size(289, 22)
        Me.UpdateWIMBootEntry.Text = "Update WIMBoot configuration entry..."
        '
        'ApplySiloedPackage
        '
        Me.ApplySiloedPackage.Name = "ApplySiloedPackage"
        Me.ApplySiloedPackage.Size = New System.Drawing.Size(289, 22)
        Me.ApplySiloedPackage.Text = "Apply siloed provisioning package..."
        '
        'ToolStripSeparator34
        '
        Me.ToolStripSeparator34.Name = "ToolStripSeparator34"
        Me.ToolStripSeparator34.Size = New System.Drawing.Size(286, 6)
        '
        'SaveImageInformationToolStripMenuItem
        '
        Me.SaveImageInformationToolStripMenuItem.Name = "SaveImageInformationToolStripMenuItem"
        Me.SaveImageInformationToolStripMenuItem.Size = New System.Drawing.Size(289, 22)
        Me.SaveImageInformationToolStripMenuItem.Text = "Save image information..."
        '
        'OSPackagesToolStripMenuItem
        '
        Me.OSPackagesToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.GetPackages, Me.AddPackage, Me.RemovePackage, Me.GetFeatures, Me.EnableFeature, Me.DisableFeature, Me.ToolStripSeparator4, Me.CleanupImage})
        Me.OSPackagesToolStripMenuItem.Name = "OSPackagesToolStripMenuItem"
        Me.OSPackagesToolStripMenuItem.Size = New System.Drawing.Size(244, 22)
        Me.OSPackagesToolStripMenuItem.Text = "OS packages"
        '
        'GetPackages
        '
        Me.GetPackages.Name = "GetPackages"
        Me.GetPackages.Size = New System.Drawing.Size(292, 22)
        Me.GetPackages.Text = "Get package information..."
        '
        'AddPackage
        '
        Me.AddPackage.Name = "AddPackage"
        Me.AddPackage.Size = New System.Drawing.Size(292, 22)
        Me.AddPackage.Text = "Add package..."
        '
        'RemovePackage
        '
        Me.RemovePackage.Name = "RemovePackage"
        Me.RemovePackage.Size = New System.Drawing.Size(292, 22)
        Me.RemovePackage.Text = "Remove package..."
        '
        'GetFeatures
        '
        Me.GetFeatures.Name = "GetFeatures"
        Me.GetFeatures.Size = New System.Drawing.Size(292, 22)
        Me.GetFeatures.Text = "Get feature information..."
        '
        'EnableFeature
        '
        Me.EnableFeature.Name = "EnableFeature"
        Me.EnableFeature.Size = New System.Drawing.Size(292, 22)
        Me.EnableFeature.Text = "Enable feature..."
        '
        'DisableFeature
        '
        Me.DisableFeature.Name = "DisableFeature"
        Me.DisableFeature.Size = New System.Drawing.Size(292, 22)
        Me.DisableFeature.Text = "Disable feature..."
        '
        'ToolStripSeparator4
        '
        Me.ToolStripSeparator4.Name = "ToolStripSeparator4"
        Me.ToolStripSeparator4.Size = New System.Drawing.Size(289, 6)
        '
        'CleanupImage
        '
        Me.CleanupImage.Name = "CleanupImage"
        Me.CleanupImage.Size = New System.Drawing.Size(292, 22)
        Me.CleanupImage.Text = "Perform cleanup or recovery operations..."
        '
        'ProvisioningPackagesToolStripMenuItem
        '
        Me.ProvisioningPackagesToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.AddProvisioningPackage, Me.GetProvisioningPackageInfo, Me.ApplyCustomDataImage})
        Me.ProvisioningPackagesToolStripMenuItem.Name = "ProvisioningPackagesToolStripMenuItem"
        Me.ProvisioningPackagesToolStripMenuItem.Size = New System.Drawing.Size(244, 22)
        Me.ProvisioningPackagesToolStripMenuItem.Text = "Provisioning packages"
        '
        'AddProvisioningPackage
        '
        Me.AddProvisioningPackage.Name = "AddProvisioningPackage"
        Me.AddProvisioningPackage.Size = New System.Drawing.Size(283, 22)
        Me.AddProvisioningPackage.Text = "Add provisioning package..."
        '
        'GetProvisioningPackageInfo
        '
        Me.GetProvisioningPackageInfo.Name = "GetProvisioningPackageInfo"
        Me.GetProvisioningPackageInfo.Size = New System.Drawing.Size(283, 22)
        Me.GetProvisioningPackageInfo.Text = "Get provisioning package information..."
        '
        'ApplyCustomDataImage
        '
        Me.ApplyCustomDataImage.Name = "ApplyCustomDataImage"
        Me.ApplyCustomDataImage.Size = New System.Drawing.Size(283, 22)
        Me.ApplyCustomDataImage.Text = "Apply custom data image..."
        '
        'AppPackagesToolStripMenuItem
        '
        Me.AppPackagesToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.GetProvisionedAppxPackages, Me.AddProvisionedAppxPackage, Me.RemoveProvisionedAppxPackage, Me.OptimizeProvisionedAppxPackages, Me.SetProvisionedAppxDataFile})
        Me.AppPackagesToolStripMenuItem.Name = "AppPackagesToolStripMenuItem"
        Me.AppPackagesToolStripMenuItem.Size = New System.Drawing.Size(244, 22)
        Me.AppPackagesToolStripMenuItem.Text = "App packages"
        '
        'GetProvisionedAppxPackages
        '
        Me.GetProvisionedAppxPackages.Name = "GetProvisionedAppxPackages"
        Me.GetProvisionedAppxPackages.Size = New System.Drawing.Size(287, 22)
        Me.GetProvisionedAppxPackages.Text = "Get app package information..."
        '
        'AddProvisionedAppxPackage
        '
        Me.AddProvisionedAppxPackage.Name = "AddProvisionedAppxPackage"
        Me.AddProvisionedAppxPackage.Size = New System.Drawing.Size(287, 22)
        Me.AddProvisionedAppxPackage.Text = "Add provisioned app package..."
        '
        'RemoveProvisionedAppxPackage
        '
        Me.RemoveProvisionedAppxPackage.Name = "RemoveProvisionedAppxPackage"
        Me.RemoveProvisionedAppxPackage.Size = New System.Drawing.Size(287, 22)
        Me.RemoveProvisionedAppxPackage.Text = "Remove provisioning for app package..."
        '
        'OptimizeProvisionedAppxPackages
        '
        Me.OptimizeProvisionedAppxPackages.Name = "OptimizeProvisionedAppxPackages"
        Me.OptimizeProvisionedAppxPackages.Size = New System.Drawing.Size(287, 22)
        Me.OptimizeProvisionedAppxPackages.Text = "Optimize provisioned packages..."
        '
        'SetProvisionedAppxDataFile
        '
        Me.SetProvisionedAppxDataFile.Name = "SetProvisionedAppxDataFile"
        Me.SetProvisionedAppxDataFile.Size = New System.Drawing.Size(287, 22)
        Me.SetProvisionedAppxDataFile.Text = "Add custom data file into app package..."
        '
        'AppPatchesToolStripMenuItem
        '
        Me.AppPatchesToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.CheckAppPatch, Me.GetAppPatchInfo, Me.GetAppPatches, Me.GetAppInfo, Me.GetApps})
        Me.AppPatchesToolStripMenuItem.Name = "AppPatchesToolStripMenuItem"
        Me.AppPatchesToolStripMenuItem.Size = New System.Drawing.Size(244, 22)
        Me.AppPatchesToolStripMenuItem.Text = "App (MSP) servicing"
        '
        'CheckAppPatch
        '
        Me.CheckAppPatch.Name = "CheckAppPatch"
        Me.CheckAppPatch.Size = New System.Drawing.Size(408, 22)
        Me.CheckAppPatch.Text = "Get application patch information..."
        '
        'GetAppPatchInfo
        '
        Me.GetAppPatchInfo.Name = "GetAppPatchInfo"
        Me.GetAppPatchInfo.Size = New System.Drawing.Size(408, 22)
        Me.GetAppPatchInfo.Text = "Get detailed installed application patch information..."
        '
        'GetAppPatches
        '
        Me.GetAppPatches.Name = "GetAppPatches"
        Me.GetAppPatches.Size = New System.Drawing.Size(408, 22)
        Me.GetAppPatches.Text = "Get basic installed application patch information..."
        '
        'GetAppInfo
        '
        Me.GetAppInfo.Name = "GetAppInfo"
        Me.GetAppInfo.Size = New System.Drawing.Size(408, 22)
        Me.GetAppInfo.Text = "Get detailed Windows Installer (*.msi) application information..."
        '
        'GetApps
        '
        Me.GetApps.Name = "GetApps"
        Me.GetApps.Size = New System.Drawing.Size(408, 22)
        Me.GetApps.Text = "Get basic Windows Installer (*.msi) application information..."
        '
        'DefaultAppAssociationsToolStripMenuItem
        '
        Me.DefaultAppAssociationsToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ExportDefaultAppAssociations, Me.GetDefaultAppAssociations, Me.ImportDefaultAppAssociations, Me.RemoveDefaultAppAssociations})
        Me.DefaultAppAssociationsToolStripMenuItem.Name = "DefaultAppAssociationsToolStripMenuItem"
        Me.DefaultAppAssociationsToolStripMenuItem.Size = New System.Drawing.Size(244, 22)
        Me.DefaultAppAssociationsToolStripMenuItem.Text = "Default app associations"
        '
        'ExportDefaultAppAssociations
        '
        Me.ExportDefaultAppAssociations.Name = "ExportDefaultAppAssociations"
        Me.ExportDefaultAppAssociations.Size = New System.Drawing.Size(331, 22)
        Me.ExportDefaultAppAssociations.Text = "Export default application associations..."
        '
        'GetDefaultAppAssociations
        '
        Me.GetDefaultAppAssociations.Name = "GetDefaultAppAssociations"
        Me.GetDefaultAppAssociations.Size = New System.Drawing.Size(331, 22)
        Me.GetDefaultAppAssociations.Text = "Get default application association information..."
        '
        'ImportDefaultAppAssociations
        '
        Me.ImportDefaultAppAssociations.Name = "ImportDefaultAppAssociations"
        Me.ImportDefaultAppAssociations.Size = New System.Drawing.Size(331, 22)
        Me.ImportDefaultAppAssociations.Text = "Import default application associations..."
        '
        'RemoveDefaultAppAssociations
        '
        Me.RemoveDefaultAppAssociations.Name = "RemoveDefaultAppAssociations"
        Me.RemoveDefaultAppAssociations.Size = New System.Drawing.Size(331, 22)
        Me.RemoveDefaultAppAssociations.Text = "Remove default application associations..."
        '
        'LanguagesAndRegionSettingsToolStripMenuItem
        '
        Me.LanguagesAndRegionSettingsToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.GetIntl, Me.SetUILang, Me.SetUILangFallback, Me.SetSysUILang, Me.SetSysLocale, Me.SetUserLocale, Me.SetInputLocale, Me.ToolStripSeparator5, Me.SetAllIntl, Me.ToolStripSeparator6, Me.SetTimeZone, Me.ToolStripSeparator7, Me.SetSKUIntlDefaults, Me.ToolStripSeparator8, Me.SetLayeredDriver, Me.GenLangINI, Me.SetSetupUILang})
        Me.LanguagesAndRegionSettingsToolStripMenuItem.Name = "LanguagesAndRegionSettingsToolStripMenuItem"
        Me.LanguagesAndRegionSettingsToolStripMenuItem.Size = New System.Drawing.Size(244, 22)
        Me.LanguagesAndRegionSettingsToolStripMenuItem.Text = "Languages and regional settings"
        '
        'GetIntl
        '
        Me.GetIntl.Name = "GetIntl"
        Me.GetIntl.Size = New System.Drawing.Size(295, 22)
        Me.GetIntl.Text = "Get international settings and languages..."
        '
        'SetUILang
        '
        Me.SetUILang.Name = "SetUILang"
        Me.SetUILang.Size = New System.Drawing.Size(295, 22)
        Me.SetUILang.Text = "Set UI language..."
        '
        'SetUILangFallback
        '
        Me.SetUILangFallback.Name = "SetUILangFallback"
        Me.SetUILangFallback.Size = New System.Drawing.Size(295, 22)
        Me.SetUILangFallback.Text = "Set default UI fallback language..."
        '
        'SetSysUILang
        '
        Me.SetSysUILang.Name = "SetSysUILang"
        Me.SetSysUILang.Size = New System.Drawing.Size(295, 22)
        Me.SetSysUILang.Text = "Set system preferred UI language..."
        '
        'SetSysLocale
        '
        Me.SetSysLocale.Name = "SetSysLocale"
        Me.SetSysLocale.Size = New System.Drawing.Size(295, 22)
        Me.SetSysLocale.Text = "Set system locale..."
        '
        'SetUserLocale
        '
        Me.SetUserLocale.Name = "SetUserLocale"
        Me.SetUserLocale.Size = New System.Drawing.Size(295, 22)
        Me.SetUserLocale.Text = "Set user locale..."
        '
        'SetInputLocale
        '
        Me.SetInputLocale.Name = "SetInputLocale"
        Me.SetInputLocale.Size = New System.Drawing.Size(295, 22)
        Me.SetInputLocale.Text = "Set input locale..."
        '
        'ToolStripSeparator5
        '
        Me.ToolStripSeparator5.Name = "ToolStripSeparator5"
        Me.ToolStripSeparator5.Size = New System.Drawing.Size(292, 6)
        '
        'SetAllIntl
        '
        Me.SetAllIntl.Name = "SetAllIntl"
        Me.SetAllIntl.Size = New System.Drawing.Size(295, 22)
        Me.SetAllIntl.Text = "Set UI language and locales..."
        '
        'ToolStripSeparator6
        '
        Me.ToolStripSeparator6.Name = "ToolStripSeparator6"
        Me.ToolStripSeparator6.Size = New System.Drawing.Size(292, 6)
        '
        'SetTimeZone
        '
        Me.SetTimeZone.Name = "SetTimeZone"
        Me.SetTimeZone.Size = New System.Drawing.Size(295, 22)
        Me.SetTimeZone.Text = "Set default time zone..."
        '
        'ToolStripSeparator7
        '
        Me.ToolStripSeparator7.Name = "ToolStripSeparator7"
        Me.ToolStripSeparator7.Size = New System.Drawing.Size(292, 6)
        '
        'SetSKUIntlDefaults
        '
        Me.SetSKUIntlDefaults.Name = "SetSKUIntlDefaults"
        Me.SetSKUIntlDefaults.Size = New System.Drawing.Size(295, 22)
        Me.SetSKUIntlDefaults.Text = "Set default languages and locales..."
        '
        'ToolStripSeparator8
        '
        Me.ToolStripSeparator8.Name = "ToolStripSeparator8"
        Me.ToolStripSeparator8.Size = New System.Drawing.Size(292, 6)
        '
        'SetLayeredDriver
        '
        Me.SetLayeredDriver.Name = "SetLayeredDriver"
        Me.SetLayeredDriver.Size = New System.Drawing.Size(295, 22)
        Me.SetLayeredDriver.Text = "Set layered driver..."
        '
        'GenLangINI
        '
        Me.GenLangINI.Name = "GenLangINI"
        Me.GenLangINI.Size = New System.Drawing.Size(295, 22)
        Me.GenLangINI.Text = "Generate Lang.ini file..."
        '
        'SetSetupUILang
        '
        Me.SetSetupUILang.Name = "SetSetupUILang"
        Me.SetSetupUILang.Size = New System.Drawing.Size(295, 22)
        Me.SetSetupUILang.Text = "Set default Setup language..."
        '
        'CapabilitiesToolStripMenuItem
        '
        Me.CapabilitiesToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.AddCapability, Me.ExportSource, Me.GetCapabilities, Me.RemoveCapability})
        Me.CapabilitiesToolStripMenuItem.Name = "CapabilitiesToolStripMenuItem"
        Me.CapabilitiesToolStripMenuItem.Size = New System.Drawing.Size(244, 22)
        Me.CapabilitiesToolStripMenuItem.Text = "Capabilities"
        '
        'AddCapability
        '
        Me.AddCapability.Name = "AddCapability"
        Me.AddCapability.Size = New System.Drawing.Size(259, 22)
        Me.AddCapability.Text = "Add capability..."
        '
        'ExportSource
        '
        Me.ExportSource.Name = "ExportSource"
        Me.ExportSource.Size = New System.Drawing.Size(259, 22)
        Me.ExportSource.Text = "Export capabilities into repository..."
        '
        'GetCapabilities
        '
        Me.GetCapabilities.Name = "GetCapabilities"
        Me.GetCapabilities.Size = New System.Drawing.Size(259, 22)
        Me.GetCapabilities.Text = "Get capability information..."
        '
        'RemoveCapability
        '
        Me.RemoveCapability.Name = "RemoveCapability"
        Me.RemoveCapability.Size = New System.Drawing.Size(259, 22)
        Me.RemoveCapability.Text = "Remove capability..."
        '
        'WindowsEditionsToolStripMenuItem
        '
        Me.WindowsEditionsToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.GetCurrentEdition, Me.GetTargetEditions, Me.SetEdition, Me.SetProductKey})
        Me.WindowsEditionsToolStripMenuItem.Name = "WindowsEditionsToolStripMenuItem"
        Me.WindowsEditionsToolStripMenuItem.Size = New System.Drawing.Size(244, 22)
        Me.WindowsEditionsToolStripMenuItem.Text = "Windows editions"
        '
        'GetCurrentEdition
        '
        Me.GetCurrentEdition.Name = "GetCurrentEdition"
        Me.GetCurrentEdition.Size = New System.Drawing.Size(187, 22)
        Me.GetCurrentEdition.Text = "Get current edition..."
        '
        'GetTargetEditions
        '
        Me.GetTargetEditions.Name = "GetTargetEditions"
        Me.GetTargetEditions.Size = New System.Drawing.Size(187, 22)
        Me.GetTargetEditions.Text = "Get upgrade targets..."
        '
        'SetEdition
        '
        Me.SetEdition.Name = "SetEdition"
        Me.SetEdition.Size = New System.Drawing.Size(187, 22)
        Me.SetEdition.Text = "Upgrade image..."
        '
        'SetProductKey
        '
        Me.SetProductKey.Name = "SetProductKey"
        Me.SetProductKey.Size = New System.Drawing.Size(187, 22)
        Me.SetProductKey.Text = "Set product key..."
        '
        'DriversToolStripMenuItem
        '
        Me.DriversToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.GetDrivers, Me.AddDriver, Me.RemoveDriver, Me.ExportDriver, Me.ImportDriver})
        Me.DriversToolStripMenuItem.Name = "DriversToolStripMenuItem"
        Me.DriversToolStripMenuItem.Size = New System.Drawing.Size(244, 22)
        Me.DriversToolStripMenuItem.Text = "Drivers"
        '
        'GetDrivers
        '
        Me.GetDrivers.Name = "GetDrivers"
        Me.GetDrivers.Size = New System.Drawing.Size(204, 22)
        Me.GetDrivers.Text = "Get driver information..."
        '
        'AddDriver
        '
        Me.AddDriver.Name = "AddDriver"
        Me.AddDriver.Size = New System.Drawing.Size(204, 22)
        Me.AddDriver.Text = "Add driver..."
        '
        'RemoveDriver
        '
        Me.RemoveDriver.Name = "RemoveDriver"
        Me.RemoveDriver.Size = New System.Drawing.Size(204, 22)
        Me.RemoveDriver.Text = "Remove driver..."
        '
        'ExportDriver
        '
        Me.ExportDriver.Name = "ExportDriver"
        Me.ExportDriver.Size = New System.Drawing.Size(204, 22)
        Me.ExportDriver.Text = "Export driver packages..."
        '
        'ImportDriver
        '
        Me.ImportDriver.Name = "ImportDriver"
        Me.ImportDriver.Size = New System.Drawing.Size(204, 22)
        Me.ImportDriver.Text = "Import driver packages..."
        '
        'UnattendedAnswerFilesToolStripMenuItem
        '
        Me.UnattendedAnswerFilesToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ApplyUnattend})
        Me.UnattendedAnswerFilesToolStripMenuItem.Name = "UnattendedAnswerFilesToolStripMenuItem"
        Me.UnattendedAnswerFilesToolStripMenuItem.Size = New System.Drawing.Size(244, 22)
        Me.UnattendedAnswerFilesToolStripMenuItem.Text = "Unattended answer files"
        '
        'ApplyUnattend
        '
        Me.ApplyUnattend.Name = "ApplyUnattend"
        Me.ApplyUnattend.Size = New System.Drawing.Size(237, 22)
        Me.ApplyUnattend.Text = "Apply unattended answer file..."
        '
        'WindowsPEServicingToolStripMenuItem
        '
        Me.WindowsPEServicingToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.GetPESettings, Me.SetScratchSpace, Me.SetTargetPath})
        Me.WindowsPEServicingToolStripMenuItem.Name = "WindowsPEServicingToolStripMenuItem"
        Me.WindowsPEServicingToolStripMenuItem.Size = New System.Drawing.Size(244, 22)
        Me.WindowsPEServicingToolStripMenuItem.Text = "Windows PE servicing"
        '
        'GetPESettings
        '
        Me.GetPESettings.Name = "GetPESettings"
        Me.GetPESettings.Size = New System.Drawing.Size(173, 22)
        Me.GetPESettings.Text = "Get settings..."
        '
        'SetScratchSpace
        '
        Me.SetScratchSpace.Name = "SetScratchSpace"
        Me.SetScratchSpace.Size = New System.Drawing.Size(173, 22)
        Me.SetScratchSpace.Text = "Set scratch space..."
        '
        'SetTargetPath
        '
        Me.SetTargetPath.Name = "SetTargetPath"
        Me.SetTargetPath.Size = New System.Drawing.Size(173, 22)
        Me.SetTargetPath.Text = "Set target path..."
        '
        'OSUninstallToolStripMenuItem
        '
        Me.OSUninstallToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.GetOSUninstallWindow, Me.InitiateOSUninstall, Me.RemoveOSUninstall, Me.SetOSUninstallWindow})
        Me.OSUninstallToolStripMenuItem.Name = "OSUninstallToolStripMenuItem"
        Me.OSUninstallToolStripMenuItem.Size = New System.Drawing.Size(244, 22)
        Me.OSUninstallToolStripMenuItem.Text = "OS uninstall"
        '
        'GetOSUninstallWindow
        '
        Me.GetOSUninstallWindow.Name = "GetOSUninstallWindow"
        Me.GetOSUninstallWindow.Size = New System.Drawing.Size(209, 22)
        Me.GetOSUninstallWindow.Text = "Get uninstall window..."
        '
        'InitiateOSUninstall
        '
        Me.InitiateOSUninstall.Name = "InitiateOSUninstall"
        Me.InitiateOSUninstall.Size = New System.Drawing.Size(209, 22)
        Me.InitiateOSUninstall.Text = "Initiate uninstall..."
        '
        'RemoveOSUninstall
        '
        Me.RemoveOSUninstall.Name = "RemoveOSUninstall"
        Me.RemoveOSUninstall.Size = New System.Drawing.Size(209, 22)
        Me.RemoveOSUninstall.Text = "Remove roll back ability..."
        '
        'SetOSUninstallWindow
        '
        Me.SetOSUninstallWindow.Name = "SetOSUninstallWindow"
        Me.SetOSUninstallWindow.Size = New System.Drawing.Size(209, 22)
        Me.SetOSUninstallWindow.Text = "Set uninstall window..."
        '
        'ReservedStorageToolStripMenuItem
        '
        Me.ReservedStorageToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.SetReservedStorageState, Me.GetReservedStorageState})
        Me.ReservedStorageToolStripMenuItem.Name = "ReservedStorageToolStripMenuItem"
        Me.ReservedStorageToolStripMenuItem.Size = New System.Drawing.Size(244, 22)
        Me.ReservedStorageToolStripMenuItem.Text = "Reserved storage"
        '
        'SetReservedStorageState
        '
        Me.SetReservedStorageState.Name = "SetReservedStorageState"
        Me.SetReservedStorageState.Size = New System.Drawing.Size(218, 22)
        Me.SetReservedStorageState.Text = "Set reserved storage state..."
        '
        'GetReservedStorageState
        '
        Me.GetReservedStorageState.Name = "GetReservedStorageState"
        Me.GetReservedStorageState.Size = New System.Drawing.Size(218, 22)
        Me.GetReservedStorageState.Text = "Get reserved storage state..."
        '
        'MicrosoftEdgeToolStripMenuItem
        '
        Me.MicrosoftEdgeToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.AddEdge, Me.AddEdgeBrowser, Me.AddEdgeWebView})
        Me.MicrosoftEdgeToolStripMenuItem.Name = "MicrosoftEdgeToolStripMenuItem"
        Me.MicrosoftEdgeToolStripMenuItem.Size = New System.Drawing.Size(244, 22)
        Me.MicrosoftEdgeToolStripMenuItem.Text = "Microsoft Edge"
        '
        'AddEdge
        '
        Me.AddEdge.Name = "AddEdge"
        Me.AddEdge.Size = New System.Drawing.Size(186, 22)
        Me.AddEdge.Text = "Add Edge..."
        '
        'AddEdgeBrowser
        '
        Me.AddEdgeBrowser.Name = "AddEdgeBrowser"
        Me.AddEdgeBrowser.Size = New System.Drawing.Size(186, 22)
        Me.AddEdgeBrowser.Text = "Add Edge browser..."
        '
        'AddEdgeWebView
        '
        Me.AddEdgeWebView.Name = "AddEdgeWebView"
        Me.AddEdgeWebView.Size = New System.Drawing.Size(186, 22)
        Me.AddEdgeWebView.Text = "Add Edge WebView..."
        '
        'ToolsToolStripMenuItem
        '
        Me.ToolsToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ImageConversionToolStripMenuItem, Me.ToolStripSeparator12, Me.MergeSWM, Me.ToolStripSeparator18, Me.RemountImageWithWritePermissionsToolStripMenuItem, Me.ToolStripSeparator13, Me.CommandShellToolStripMenuItem, Me.ToolStripSeparator16, Me.UnattendedAnswerFileManagerToolStripMenuItem, Me.UnattendedAnswerFileCreatorToolStripMenuItem, Me.ToolStripSeparator41, Me.ReportManagerToolStripMenuItem, Me.MountedImageManagerTSMI, Me.ToolStripSeparator28, Me.CreateDiscImageToolStripMenuItem, Me.CreateTestingEnvironmentToolStripMenuItem, Me.ToolStripSeparator38, Me.WimScriptEditorCommand, Me.ToolStripSeparator9, Me.ActionEditorToolStripMenuItem, Me.ToolStripSeparator22, Me.OptionsToolStripMenuItem})
        Me.ToolsToolStripMenuItem.Name = "ToolsToolStripMenuItem"
        Me.ToolsToolStripMenuItem.Size = New System.Drawing.Size(46, 20)
        Me.ToolsToolStripMenuItem.Text = "&Tools"
        '
        'ImageConversionToolStripMenuItem
        '
        Me.ImageConversionToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.WIMESDToolStripMenuItem})
        Me.ImageConversionToolStripMenuItem.Name = "ImageConversionToolStripMenuItem"
        Me.ImageConversionToolStripMenuItem.Size = New System.Drawing.Size(280, 22)
        Me.ImageConversionToolStripMenuItem.Text = "Image conversion"
        '
        'WIMESDToolStripMenuItem
        '
        Me.WIMESDToolStripMenuItem.Name = "WIMESDToolStripMenuItem"
        Me.WIMESDToolStripMenuItem.Size = New System.Drawing.Size(146, 22)
        Me.WIMESDToolStripMenuItem.Text = "WIM <-> ESD"
        '
        'ToolStripSeparator12
        '
        Me.ToolStripSeparator12.Name = "ToolStripSeparator12"
        Me.ToolStripSeparator12.Size = New System.Drawing.Size(277, 6)
        '
        'MergeSWM
        '
        Me.MergeSWM.Name = "MergeSWM"
        Me.MergeSWM.Size = New System.Drawing.Size(280, 22)
        Me.MergeSWM.Text = "Merge SWM files..."
        '
        'ToolStripSeparator18
        '
        Me.ToolStripSeparator18.Name = "ToolStripSeparator18"
        Me.ToolStripSeparator18.Size = New System.Drawing.Size(277, 6)
        '
        'RemountImageWithWritePermissionsToolStripMenuItem
        '
        Me.RemountImageWithWritePermissionsToolStripMenuItem.Enabled = False
        Me.RemountImageWithWritePermissionsToolStripMenuItem.Name = "RemountImageWithWritePermissionsToolStripMenuItem"
        Me.RemountImageWithWritePermissionsToolStripMenuItem.Size = New System.Drawing.Size(280, 22)
        Me.RemountImageWithWritePermissionsToolStripMenuItem.Text = "Remount image with write permissions"
        '
        'ToolStripSeparator13
        '
        Me.ToolStripSeparator13.Name = "ToolStripSeparator13"
        Me.ToolStripSeparator13.Size = New System.Drawing.Size(277, 6)
        '
        'CommandShellToolStripMenuItem
        '
        Me.CommandShellToolStripMenuItem.Name = "CommandShellToolStripMenuItem"
        Me.CommandShellToolStripMenuItem.Size = New System.Drawing.Size(280, 22)
        Me.CommandShellToolStripMenuItem.Text = "Command Console"
        '
        'ToolStripSeparator16
        '
        Me.ToolStripSeparator16.Name = "ToolStripSeparator16"
        Me.ToolStripSeparator16.Size = New System.Drawing.Size(277, 6)
        '
        'UnattendedAnswerFileManagerToolStripMenuItem
        '
        Me.UnattendedAnswerFileManagerToolStripMenuItem.Name = "UnattendedAnswerFileManagerToolStripMenuItem"
        Me.UnattendedAnswerFileManagerToolStripMenuItem.Size = New System.Drawing.Size(280, 22)
        Me.UnattendedAnswerFileManagerToolStripMenuItem.Text = "Unattended answer file manager"
        '
        'UnattendedAnswerFileCreatorToolStripMenuItem
        '
        Me.UnattendedAnswerFileCreatorToolStripMenuItem.Name = "UnattendedAnswerFileCreatorToolStripMenuItem"
        Me.UnattendedAnswerFileCreatorToolStripMenuItem.Size = New System.Drawing.Size(280, 22)
        Me.UnattendedAnswerFileCreatorToolStripMenuItem.Text = "Unattended answer file creator"
        '
        'ToolStripSeparator41
        '
        Me.ToolStripSeparator41.Name = "ToolStripSeparator41"
        Me.ToolStripSeparator41.Size = New System.Drawing.Size(277, 6)
        '
        'ReportManagerToolStripMenuItem
        '
        Me.ReportManagerToolStripMenuItem.Name = "ReportManagerToolStripMenuItem"
        Me.ReportManagerToolStripMenuItem.Size = New System.Drawing.Size(280, 22)
        Me.ReportManagerToolStripMenuItem.Text = "Report manager"
        '
        'MountedImageManagerTSMI
        '
        Me.MountedImageManagerTSMI.Name = "MountedImageManagerTSMI"
        Me.MountedImageManagerTSMI.Size = New System.Drawing.Size(280, 22)
        Me.MountedImageManagerTSMI.Text = "Mounted image manager"
        '
        'ToolStripSeparator28
        '
        Me.ToolStripSeparator28.Name = "ToolStripSeparator28"
        Me.ToolStripSeparator28.Size = New System.Drawing.Size(277, 6)
        '
        'CreateDiscImageToolStripMenuItem
        '
        Me.CreateDiscImageToolStripMenuItem.Name = "CreateDiscImageToolStripMenuItem"
        Me.CreateDiscImageToolStripMenuItem.Size = New System.Drawing.Size(280, 22)
        Me.CreateDiscImageToolStripMenuItem.Text = "Create disc image..."
        '
        'CreateTestingEnvironmentToolStripMenuItem
        '
        Me.CreateTestingEnvironmentToolStripMenuItem.Name = "CreateTestingEnvironmentToolStripMenuItem"
        Me.CreateTestingEnvironmentToolStripMenuItem.Size = New System.Drawing.Size(280, 22)
        Me.CreateTestingEnvironmentToolStripMenuItem.Text = "Create testing environment..."
        '
        'ToolStripSeparator38
        '
        Me.ToolStripSeparator38.Name = "ToolStripSeparator38"
        Me.ToolStripSeparator38.Size = New System.Drawing.Size(277, 6)
        '
        'WimScriptEditorCommand
        '
        Me.WimScriptEditorCommand.Name = "WimScriptEditorCommand"
        Me.WimScriptEditorCommand.Size = New System.Drawing.Size(280, 22)
        Me.WimScriptEditorCommand.Text = "Configuration list editor"
        '
        'ToolStripSeparator9
        '
        Me.ToolStripSeparator9.Name = "ToolStripSeparator9"
        Me.ToolStripSeparator9.Size = New System.Drawing.Size(277, 6)
        '
        'ActionEditorToolStripMenuItem
        '
        Me.ActionEditorToolStripMenuItem.Name = "ActionEditorToolStripMenuItem"
        Me.ActionEditorToolStripMenuItem.Size = New System.Drawing.Size(280, 22)
        Me.ActionEditorToolStripMenuItem.Text = "Action editor"
        '
        'ToolStripSeparator22
        '
        Me.ToolStripSeparator22.Name = "ToolStripSeparator22"
        Me.ToolStripSeparator22.Size = New System.Drawing.Size(277, 6)
        '
        'OptionsToolStripMenuItem
        '
        Me.OptionsToolStripMenuItem.Name = "OptionsToolStripMenuItem"
        Me.OptionsToolStripMenuItem.Size = New System.Drawing.Size(280, 22)
        Me.OptionsToolStripMenuItem.Text = "Options"
        '
        'HelpToolStripMenuItem
        '
        Me.HelpToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.HelpTopicsToolStripMenuItem, Me.GlossaryToolStripMenuItem, Me.CommandHelpToolStripMenuItem, Me.ToolStripSeparator10, Me.AboutDISMToolsToolStripMenuItem, Me.ToolStripSeparator21, Me.ReportFeedbackToolStripMenuItem, Me.ToolStripSeparator35, Me.ContributeToTheHelpSystemToolStripMenuItem})
        Me.HelpToolStripMenuItem.Name = "HelpToolStripMenuItem"
        Me.HelpToolStripMenuItem.Size = New System.Drawing.Size(44, 20)
        Me.HelpToolStripMenuItem.Text = "&Help"
        '
        'HelpTopicsToolStripMenuItem
        '
        Me.HelpTopicsToolStripMenuItem.Name = "HelpTopicsToolStripMenuItem"
        Me.HelpTopicsToolStripMenuItem.ShortcutKeys = System.Windows.Forms.Keys.F1
        Me.HelpTopicsToolStripMenuItem.Size = New System.Drawing.Size(286, 22)
        Me.HelpTopicsToolStripMenuItem.Text = "Help Topics"
        '
        'GlossaryToolStripMenuItem
        '
        Me.GlossaryToolStripMenuItem.Name = "GlossaryToolStripMenuItem"
        Me.GlossaryToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.F1), System.Windows.Forms.Keys)
        Me.GlossaryToolStripMenuItem.Size = New System.Drawing.Size(286, 22)
        Me.GlossaryToolStripMenuItem.Text = "Glossary"
        Me.GlossaryToolStripMenuItem.Visible = False
        '
        'CommandHelpToolStripMenuItem
        '
        Me.CommandHelpToolStripMenuItem.Name = "CommandHelpToolStripMenuItem"
        Me.CommandHelpToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Shift Or System.Windows.Forms.Keys.F1), System.Windows.Forms.Keys)
        Me.CommandHelpToolStripMenuItem.Size = New System.Drawing.Size(286, 22)
        Me.CommandHelpToolStripMenuItem.Text = "Command help..."
        '
        'ToolStripSeparator10
        '
        Me.ToolStripSeparator10.Name = "ToolStripSeparator10"
        Me.ToolStripSeparator10.Size = New System.Drawing.Size(283, 6)
        '
        'AboutDISMToolsToolStripMenuItem
        '
        Me.AboutDISMToolsToolStripMenuItem.Name = "AboutDISMToolsToolStripMenuItem"
        Me.AboutDISMToolsToolStripMenuItem.Size = New System.Drawing.Size(286, 22)
        Me.AboutDISMToolsToolStripMenuItem.Text = "About DISMTools"
        '
        'ToolStripSeparator21
        '
        Me.ToolStripSeparator21.Name = "ToolStripSeparator21"
        Me.ToolStripSeparator21.Size = New System.Drawing.Size(283, 6)
        '
        'ReportFeedbackToolStripMenuItem
        '
        Me.ReportFeedbackToolStripMenuItem.Name = "ReportFeedbackToolStripMenuItem"
        Me.ReportFeedbackToolStripMenuItem.Size = New System.Drawing.Size(286, 22)
        Me.ReportFeedbackToolStripMenuItem.Text = "Report feedback (opens in web browser)"
        '
        'ToolStripSeparator35
        '
        Me.ToolStripSeparator35.Name = "ToolStripSeparator35"
        Me.ToolStripSeparator35.Size = New System.Drawing.Size(283, 6)
        '
        'ContributeToTheHelpSystemToolStripMenuItem
        '
        Me.ContributeToTheHelpSystemToolStripMenuItem.Name = "ContributeToTheHelpSystemToolStripMenuItem"
        Me.ContributeToTheHelpSystemToolStripMenuItem.Size = New System.Drawing.Size(286, 22)
        Me.ContributeToTheHelpSystemToolStripMenuItem.Text = "Contribute to the help system"
        '
        'BranchTSMI
        '
        Me.BranchTSMI.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right
        Me.BranchTSMI.Image = CType(resources.GetObject("BranchTSMI.Image"), System.Drawing.Image)
        Me.BranchTSMI.Name = "BranchTSMI"
        Me.BranchTSMI.Size = New System.Drawing.Size(72, 20)
        Me.BranchTSMI.Text = "Branch"
        Me.BranchTSMI.Visible = False
        '
        'VersionTSMI
        '
        Me.VersionTSMI.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right
        Me.VersionTSMI.Name = "VersionTSMI"
        Me.VersionTSMI.Size = New System.Drawing.Size(66, 20)
        Me.VersionTSMI.Text = "PREVIEW"
        Me.VersionTSMI.ToolTipText = "This is a beta release. In it, you will encounter lots of bugs and incomplete fea" & _
    "tures."
        Me.VersionTSMI.Visible = False
        '
        'InvalidSettingsTSMI
        '
        Me.InvalidSettingsTSMI.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right
        Me.InvalidSettingsTSMI.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ISFix, Me.ToolStripSeparator19, Me.ISHelp})
        Me.InvalidSettingsTSMI.Image = CType(resources.GetObject("InvalidSettingsTSMI.Image"), System.Drawing.Image)
        Me.InvalidSettingsTSMI.Name = "InvalidSettingsTSMI"
        Me.InvalidSettingsTSMI.Size = New System.Drawing.Size(220, 20)
        Me.InvalidSettingsTSMI.Text = "Invalid settings have been detected"
        Me.InvalidSettingsTSMI.Visible = False
        '
        'ISFix
        '
        Me.ISFix.Name = "ISFix"
        Me.ISFix.Size = New System.Drawing.Size(168, 22)
        Me.ISFix.Text = "More information"
        '
        'ToolStripSeparator19
        '
        Me.ToolStripSeparator19.Name = "ToolStripSeparator19"
        Me.ToolStripSeparator19.Size = New System.Drawing.Size(165, 6)
        '
        'ISHelp
        '
        Me.ISHelp.Name = "ISHelp"
        Me.ISHelp.Size = New System.Drawing.Size(168, 22)
        Me.ISHelp.Text = "What's this?"
        '
        'HomePanel
        '
        Me.HomePanel.Controls.Add(Me.WelcomePanel)
        Me.HomePanel.Controls.Add(Me.SidePanel)
        Me.HomePanel.Dock = System.Windows.Forms.DockStyle.Fill
        Me.HomePanel.Location = New System.Drawing.Point(0, 24)
        Me.HomePanel.Name = "HomePanel"
        Me.HomePanel.Size = New System.Drawing.Size(1264, 657)
        Me.HomePanel.TabIndex = 3
        '
        'WelcomePanel
        '
        Me.WelcomePanel.Controls.Add(Me.StartPanel)
        Me.WelcomePanel.Dock = System.Windows.Forms.DockStyle.Fill
        Me.WelcomePanel.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.WelcomePanel.Location = New System.Drawing.Point(256, 0)
        Me.WelcomePanel.Name = "WelcomePanel"
        Me.WelcomePanel.Size = New System.Drawing.Size(1008, 657)
        Me.WelcomePanel.TabIndex = 1
        '
        'StartPanel
        '
        Me.StartPanel.Controls.Add(Me.StartPanelPContainer)
        Me.StartPanel.Controls.Add(Me.Panel1)
        Me.StartPanel.Dock = System.Windows.Forms.DockStyle.Fill
        Me.StartPanel.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.StartPanel.Location = New System.Drawing.Point(0, 0)
        Me.StartPanel.Name = "StartPanel"
        Me.StartPanel.Size = New System.Drawing.Size(1008, 657)
        Me.StartPanel.TabIndex = 2
        '
        'StartPanelPContainer
        '
        Me.StartPanelPContainer.Controls.Add(Me.GetStartedPanel)
        Me.StartPanelPContainer.Controls.Add(Me.LatestNewsPanel)
        Me.StartPanelPContainer.Controls.Add(Me.TutorialVideoPanel)
        Me.StartPanelPContainer.Dock = System.Windows.Forms.DockStyle.Fill
        Me.StartPanelPContainer.Location = New System.Drawing.Point(0, 38)
        Me.StartPanelPContainer.Name = "StartPanelPContainer"
        Me.StartPanelPContainer.Size = New System.Drawing.Size(1008, 619)
        Me.StartPanelPContainer.TabIndex = 5
        '
        'GetStartedPanel
        '
        Me.GetStartedPanel.Controls.Add(Me.GetStartedContainer)
        Me.GetStartedPanel.Dock = System.Windows.Forms.DockStyle.Fill
        Me.GetStartedPanel.Location = New System.Drawing.Point(0, 0)
        Me.GetStartedPanel.Name = "GetStartedPanel"
        Me.GetStartedPanel.Size = New System.Drawing.Size(1008, 619)
        Me.GetStartedPanel.TabIndex = 0
        '
        'GetStartedContainer
        '
        Me.GetStartedContainer.Controls.Add(Me.Panel6)
        Me.GetStartedContainer.Dock = System.Windows.Forms.DockStyle.Fill
        Me.GetStartedContainer.Location = New System.Drawing.Point(0, 0)
        Me.GetStartedContainer.Name = "GetStartedContainer"
        Me.GetStartedContainer.Size = New System.Drawing.Size(1008, 619)
        Me.GetStartedContainer.TabIndex = 6
        '
        'Panel6
        '
        Me.Panel6.Controls.Add(Me.Label8)
        Me.Panel6.Controls.Add(Me.LinkLabel5)
        Me.Panel6.Controls.Add(Me.LinkLabel4)
        Me.Panel6.Controls.Add(Me.LinkLabel11)
        Me.Panel6.Controls.Add(Me.LinkLabel8)
        Me.Panel6.Controls.Add(Me.LinkLabel10)
        Me.Panel6.Controls.Add(Me.LinkLabel7)
        Me.Panel6.Controls.Add(Me.LinkLabel9)
        Me.Panel6.Controls.Add(Me.LinkLabel6)
        Me.Panel6.Controls.Add(Me.Label38)
        Me.Panel6.Controls.Add(Me.Label37)
        Me.Panel6.Controls.Add(Me.Label36)
        Me.Panel6.Controls.Add(Me.PictureBox8)
        Me.Panel6.Controls.Add(Me.PictureBox7)
        Me.Panel6.Controls.Add(Me.PictureBox6)
        Me.Panel6.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel6.Location = New System.Drawing.Point(0, 0)
        Me.Panel6.Name = "Panel6"
        Me.Panel6.Size = New System.Drawing.Size(1008, 619)
        Me.Panel6.TabIndex = 0
        '
        'Label8
        '
        Me.Label8.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label8.AutoEllipsis = True
        Me.Label8.Location = New System.Drawing.Point(74, 40)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(918, 35)
        Me.Label8.TabIndex = 5
        Me.Label8.Text = "This program is not complete and you may run into issues. If that happens, don't " & _
    "hesitate to send us feedback"
        '
        'LinkLabel5
        '
        Me.LinkLabel5.AutoSize = True
        Me.LinkLabel5.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline
        Me.LinkLabel5.LinkColor = System.Drawing.Color.DodgerBlue
        Me.LinkLabel5.Location = New System.Drawing.Point(73, 262)
        Me.LinkLabel5.Name = "LinkLabel5"
        Me.LinkLabel5.Size = New System.Drawing.Size(195, 15)
        Me.LinkLabel5.TabIndex = 4
        Me.LinkLabel5.TabStop = True
        Me.LinkLabel5.Text = "Managing installations on any drive"
        '
        'LinkLabel4
        '
        Me.LinkLabel4.AutoSize = True
        Me.LinkLabel4.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline
        Me.LinkLabel4.LinkColor = System.Drawing.Color.DodgerBlue
        Me.LinkLabel4.Location = New System.Drawing.Point(73, 244)
        Me.LinkLabel4.Name = "LinkLabel4"
        Me.LinkLabel4.Size = New System.Drawing.Size(183, 15)
        Me.LinkLabel4.TabIndex = 4
        Me.LinkLabel4.TabStop = True
        Me.LinkLabel4.Text = "Managing your active installation"
        '
        'LinkLabel11
        '
        Me.LinkLabel11.AutoSize = True
        Me.LinkLabel11.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline
        Me.LinkLabel11.LinkColor = System.Drawing.Color.DodgerBlue
        Me.LinkLabel11.Location = New System.Drawing.Point(73, 226)
        Me.LinkLabel11.Name = "LinkLabel11"
        Me.LinkLabel11.Size = New System.Drawing.Size(144, 15)
        Me.LinkLabel11.TabIndex = 4
        Me.LinkLabel11.TabStop = True
        Me.LinkLabel11.Text = "Saving image information"
        '
        'LinkLabel8
        '
        Me.LinkLabel8.AutoSize = True
        Me.LinkLabel8.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline
        Me.LinkLabel8.LinkColor = System.Drawing.Color.DodgerBlue
        Me.LinkLabel8.Location = New System.Drawing.Point(73, 143)
        Me.LinkLabel8.Name = "LinkLabel8"
        Me.LinkLabel8.Size = New System.Drawing.Size(156, 15)
        Me.LinkLabel8.TabIndex = 4
        Me.LinkLabel8.TabStop = True
        Me.LinkLabel8.Text = "Coming from other utilities?"
        '
        'LinkLabel10
        '
        Me.LinkLabel10.AutoSize = True
        Me.LinkLabel10.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline
        Me.LinkLabel10.LinkColor = System.Drawing.Color.DodgerBlue
        Me.LinkLabel10.Location = New System.Drawing.Point(73, 208)
        Me.LinkLabel10.Name = "LinkLabel10"
        Me.LinkLabel10.Size = New System.Drawing.Size(148, 15)
        Me.LinkLabel10.TabIndex = 4
        Me.LinkLabel10.TabStop = True
        Me.LinkLabel10.Text = "Getting image information"
        '
        'LinkLabel7
        '
        Me.LinkLabel7.AutoSize = True
        Me.LinkLabel7.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline
        Me.LinkLabel7.LinkColor = System.Drawing.Color.DodgerBlue
        Me.LinkLabel7.Location = New System.Drawing.Point(73, 125)
        Me.LinkLabel7.Name = "LinkLabel7"
        Me.LinkLabel7.Size = New System.Drawing.Size(169, 15)
        Me.LinkLabel7.TabIndex = 4
        Me.LinkLabel7.TabStop = True
        Me.LinkLabel7.Text = "Getting started with DISMTools"
        '
        'LinkLabel9
        '
        Me.LinkLabel9.AutoSize = True
        Me.LinkLabel9.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline
        Me.LinkLabel9.LinkColor = System.Drawing.Color.DodgerBlue
        Me.LinkLabel9.Location = New System.Drawing.Point(73, 190)
        Me.LinkLabel9.Name = "LinkLabel9"
        Me.LinkLabel9.Size = New System.Drawing.Size(189, 15)
        Me.LinkLabel9.TabIndex = 4
        Me.LinkLabel9.TabStop = True
        Me.LinkLabel9.Text = "Tips for performing great servicing"
        '
        'LinkLabel6
        '
        Me.LinkLabel6.AutoSize = True
        Me.LinkLabel6.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline
        Me.LinkLabel6.LinkColor = System.Drawing.Color.DodgerBlue
        Me.LinkLabel6.Location = New System.Drawing.Point(73, 107)
        Me.LinkLabel6.Name = "LinkLabel6"
        Me.LinkLabel6.Size = New System.Drawing.Size(197, 15)
        Me.LinkLabel6.TabIndex = 4
        Me.LinkLabel6.TabStop = True
        Me.LinkLabel6.Text = "Getting started with image servicing"
        '
        'Label38
        '
        Me.Label38.AutoSize = True
        Me.Label38.Font = New System.Drawing.Font("Segoe UI", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label38.Location = New System.Drawing.Point(72, 167)
        Me.Label38.Name = "Label38"
        Me.Label38.Size = New System.Drawing.Size(157, 20)
        Me.Label38.TabIndex = 3
        Me.Label38.Text = "Performing operations"
        '
        'Label37
        '
        Me.Label37.AutoSize = True
        Me.Label37.Font = New System.Drawing.Font("Segoe UI", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label37.Location = New System.Drawing.Point(72, 84)
        Me.Label37.Name = "Label37"
        Me.Label37.Size = New System.Drawing.Size(108, 20)
        Me.Label37.TabIndex = 3
        Me.Label37.Text = "Getting started"
        '
        'Label36
        '
        Me.Label36.AutoSize = True
        Me.Label36.Font = New System.Drawing.Font("Segoe UI", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label36.Location = New System.Drawing.Point(72, 16)
        Me.Label36.Name = "Label36"
        Me.Label36.Size = New System.Drawing.Size(154, 20)
        Me.Label36.TabIndex = 3
        Me.Label36.Text = "This is beta software"
        '
        'PictureBox8
        '
        Me.PictureBox8.Image = Global.DISMTools.My.Resources.Resources.imgoperation
        Me.PictureBox8.Location = New System.Drawing.Point(16, 167)
        Me.PictureBox8.Name = "PictureBox8"
        Me.PictureBox8.Size = New System.Drawing.Size(48, 48)
        Me.PictureBox8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage
        Me.PictureBox8.TabIndex = 0
        Me.PictureBox8.TabStop = False
        '
        'PictureBox7
        '
        Me.PictureBox7.Image = Global.DISMTools.My.Resources.Resources.getting_started
        Me.PictureBox7.Location = New System.Drawing.Point(16, 84)
        Me.PictureBox7.Name = "PictureBox7"
        Me.PictureBox7.Size = New System.Drawing.Size(48, 48)
        Me.PictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage
        Me.PictureBox7.TabIndex = 0
        Me.PictureBox7.TabStop = False
        '
        'PictureBox6
        '
        Me.PictureBox6.Image = Global.DISMTools.My.Resources.Resources.ver_stability
        Me.PictureBox6.Location = New System.Drawing.Point(16, 16)
        Me.PictureBox6.Name = "PictureBox6"
        Me.PictureBox6.Size = New System.Drawing.Size(48, 48)
        Me.PictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage
        Me.PictureBox6.TabIndex = 0
        Me.PictureBox6.TabStop = False
        '
        'LatestNewsPanel
        '
        Me.LatestNewsPanel.Controls.Add(Me.FeedContainer)
        Me.LatestNewsPanel.Controls.Add(Me.Panel4)
        Me.LatestNewsPanel.Dock = System.Windows.Forms.DockStyle.Fill
        Me.LatestNewsPanel.Location = New System.Drawing.Point(0, 0)
        Me.LatestNewsPanel.Name = "LatestNewsPanel"
        Me.LatestNewsPanel.Size = New System.Drawing.Size(1008, 619)
        Me.LatestNewsPanel.TabIndex = 0
        Me.LatestNewsPanel.Visible = False
        '
        'FeedContainer
        '
        Me.FeedContainer.Controls.Add(Me.FeedsPanel)
        Me.FeedContainer.Controls.Add(Me.FeedErrorPanel)
        Me.FeedContainer.Dock = System.Windows.Forms.DockStyle.Fill
        Me.FeedContainer.Location = New System.Drawing.Point(0, 0)
        Me.FeedContainer.Name = "FeedContainer"
        Me.FeedContainer.Size = New System.Drawing.Size(1008, 571)
        Me.FeedContainer.TabIndex = 1
        '
        'FeedsPanel
        '
        Me.FeedsPanel.Controls.Add(Me.ListView1)
        Me.FeedsPanel.Dock = System.Windows.Forms.DockStyle.Fill
        Me.FeedsPanel.Location = New System.Drawing.Point(0, 0)
        Me.FeedsPanel.Name = "FeedsPanel"
        Me.FeedsPanel.Padding = New System.Windows.Forms.Padding(8)
        Me.FeedsPanel.Size = New System.Drawing.Size(1008, 571)
        Me.FeedsPanel.TabIndex = 1
        '
        'ListView1
        '
        Me.ListView1.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.ListView1.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.ColumnHeader1, Me.ColumnHeader2})
        Me.ListView1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.ListView1.FullRowSelect = True
        Me.ListView1.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.None
        Me.ListView1.Location = New System.Drawing.Point(8, 8)
        Me.ListView1.MultiSelect = False
        Me.ListView1.Name = "ListView1"
        Me.ListView1.Size = New System.Drawing.Size(992, 555)
        Me.ListView1.TabIndex = 0
        Me.ListView1.UseCompatibleStateImageBehavior = False
        Me.ListView1.View = System.Windows.Forms.View.Details
        '
        'ColumnHeader1
        '
        Me.ColumnHeader1.Text = "Title"
        Me.ColumnHeader1.Width = 726
        '
        'ColumnHeader2
        '
        Me.ColumnHeader2.Text = "Date"
        Me.ColumnHeader2.Width = 254
        '
        'FeedErrorPanel
        '
        Me.FeedErrorPanel.Controls.Add(Me.Button59)
        Me.FeedErrorPanel.Controls.Add(Me.TextBox1)
        Me.FeedErrorPanel.Controls.Add(Me.Label35)
        Me.FeedErrorPanel.Controls.Add(Me.Label34)
        Me.FeedErrorPanel.Controls.Add(Me.Label22)
        Me.FeedErrorPanel.Dock = System.Windows.Forms.DockStyle.Fill
        Me.FeedErrorPanel.Location = New System.Drawing.Point(0, 0)
        Me.FeedErrorPanel.Name = "FeedErrorPanel"
        Me.FeedErrorPanel.Size = New System.Drawing.Size(1008, 571)
        Me.FeedErrorPanel.TabIndex = 0
        '
        'Button59
        '
        Me.Button59.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button59.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.Button59.Location = New System.Drawing.Point(880, 337)
        Me.Button59.Name = "Button59"
        Me.Button59.Size = New System.Drawing.Size(114, 23)
        Me.Button59.TabIndex = 2
        Me.Button59.Text = "Try again"
        Me.Button59.UseVisualStyleBackColor = True
        '
        'TextBox1
        '
        Me.TextBox1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TextBox1.Font = New System.Drawing.Font("Consolas", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox1.Location = New System.Drawing.Point(18, 78)
        Me.TextBox1.Multiline = True
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.ReadOnly = True
        Me.TextBox1.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.TextBox1.Size = New System.Drawing.Size(972, 252)
        Me.TextBox1.TabIndex = 1
        '
        'Label35
        '
        Me.Label35.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label35.AutoEllipsis = True
        Me.Label35.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.Label35.Location = New System.Drawing.Point(14, 363)
        Me.Label35.Name = "Label35"
        Me.Label35.Size = New System.Drawing.Size(978, 49)
        Me.Label35.TabIndex = 0
        Me.Label35.Text = "Try connecting your system to the network. If your system is connected to the net" & _
    "work but this error still appears, check whether you can access websites."
        '
        'Label34
        '
        Me.Label34.AutoSize = True
        Me.Label34.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.Label34.Location = New System.Drawing.Point(14, 55)
        Me.Label34.Name = "Label34"
        Me.Label34.Size = New System.Drawing.Size(101, 15)
        Me.Label34.TabIndex = 0
        Me.Label34.Text = "Error information:"
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.Font = New System.Drawing.Font("Segoe UI", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label22.Location = New System.Drawing.Point(12, 12)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(305, 30)
        Me.Label22.TabIndex = 0
        Me.Label22.Text = "We couldn't get the latest news"
        '
        'Panel4
        '
        Me.Panel4.Controls.Add(Me.Label9)
        Me.Panel4.Controls.Add(Me.LinkLabel25)
        Me.Panel4.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.Panel4.Location = New System.Drawing.Point(0, 571)
        Me.Panel4.Name = "Panel4"
        Me.Panel4.Size = New System.Drawing.Size(1008, 48)
        Me.Panel4.TabIndex = 1
        '
        'Label9
        '
        Me.Label9.AutoEllipsis = True
        Me.Label9.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Label9.Location = New System.Drawing.Point(0, 0)
        Me.Label9.Name = "Label9"
        Me.Label9.Padding = New System.Windows.Forms.Padding(4, 4, 0, 0)
        Me.Label9.Size = New System.Drawing.Size(880, 48)
        Me.Label9.TabIndex = 0
        Me.Label9.Text = "To get the latest DISMTools development news, check out the discussion on the My " & _
    "Digital Life forums. An account is required to view most content."
        '
        'LinkLabel25
        '
        Me.LinkLabel25.AutoEllipsis = True
        Me.LinkLabel25.Dock = System.Windows.Forms.DockStyle.Right
        Me.LinkLabel25.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline
        Me.LinkLabel25.LinkColor = System.Drawing.Color.DodgerBlue
        Me.LinkLabel25.Location = New System.Drawing.Point(880, 0)
        Me.LinkLabel25.Name = "LinkLabel25"
        Me.LinkLabel25.Size = New System.Drawing.Size(128, 48)
        Me.LinkLabel25.TabIndex = 1
        Me.LinkLabel25.TabStop = True
        Me.LinkLabel25.Text = "Visit"
        Me.LinkLabel25.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'TutorialVideoPanel
        '
        Me.TutorialVideoPanel.Controls.Add(Me.VideoContainer)
        Me.TutorialVideoPanel.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TutorialVideoPanel.Location = New System.Drawing.Point(0, 0)
        Me.TutorialVideoPanel.Name = "TutorialVideoPanel"
        Me.TutorialVideoPanel.Size = New System.Drawing.Size(1008, 619)
        Me.TutorialVideoPanel.TabIndex = 0
        Me.TutorialVideoPanel.Visible = False
        '
        'VideoContainer
        '
        Me.VideoContainer.Controls.Add(Me.VideosPanel)
        Me.VideoContainer.Controls.Add(Me.VideoErrorPanel)
        Me.VideoContainer.Dock = System.Windows.Forms.DockStyle.Fill
        Me.VideoContainer.Location = New System.Drawing.Point(0, 0)
        Me.VideoContainer.Name = "VideoContainer"
        Me.VideoContainer.Size = New System.Drawing.Size(1008, 619)
        Me.VideoContainer.TabIndex = 2
        '
        'VideosPanel
        '
        Me.VideosPanel.Controls.Add(Me.ListView2)
        Me.VideosPanel.Dock = System.Windows.Forms.DockStyle.Fill
        Me.VideosPanel.Location = New System.Drawing.Point(0, 0)
        Me.VideosPanel.Name = "VideosPanel"
        Me.VideosPanel.Padding = New System.Windows.Forms.Padding(8)
        Me.VideosPanel.Size = New System.Drawing.Size(1008, 619)
        Me.VideosPanel.TabIndex = 1
        '
        'ListView2
        '
        Me.ListView2.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.ListView2.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.ColumnHeader4, Me.ColumnHeader5})
        Me.ListView2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.ListView2.FullRowSelect = True
        Me.ListView2.Location = New System.Drawing.Point(8, 8)
        Me.ListView2.MultiSelect = False
        Me.ListView2.Name = "ListView2"
        Me.ListView2.Size = New System.Drawing.Size(992, 603)
        Me.ListView2.TabIndex = 0
        Me.ListView2.UseCompatibleStateImageBehavior = False
        Me.ListView2.View = System.Windows.Forms.View.Details
        '
        'ColumnHeader4
        '
        Me.ColumnHeader4.Text = "Name"
        Me.ColumnHeader4.Width = 375
        '
        'ColumnHeader5
        '
        Me.ColumnHeader5.Text = "Description"
        Me.ColumnHeader5.Width = 592
        '
        'VideoErrorPanel
        '
        Me.VideoErrorPanel.Controls.Add(Me.Button17)
        Me.VideoErrorPanel.Controls.Add(Me.TextBox2)
        Me.VideoErrorPanel.Controls.Add(Me.Label6)
        Me.VideoErrorPanel.Controls.Add(Me.Label7)
        Me.VideoErrorPanel.Controls.Add(Me.Label11)
        Me.VideoErrorPanel.Dock = System.Windows.Forms.DockStyle.Fill
        Me.VideoErrorPanel.Location = New System.Drawing.Point(0, 0)
        Me.VideoErrorPanel.Name = "VideoErrorPanel"
        Me.VideoErrorPanel.Size = New System.Drawing.Size(1008, 619)
        Me.VideoErrorPanel.TabIndex = 0
        '
        'Button17
        '
        Me.Button17.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button17.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.Button17.Location = New System.Drawing.Point(880, 385)
        Me.Button17.Name = "Button17"
        Me.Button17.Size = New System.Drawing.Size(114, 23)
        Me.Button17.TabIndex = 2
        Me.Button17.Text = "Try again"
        Me.Button17.UseVisualStyleBackColor = True
        '
        'TextBox2
        '
        Me.TextBox2.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TextBox2.Font = New System.Drawing.Font("Consolas", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox2.Location = New System.Drawing.Point(18, 78)
        Me.TextBox2.Multiline = True
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.ReadOnly = True
        Me.TextBox2.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.TextBox2.Size = New System.Drawing.Size(972, 300)
        Me.TextBox2.TabIndex = 1
        '
        'Label6
        '
        Me.Label6.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label6.AutoEllipsis = True
        Me.Label6.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.Label6.Location = New System.Drawing.Point(14, 411)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(978, 49)
        Me.Label6.TabIndex = 0
        Me.Label6.Text = "Try connecting your system to the network. If your system is connected to the net" & _
    "work but this error still appears, check whether you can access websites."
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.Label7.Location = New System.Drawing.Point(14, 55)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(101, 15)
        Me.Label7.TabIndex = 0
        Me.Label7.Text = "Error information:"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Font = New System.Drawing.Font("Segoe UI", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.Location = New System.Drawing.Point(12, 12)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(317, 30)
        Me.Label11.TabIndex = 0
        Me.Label11.Text = "We couldn't get the latest videos"
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.FlowLayoutPanel2)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel1.Location = New System.Drawing.Point(0, 0)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(1008, 38)
        Me.Panel1.TabIndex = 4
        '
        'FlowLayoutPanel2
        '
        Me.FlowLayoutPanel2.Controls.Add(Me.LinkLabel22)
        Me.FlowLayoutPanel2.Controls.Add(Me.LinkLabel23)
        Me.FlowLayoutPanel2.Controls.Add(Me.LinkLabel24)
        Me.FlowLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.FlowLayoutPanel2.FlowDirection = System.Windows.Forms.FlowDirection.TopDown
        Me.FlowLayoutPanel2.Location = New System.Drawing.Point(0, 0)
        Me.FlowLayoutPanel2.Name = "FlowLayoutPanel2"
        Me.FlowLayoutPanel2.Padding = New System.Windows.Forms.Padding(10, 12, 0, 0)
        Me.FlowLayoutPanel2.Size = New System.Drawing.Size(1008, 38)
        Me.FlowLayoutPanel2.TabIndex = 1
        '
        'LinkLabel22
        '
        Me.LinkLabel22.ActiveLinkColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(123, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.LinkLabel22.AutoSize = True
        Me.LinkLabel22.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LinkLabel22.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline
        Me.LinkLabel22.LinkColor = System.Drawing.SystemColors.ControlText
        Me.LinkLabel22.Location = New System.Drawing.Point(13, 12)
        Me.LinkLabel22.Name = "LinkLabel22"
        Me.LinkLabel22.Size = New System.Drawing.Size(64, 15)
        Me.LinkLabel22.TabIndex = 0
        Me.LinkLabel22.TabStop = True
        Me.LinkLabel22.Text = "WELCOME"
        '
        'LinkLabel23
        '
        Me.LinkLabel23.ActiveLinkColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(123, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.LinkLabel23.AutoSize = True
        Me.LinkLabel23.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LinkLabel23.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline
        Me.LinkLabel23.LinkColor = System.Drawing.Color.FromArgb(CType(CType(153, Byte), Integer), CType(CType(153, Byte), Integer), CType(CType(153, Byte), Integer))
        Me.LinkLabel23.Location = New System.Drawing.Point(83, 12)
        Me.LinkLabel23.Name = "LinkLabel23"
        Me.LinkLabel23.Size = New System.Drawing.Size(84, 15)
        Me.LinkLabel23.TabIndex = 0
        Me.LinkLabel23.TabStop = True
        Me.LinkLabel23.Text = "LATEST NEWS"
        '
        'LinkLabel24
        '
        Me.LinkLabel24.ActiveLinkColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(123, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.LinkLabel24.AutoSize = True
        Me.LinkLabel24.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LinkLabel24.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline
        Me.LinkLabel24.LinkColor = System.Drawing.Color.FromArgb(CType(CType(153, Byte), Integer), CType(CType(153, Byte), Integer), CType(CType(153, Byte), Integer))
        Me.LinkLabel24.Location = New System.Drawing.Point(173, 12)
        Me.LinkLabel24.Name = "LinkLabel24"
        Me.LinkLabel24.Size = New System.Drawing.Size(111, 15)
        Me.LinkLabel24.TabIndex = 0
        Me.LinkLabel24.TabStop = True
        Me.LinkLabel24.Text = "TUTORIAL VIDEOS"
        '
        'SidePanel
        '
        Me.SidePanel.BackColor = System.Drawing.Color.White
        Me.SidePanel.Controls.Add(Me.RecentsLV)
        Me.SidePanel.Controls.Add(Me.UpdatePanel)
        Me.SidePanel.Controls.Add(Me.RecentRemoveLink)
        Me.SidePanel.Controls.Add(Me.OfflineInstMgmt)
        Me.SidePanel.Controls.Add(Me.OnlineInstMgmt)
        Me.SidePanel.Controls.Add(Me.ExistingProjLink)
        Me.SidePanel.Controls.Add(Me.NewProjLink)
        Me.SidePanel.Controls.Add(Me.Label10)
        Me.SidePanel.Controls.Add(Me.LabelHeader1)
        Me.SidePanel.Controls.Add(Me.Panel3)
        Me.SidePanel.Dock = System.Windows.Forms.DockStyle.Left
        Me.SidePanel.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.SidePanel.Location = New System.Drawing.Point(0, 0)
        Me.SidePanel.Name = "SidePanel"
        Me.SidePanel.Size = New System.Drawing.Size(256, 657)
        Me.SidePanel.TabIndex = 0
        '
        'RecentsLV
        '
        Me.RecentsLV.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.RecentsLV.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.RecentsLV.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.ColumnHeader3})
        Me.RecentsLV.ForeColor = System.Drawing.Color.DodgerBlue
        Me.RecentsLV.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.None
        Me.RecentsLV.Location = New System.Drawing.Point(28, 222)
        Me.RecentsLV.MultiSelect = False
        Me.RecentsLV.Name = "RecentsLV"
        Me.RecentsLV.Size = New System.Drawing.Size(196, 307)
        Me.RecentsLV.TabIndex = 6
        Me.RecentsLV.UseCompatibleStateImageBehavior = False
        Me.RecentsLV.View = System.Windows.Forms.View.Details
        '
        'ColumnHeader3
        '
        Me.ColumnHeader3.Text = "Path/Name"
        Me.ColumnHeader3.Width = 163
        '
        'UpdatePanel
        '
        Me.UpdatePanel.Controls.Add(Me.UpdateLink)
        Me.UpdatePanel.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.UpdatePanel.Location = New System.Drawing.Point(0, 573)
        Me.UpdatePanel.Name = "UpdatePanel"
        Me.UpdatePanel.Size = New System.Drawing.Size(256, 84)
        Me.UpdatePanel.TabIndex = 5
        '
        'UpdateLink
        '
        Me.UpdateLink.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.UpdateLink.AutoEllipsis = True
        Me.UpdateLink.LinkArea = New System.Windows.Forms.LinkArea(58, 24)
        Me.UpdateLink.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline
        Me.UpdateLink.LinkColor = System.Drawing.Color.DodgerBlue
        Me.UpdateLink.Location = New System.Drawing.Point(16, 14)
        Me.UpdateLink.Name = "UpdateLink"
        Me.UpdateLink.Size = New System.Drawing.Size(223, 56)
        Me.UpdateLink.TabIndex = 0
        Me.UpdateLink.TabStop = True
        Me.UpdateLink.Text = "A new version is available for download and installation. Click here to learn mor" & _
    "e"
        Me.UpdateLink.UseCompatibleTextRendering = True
        '
        'RecentRemoveLink
        '
        Me.RecentRemoveLink.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.RecentRemoveLink.AutoEllipsis = True
        Me.RecentRemoveLink.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline
        Me.RecentRemoveLink.LinkColor = System.Drawing.Color.DodgerBlue
        Me.RecentRemoveLink.Location = New System.Drawing.Point(34, 535)
        Me.RecentRemoveLink.Name = "RecentRemoveLink"
        Me.RecentRemoveLink.Size = New System.Drawing.Size(190, 15)
        Me.RecentRemoveLink.TabIndex = 2
        Me.RecentRemoveLink.TabStop = True
        Me.RecentRemoveLink.Text = "Remove entry"
        Me.RecentRemoveLink.TextAlign = System.Drawing.ContentAlignment.TopRight
        Me.RecentRemoveLink.Visible = False
        '
        'OfflineInstMgmt
        '
        Me.OfflineInstMgmt.AutoSize = True
        Me.OfflineInstMgmt.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline
        Me.OfflineInstMgmt.LinkColor = System.Drawing.Color.DodgerBlue
        Me.OfflineInstMgmt.Location = New System.Drawing.Point(31, 168)
        Me.OfflineInstMgmt.Name = "OfflineInstMgmt"
        Me.OfflineInstMgmt.Size = New System.Drawing.Size(157, 15)
        Me.OfflineInstMgmt.TabIndex = 2
        Me.OfflineInstMgmt.TabStop = True
        Me.OfflineInstMgmt.Text = "Manage offline installation..."
        '
        'OnlineInstMgmt
        '
        Me.OnlineInstMgmt.AutoSize = True
        Me.OnlineInstMgmt.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline
        Me.OnlineInstMgmt.LinkColor = System.Drawing.Color.DodgerBlue
        Me.OnlineInstMgmt.Location = New System.Drawing.Point(31, 150)
        Me.OnlineInstMgmt.Name = "OnlineInstMgmt"
        Me.OnlineInstMgmt.Size = New System.Drawing.Size(147, 15)
        Me.OnlineInstMgmt.TabIndex = 2
        Me.OnlineInstMgmt.TabStop = True
        Me.OnlineInstMgmt.Text = "Manage online installation"
        '
        'ExistingProjLink
        '
        Me.ExistingProjLink.AutoSize = True
        Me.ExistingProjLink.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline
        Me.ExistingProjLink.LinkColor = System.Drawing.Color.DodgerBlue
        Me.ExistingProjLink.Location = New System.Drawing.Point(31, 132)
        Me.ExistingProjLink.Name = "ExistingProjLink"
        Me.ExistingProjLink.Size = New System.Drawing.Size(129, 15)
        Me.ExistingProjLink.TabIndex = 2
        Me.ExistingProjLink.TabStop = True
        Me.ExistingProjLink.Text = "Open existing project..."
        '
        'NewProjLink
        '
        Me.NewProjLink.AutoSize = True
        Me.NewProjLink.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline
        Me.NewProjLink.LinkColor = System.Drawing.Color.DodgerBlue
        Me.NewProjLink.Location = New System.Drawing.Point(31, 114)
        Me.NewProjLink.Name = "NewProjLink"
        Me.NewProjLink.Size = New System.Drawing.Size(80, 15)
        Me.NewProjLink.TabIndex = 2
        Me.NewProjLink.TabStop = True
        Me.NewProjLink.Text = "New project..."
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.Location = New System.Drawing.Point(14, 194)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(116, 21)
        Me.Label10.TabIndex = 1
        Me.Label10.Text = "Recent projects"
        '
        'LabelHeader1
        '
        Me.LabelHeader1.AutoSize = True
        Me.LabelHeader1.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabelHeader1.Location = New System.Drawing.Point(14, 76)
        Me.LabelHeader1.Name = "LabelHeader1"
        Me.LabelHeader1.Size = New System.Drawing.Size(49, 21)
        Me.LabelHeader1.TabIndex = 1
        Me.LabelHeader1.Text = "Begin"
        '
        'Panel3
        '
        Me.Panel3.Controls.Add(Me.PictureBox5)
        Me.Panel3.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel3.Location = New System.Drawing.Point(0, 0)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(256, 64)
        Me.Panel3.TabIndex = 0
        '
        'PictureBox5
        '
        Me.PictureBox5.Image = CType(resources.GetObject("PictureBox5.Image"), System.Drawing.Image)
        Me.PictureBox5.Location = New System.Drawing.Point(32, 14)
        Me.PictureBox5.Name = "PictureBox5"
        Me.PictureBox5.Size = New System.Drawing.Size(192, 36)
        Me.PictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.PictureBox5.TabIndex = 7
        Me.PictureBox5.TabStop = False
        '
        'PrjPanel
        '
        Me.PrjPanel.Controls.Add(Me.ProjectView)
        Me.PrjPanel.Controls.Add(Me.SplitPanels)
        Me.PrjPanel.Controls.Add(Me.ToolStrip1)
        Me.PrjPanel.Controls.Add(Me.Panel2)
        Me.PrjPanel.Controls.Add(Me.StatusStrip)
        Me.PrjPanel.Dock = System.Windows.Forms.DockStyle.Fill
        Me.PrjPanel.Location = New System.Drawing.Point(0, 24)
        Me.PrjPanel.Name = "PrjPanel"
        Me.PrjPanel.Size = New System.Drawing.Size(1264, 657)
        Me.PrjPanel.TabIndex = 4
        '
        'ProjectView
        '
        Me.ProjectView.Controls.Add(Me.Panel11)
        Me.ProjectView.Controls.Add(Me.ProjectSidePanel)
        Me.ProjectView.Controls.Add(Me.ProjectViewHeader)
        Me.ProjectView.Dock = System.Windows.Forms.DockStyle.Fill
        Me.ProjectView.Location = New System.Drawing.Point(0, 25)
        Me.ProjectView.Name = "ProjectView"
        Me.ProjectView.Size = New System.Drawing.Size(1008, 606)
        Me.ProjectView.TabIndex = 3
        Me.ProjectView.Visible = False
        '
        'Panel11
        '
        Me.Panel11.Controls.Add(Me.FlowLayoutPanel1)
        Me.Panel11.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel11.Location = New System.Drawing.Point(300, 48)
        Me.Panel11.Name = "Panel11"
        Me.Panel11.Size = New System.Drawing.Size(708, 558)
        Me.Panel11.TabIndex = 2
        '
        'FlowLayoutPanel1
        '
        Me.FlowLayoutPanel1.AutoScroll = True
        Me.FlowLayoutPanel1.BackColor = System.Drawing.SystemColors.Control
        Me.FlowLayoutPanel1.Controls.Add(Me.GroupBox4)
        Me.FlowLayoutPanel1.Controls.Add(Me.GroupBox5)
        Me.FlowLayoutPanel1.Controls.Add(Me.GroupBox6)
        Me.FlowLayoutPanel1.Controls.Add(Me.GroupBox7)
        Me.FlowLayoutPanel1.Controls.Add(Me.GroupBox8)
        Me.FlowLayoutPanel1.Controls.Add(Me.GroupBox9)
        Me.FlowLayoutPanel1.Controls.Add(Me.GroupBox10)
        Me.FlowLayoutPanel1.Controls.Add(Me.Button20)
        Me.FlowLayoutPanel1.Controls.Add(Me.SpaceLabel)
        Me.FlowLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.FlowLayoutPanel1.ForeColor = System.Drawing.SystemColors.ControlText
        Me.FlowLayoutPanel1.Location = New System.Drawing.Point(0, 0)
        Me.FlowLayoutPanel1.Name = "FlowLayoutPanel1"
        Me.FlowLayoutPanel1.Padding = New System.Windows.Forms.Padding(8)
        Me.FlowLayoutPanel1.Size = New System.Drawing.Size(708, 558)
        Me.FlowLayoutPanel1.TabIndex = 1
        '
        'GroupBox4
        '
        Me.GroupBox4.Controls.Add(Me.Button24)
        Me.GroupBox4.Controls.Add(Me.Button31)
        Me.GroupBox4.Controls.Add(Me.Button30)
        Me.GroupBox4.Controls.Add(Me.Button33)
        Me.GroupBox4.Controls.Add(Me.Button32)
        Me.GroupBox4.Controls.Add(Me.Button26)
        Me.GroupBox4.Controls.Add(Me.Button25)
        Me.GroupBox4.Controls.Add(Me.Button29)
        Me.GroupBox4.Controls.Add(Me.Button28)
        Me.GroupBox4.Controls.Add(Me.Button27)
        Me.GroupBox4.Location = New System.Drawing.Point(11, 11)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Size = New System.Drawing.Size(666, 230)
        Me.GroupBox4.TabIndex = 0
        Me.GroupBox4.TabStop = False
        Me.GroupBox4.Text = "Image operations"
        '
        'Button24
        '
        Me.Button24.ForeColor = System.Drawing.Color.Black
        Me.Button24.Image = CType(resources.GetObject("Button24.Image"), System.Drawing.Image)
        Me.Button24.Location = New System.Drawing.Point(336, 89)
        Me.Button24.Name = "Button24"
        Me.Button24.Size = New System.Drawing.Size(324, 63)
        Me.Button24.TabIndex = 1
        Me.Button24.Text = "Switch image indexes..."
        Me.Button24.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.Button24.UseVisualStyleBackColor = True
        '
        'Button31
        '
        Me.Button31.ForeColor = System.Drawing.Color.Black
        Me.Button31.Image = Global.DISMTools.My.Resources.Resources.capture_img
        Me.Button31.Location = New System.Drawing.Point(171, 158)
        Me.Button31.Name = "Button31"
        Me.Button31.Size = New System.Drawing.Size(159, 63)
        Me.Button31.TabIndex = 1
        Me.Button31.Text = "Capture image..."
        Me.Button31.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.Button31.UseVisualStyleBackColor = True
        '
        'Button30
        '
        Me.Button30.ForeColor = System.Drawing.Color.Black
        Me.Button30.Image = Global.DISMTools.My.Resources.Resources.apply_img
        Me.Button30.Location = New System.Drawing.Point(6, 158)
        Me.Button30.Name = "Button30"
        Me.Button30.Size = New System.Drawing.Size(159, 63)
        Me.Button30.TabIndex = 1
        Me.Button30.Text = "Apply image..."
        Me.Button30.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.Button30.UseVisualStyleBackColor = True
        '
        'Button33
        '
        Me.Button33.ForeColor = System.Drawing.Color.Black
        Me.Button33.Location = New System.Drawing.Point(501, 158)
        Me.Button33.Name = "Button33"
        Me.Button33.Size = New System.Drawing.Size(159, 63)
        Me.Button33.TabIndex = 1
        Me.Button33.Text = "Save complete image information..."
        Me.Button33.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.Button33.UseVisualStyleBackColor = True
        '
        'Button32
        '
        Me.Button32.ForeColor = System.Drawing.Color.Black
        Me.Button32.Image = Global.DISMTools.My.Resources.Resources.delete_imgindex
        Me.Button32.Location = New System.Drawing.Point(336, 158)
        Me.Button32.Name = "Button32"
        Me.Button32.Size = New System.Drawing.Size(159, 63)
        Me.Button32.TabIndex = 1
        Me.Button32.Text = "Remove volume images..."
        Me.Button32.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.Button32.UseVisualStyleBackColor = True
        '
        'Button26
        '
        Me.Button26.ForeColor = System.Drawing.Color.Black
        Me.Button26.Image = CType(resources.GetObject("Button26.Image"), System.Drawing.Image)
        Me.Button26.Location = New System.Drawing.Point(6, 20)
        Me.Button26.Name = "Button26"
        Me.Button26.Size = New System.Drawing.Size(159, 63)
        Me.Button26.TabIndex = 1
        Me.Button26.Text = "Mount image..."
        Me.Button26.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.Button26.UseVisualStyleBackColor = True
        '
        'Button25
        '
        Me.Button25.ForeColor = System.Drawing.Color.Black
        Me.Button25.Image = CType(resources.GetObject("Button25.Image"), System.Drawing.Image)
        Me.Button25.Location = New System.Drawing.Point(6, 89)
        Me.Button25.Name = "Button25"
        Me.Button25.Size = New System.Drawing.Size(324, 63)
        Me.Button25.TabIndex = 1
        Me.Button25.Text = "Reload servicing session"
        Me.Button25.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.Button25.UseVisualStyleBackColor = True
        '
        'Button29
        '
        Me.Button29.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button29.ForeColor = System.Drawing.Color.Black
        Me.Button29.Location = New System.Drawing.Point(336, 54)
        Me.Button29.Name = "Button29"
        Me.Button29.Size = New System.Drawing.Size(324, 28)
        Me.Button29.TabIndex = 1
        Me.Button29.Text = "Unmount image discarding changes"
        Me.Button29.UseVisualStyleBackColor = True
        '
        'Button28
        '
        Me.Button28.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button28.ForeColor = System.Drawing.Color.Black
        Me.Button28.Location = New System.Drawing.Point(336, 20)
        Me.Button28.Name = "Button28"
        Me.Button28.Size = New System.Drawing.Size(324, 28)
        Me.Button28.TabIndex = 1
        Me.Button28.Text = "Commit and unmount image"
        Me.Button28.UseVisualStyleBackColor = True
        '
        'Button27
        '
        Me.Button27.ForeColor = System.Drawing.Color.Black
        Me.Button27.Image = CType(resources.GetObject("Button27.Image"), System.Drawing.Image)
        Me.Button27.Location = New System.Drawing.Point(171, 20)
        Me.Button27.Name = "Button27"
        Me.Button27.Size = New System.Drawing.Size(159, 63)
        Me.Button27.TabIndex = 1
        Me.Button27.Text = "Commit current changes"
        Me.Button27.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.Button27.UseVisualStyleBackColor = True
        '
        'GroupBox5
        '
        Me.GroupBox5.Controls.Add(Me.Button38)
        Me.GroupBox5.Controls.Add(Me.Button35)
        Me.GroupBox5.Controls.Add(Me.Button37)
        Me.GroupBox5.Controls.Add(Me.Button34)
        Me.GroupBox5.Controls.Add(Me.Button36)
        Me.GroupBox5.Location = New System.Drawing.Point(11, 247)
        Me.GroupBox5.Name = "GroupBox5"
        Me.GroupBox5.Size = New System.Drawing.Size(666, 162)
        Me.GroupBox5.TabIndex = 0
        Me.GroupBox5.TabStop = False
        Me.GroupBox5.Text = "Package operations"
        '
        'Button38
        '
        Me.Button38.ForeColor = System.Drawing.Color.Black
        Me.Button38.Location = New System.Drawing.Point(446, 20)
        Me.Button38.Name = "Button38"
        Me.Button38.Size = New System.Drawing.Size(214, 63)
        Me.Button38.TabIndex = 1
        Me.Button38.Text = "Save installed package information..."
        Me.Button38.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.Button38.UseVisualStyleBackColor = True
        '
        'Button35
        '
        Me.Button35.ForeColor = System.Drawing.Color.Black
        Me.Button35.Image = CType(resources.GetObject("Button35.Image"), System.Drawing.Image)
        Me.Button35.Location = New System.Drawing.Point(6, 89)
        Me.Button35.Name = "Button35"
        Me.Button35.Size = New System.Drawing.Size(324, 63)
        Me.Button35.TabIndex = 1
        Me.Button35.Text = "Remove package..."
        Me.Button35.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.Button35.UseVisualStyleBackColor = True
        '
        'Button37
        '
        Me.Button37.ForeColor = System.Drawing.Color.Black
        Me.Button37.Image = Global.DISMTools.My.Resources.Resources.cleanup_img
        Me.Button37.Location = New System.Drawing.Point(336, 89)
        Me.Button37.Name = "Button37"
        Me.Button37.Size = New System.Drawing.Size(324, 63)
        Me.Button37.TabIndex = 1
        Me.Button37.Text = "Perform component store maintenance and cleanup..."
        Me.Button37.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.Button37.UseVisualStyleBackColor = True
        '
        'Button34
        '
        Me.Button34.ForeColor = System.Drawing.Color.Black
        Me.Button34.Image = CType(resources.GetObject("Button34.Image"), System.Drawing.Image)
        Me.Button34.Location = New System.Drawing.Point(226, 20)
        Me.Button34.Name = "Button34"
        Me.Button34.Size = New System.Drawing.Size(214, 63)
        Me.Button34.TabIndex = 1
        Me.Button34.Text = "Get package information..."
        Me.Button34.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.Button34.UseVisualStyleBackColor = True
        '
        'Button36
        '
        Me.Button36.ForeColor = System.Drawing.Color.Black
        Me.Button36.Image = CType(resources.GetObject("Button36.Image"), System.Drawing.Image)
        Me.Button36.Location = New System.Drawing.Point(6, 20)
        Me.Button36.Name = "Button36"
        Me.Button36.Size = New System.Drawing.Size(214, 63)
        Me.Button36.TabIndex = 1
        Me.Button36.Text = "Add package..."
        Me.Button36.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.Button36.UseVisualStyleBackColor = True
        '
        'GroupBox6
        '
        Me.GroupBox6.Controls.Add(Me.Button42)
        Me.GroupBox6.Controls.Add(Me.Button39)
        Me.GroupBox6.Controls.Add(Me.Button41)
        Me.GroupBox6.Controls.Add(Me.Button40)
        Me.GroupBox6.Location = New System.Drawing.Point(11, 415)
        Me.GroupBox6.Name = "GroupBox6"
        Me.GroupBox6.Size = New System.Drawing.Size(666, 93)
        Me.GroupBox6.TabIndex = 0
        Me.GroupBox6.TabStop = False
        Me.GroupBox6.Text = "Feature operations"
        '
        'Button42
        '
        Me.Button42.ForeColor = System.Drawing.Color.Black
        Me.Button42.Location = New System.Drawing.Point(336, 20)
        Me.Button42.Name = "Button42"
        Me.Button42.Size = New System.Drawing.Size(159, 63)
        Me.Button42.TabIndex = 1
        Me.Button42.Text = "Save feature information..."
        Me.Button42.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.Button42.UseVisualStyleBackColor = True
        '
        'Button39
        '
        Me.Button39.ForeColor = System.Drawing.Color.Black
        Me.Button39.Image = CType(resources.GetObject("Button39.Image"), System.Drawing.Image)
        Me.Button39.Location = New System.Drawing.Point(171, 20)
        Me.Button39.Name = "Button39"
        Me.Button39.Size = New System.Drawing.Size(159, 63)
        Me.Button39.TabIndex = 1
        Me.Button39.Text = "Get feature information..."
        Me.Button39.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.Button39.UseVisualStyleBackColor = True
        '
        'Button41
        '
        Me.Button41.ForeColor = System.Drawing.Color.Black
        Me.Button41.Image = CType(resources.GetObject("Button41.Image"), System.Drawing.Image)
        Me.Button41.Location = New System.Drawing.Point(6, 20)
        Me.Button41.Name = "Button41"
        Me.Button41.Size = New System.Drawing.Size(159, 63)
        Me.Button41.TabIndex = 1
        Me.Button41.Text = "Enable feature..."
        Me.Button41.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.Button41.UseVisualStyleBackColor = True
        '
        'Button40
        '
        Me.Button40.ForeColor = System.Drawing.Color.Black
        Me.Button40.Image = CType(resources.GetObject("Button40.Image"), System.Drawing.Image)
        Me.Button40.Location = New System.Drawing.Point(501, 20)
        Me.Button40.Name = "Button40"
        Me.Button40.Size = New System.Drawing.Size(159, 63)
        Me.Button40.TabIndex = 1
        Me.Button40.Text = "Disable feature..."
        Me.Button40.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.Button40.UseVisualStyleBackColor = True
        '
        'GroupBox7
        '
        Me.GroupBox7.Controls.Add(Me.Button46)
        Me.GroupBox7.Controls.Add(Me.Button44)
        Me.GroupBox7.Controls.Add(Me.Button45)
        Me.GroupBox7.Controls.Add(Me.Button43)
        Me.GroupBox7.Location = New System.Drawing.Point(11, 514)
        Me.GroupBox7.Name = "GroupBox7"
        Me.GroupBox7.Size = New System.Drawing.Size(666, 93)
        Me.GroupBox7.TabIndex = 0
        Me.GroupBox7.TabStop = False
        Me.GroupBox7.Text = "AppX package operations"
        '
        'Button46
        '
        Me.Button46.ForeColor = System.Drawing.Color.Black
        Me.Button46.Location = New System.Drawing.Point(336, 20)
        Me.Button46.Name = "Button46"
        Me.Button46.Size = New System.Drawing.Size(159, 63)
        Me.Button46.TabIndex = 1
        Me.Button46.Text = "Save installed AppX package information..."
        Me.Button46.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.Button46.UseVisualStyleBackColor = True
        '
        'Button44
        '
        Me.Button44.ForeColor = System.Drawing.Color.Black
        Me.Button44.Image = Global.DISMTools.My.Resources.Resources.add_appxpkg
        Me.Button44.Location = New System.Drawing.Point(6, 20)
        Me.Button44.Name = "Button44"
        Me.Button44.Size = New System.Drawing.Size(159, 63)
        Me.Button44.TabIndex = 1
        Me.Button44.Text = "Add AppX package..."
        Me.Button44.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.Button44.UseVisualStyleBackColor = True
        '
        'Button45
        '
        Me.Button45.ForeColor = System.Drawing.Color.Black
        Me.Button45.Image = Global.DISMTools.My.Resources.Resources.get_appxpkg_info
        Me.Button45.Location = New System.Drawing.Point(171, 20)
        Me.Button45.Name = "Button45"
        Me.Button45.Size = New System.Drawing.Size(159, 63)
        Me.Button45.TabIndex = 1
        Me.Button45.Text = "Get app information..."
        Me.Button45.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.Button45.UseVisualStyleBackColor = True
        '
        'Button43
        '
        Me.Button43.ForeColor = System.Drawing.Color.Black
        Me.Button43.Image = Global.DISMTools.My.Resources.Resources.rem_appxpkg
        Me.Button43.Location = New System.Drawing.Point(501, 20)
        Me.Button43.Name = "Button43"
        Me.Button43.Size = New System.Drawing.Size(159, 63)
        Me.Button43.TabIndex = 1
        Me.Button43.Text = "Remove AppX package..."
        Me.Button43.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.Button43.UseVisualStyleBackColor = True
        '
        'GroupBox8
        '
        Me.GroupBox8.Controls.Add(Me.Button50)
        Me.GroupBox8.Controls.Add(Me.Button48)
        Me.GroupBox8.Controls.Add(Me.Button49)
        Me.GroupBox8.Controls.Add(Me.Button47)
        Me.GroupBox8.Location = New System.Drawing.Point(11, 613)
        Me.GroupBox8.Name = "GroupBox8"
        Me.GroupBox8.Size = New System.Drawing.Size(666, 93)
        Me.GroupBox8.TabIndex = 0
        Me.GroupBox8.TabStop = False
        Me.GroupBox8.Text = "Capability operations"
        '
        'Button50
        '
        Me.Button50.ForeColor = System.Drawing.Color.Black
        Me.Button50.Location = New System.Drawing.Point(336, 20)
        Me.Button50.Name = "Button50"
        Me.Button50.Size = New System.Drawing.Size(159, 63)
        Me.Button50.TabIndex = 1
        Me.Button50.Text = "Save capability information..."
        Me.Button50.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.Button50.UseVisualStyleBackColor = True
        '
        'Button48
        '
        Me.Button48.ForeColor = System.Drawing.Color.Black
        Me.Button48.Image = CType(resources.GetObject("Button48.Image"), System.Drawing.Image)
        Me.Button48.Location = New System.Drawing.Point(6, 20)
        Me.Button48.Name = "Button48"
        Me.Button48.Size = New System.Drawing.Size(159, 63)
        Me.Button48.TabIndex = 1
        Me.Button48.Text = "Add capability..."
        Me.Button48.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.Button48.UseVisualStyleBackColor = True
        '
        'Button49
        '
        Me.Button49.ForeColor = System.Drawing.Color.Black
        Me.Button49.Image = CType(resources.GetObject("Button49.Image"), System.Drawing.Image)
        Me.Button49.Location = New System.Drawing.Point(171, 20)
        Me.Button49.Name = "Button49"
        Me.Button49.Size = New System.Drawing.Size(159, 63)
        Me.Button49.TabIndex = 1
        Me.Button49.Text = "Get capability information..."
        Me.Button49.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.Button49.UseVisualStyleBackColor = True
        '
        'Button47
        '
        Me.Button47.ForeColor = System.Drawing.Color.Black
        Me.Button47.Image = CType(resources.GetObject("Button47.Image"), System.Drawing.Image)
        Me.Button47.Location = New System.Drawing.Point(501, 20)
        Me.Button47.Name = "Button47"
        Me.Button47.Size = New System.Drawing.Size(159, 63)
        Me.Button47.TabIndex = 1
        Me.Button47.Text = "Remove capability..."
        Me.Button47.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.Button47.UseVisualStyleBackColor = True
        '
        'GroupBox9
        '
        Me.GroupBox9.Controls.Add(Me.Button54)
        Me.GroupBox9.Controls.Add(Me.Button53)
        Me.GroupBox9.Controls.Add(Me.Button51)
        Me.GroupBox9.Controls.Add(Me.Button52)
        Me.GroupBox9.Location = New System.Drawing.Point(11, 712)
        Me.GroupBox9.Name = "GroupBox9"
        Me.GroupBox9.Size = New System.Drawing.Size(666, 93)
        Me.GroupBox9.TabIndex = 0
        Me.GroupBox9.TabStop = False
        Me.GroupBox9.Text = "Driver operations"
        '
        'Button54
        '
        Me.Button54.ForeColor = System.Drawing.Color.Black
        Me.Button54.Location = New System.Drawing.Point(336, 20)
        Me.Button54.Name = "Button54"
        Me.Button54.Size = New System.Drawing.Size(159, 63)
        Me.Button54.TabIndex = 1
        Me.Button54.Text = "Save installed driver information..."
        Me.Button54.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.Button54.UseVisualStyleBackColor = True
        '
        'Button53
        '
        Me.Button53.ForeColor = System.Drawing.Color.Black
        Me.Button53.Image = Global.DISMTools.My.Resources.Resources.add_drv
        Me.Button53.Location = New System.Drawing.Point(6, 20)
        Me.Button53.Name = "Button53"
        Me.Button53.Size = New System.Drawing.Size(159, 63)
        Me.Button53.TabIndex = 1
        Me.Button53.Text = "Add driver package..."
        Me.Button53.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.Button53.UseVisualStyleBackColor = True
        '
        'Button51
        '
        Me.Button51.ForeColor = System.Drawing.Color.Black
        Me.Button51.Image = Global.DISMTools.My.Resources.Resources.rem_drv
        Me.Button51.Location = New System.Drawing.Point(501, 20)
        Me.Button51.Name = "Button51"
        Me.Button51.Size = New System.Drawing.Size(159, 63)
        Me.Button51.TabIndex = 1
        Me.Button51.Text = "Remove driver..."
        Me.Button51.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.Button51.UseVisualStyleBackColor = True
        '
        'Button52
        '
        Me.Button52.ForeColor = System.Drawing.Color.Black
        Me.Button52.Image = Global.DISMTools.My.Resources.Resources.get_drv_info
        Me.Button52.Location = New System.Drawing.Point(171, 20)
        Me.Button52.Name = "Button52"
        Me.Button52.Size = New System.Drawing.Size(159, 63)
        Me.Button52.TabIndex = 1
        Me.Button52.Text = "Get driver information..."
        Me.Button52.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.Button52.UseVisualStyleBackColor = True
        '
        'GroupBox10
        '
        Me.GroupBox10.Controls.Add(Me.Button58)
        Me.GroupBox10.Controls.Add(Me.Button57)
        Me.GroupBox10.Controls.Add(Me.Button56)
        Me.GroupBox10.Controls.Add(Me.Button55)
        Me.GroupBox10.Location = New System.Drawing.Point(11, 811)
        Me.GroupBox10.Name = "GroupBox10"
        Me.GroupBox10.Size = New System.Drawing.Size(666, 53)
        Me.GroupBox10.TabIndex = 0
        Me.GroupBox10.TabStop = False
        Me.GroupBox10.Text = "Windows PE operations"
        '
        'Button58
        '
        Me.Button58.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Button58.ForeColor = System.Drawing.Color.Black
        Me.Button58.Location = New System.Drawing.Point(501, 20)
        Me.Button58.Name = "Button58"
        Me.Button58.Size = New System.Drawing.Size(159, 23)
        Me.Button58.TabIndex = 1
        Me.Button58.Text = "Set scratch space..."
        Me.Button58.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.Button58.UseVisualStyleBackColor = True
        '
        'Button57
        '
        Me.Button57.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Button57.ForeColor = System.Drawing.Color.Black
        Me.Button57.Location = New System.Drawing.Point(336, 20)
        Me.Button57.Name = "Button57"
        Me.Button57.Size = New System.Drawing.Size(159, 23)
        Me.Button57.TabIndex = 1
        Me.Button57.Text = "Set target path..."
        Me.Button57.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.Button57.UseVisualStyleBackColor = True
        '
        'Button56
        '
        Me.Button56.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Button56.ForeColor = System.Drawing.Color.Black
        Me.Button56.Location = New System.Drawing.Point(171, 20)
        Me.Button56.Name = "Button56"
        Me.Button56.Size = New System.Drawing.Size(159, 23)
        Me.Button56.TabIndex = 1
        Me.Button56.Text = "Save configuration..."
        Me.Button56.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.Button56.UseVisualStyleBackColor = True
        '
        'Button55
        '
        Me.Button55.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Button55.ForeColor = System.Drawing.Color.Black
        Me.Button55.Location = New System.Drawing.Point(7, 20)
        Me.Button55.Name = "Button55"
        Me.Button55.Size = New System.Drawing.Size(159, 23)
        Me.Button55.TabIndex = 1
        Me.Button55.Text = "Get configuration..."
        Me.Button55.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.Button55.UseVisualStyleBackColor = True
        '
        'Button20
        '
        Me.Button20.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Button20.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.Button20.Location = New System.Drawing.Point(11, 870)
        Me.Button20.Name = "Button20"
        Me.Button20.Size = New System.Drawing.Size(281, 23)
        Me.Button20.TabIndex = 0
        Me.Button20.Text = "Go back to the old design"
        Me.Button20.UseVisualStyleBackColor = True
        Me.Button20.Visible = False
        '
        'SpaceLabel
        '
        Me.SpaceLabel.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.SpaceLabel.AutoEllipsis = True
        Me.SpaceLabel.Location = New System.Drawing.Point(11, 896)
        Me.SpaceLabel.Name = "SpaceLabel"
        Me.SpaceLabel.Size = New System.Drawing.Size(675, 17)
        Me.SpaceLabel.TabIndex = 1
        '
        'ProjectSidePanel
        '
        Me.ProjectSidePanel.BackColor = System.Drawing.Color.FromArgb(CType(CType(4, Byte), Integer), CType(CType(17, Byte), Integer), CType(CType(51, Byte), Integer))
        Me.ProjectSidePanel.Controls.Add(Me.ProjectSidePanelContainer)
        Me.ProjectSidePanel.Controls.Add(Me.Panel10)
        Me.ProjectSidePanel.Dock = System.Windows.Forms.DockStyle.Left
        Me.ProjectSidePanel.ForeColor = System.Drawing.Color.White
        Me.ProjectSidePanel.Location = New System.Drawing.Point(0, 48)
        Me.ProjectSidePanel.Name = "ProjectSidePanel"
        Me.ProjectSidePanel.Size = New System.Drawing.Size(300, 558)
        Me.ProjectSidePanel.TabIndex = 1
        '
        'ProjectSidePanelContainer
        '
        Me.ProjectSidePanelContainer.Controls.Add(Me.SidePanel_ProjectView)
        Me.ProjectSidePanelContainer.Controls.Add(Me.SidePanel_ImageView)
        Me.ProjectSidePanelContainer.Dock = System.Windows.Forms.DockStyle.Fill
        Me.ProjectSidePanelContainer.Location = New System.Drawing.Point(0, 36)
        Me.ProjectSidePanelContainer.Name = "ProjectSidePanelContainer"
        Me.ProjectSidePanelContainer.Size = New System.Drawing.Size(300, 522)
        Me.ProjectSidePanelContainer.TabIndex = 1
        '
        'SidePanel_ProjectView
        '
        Me.SidePanel_ProjectView.Controls.Add(Me.Label55)
        Me.SidePanel_ProjectView.Controls.Add(Me.PrjTasks)
        Me.SidePanel_ProjectView.Controls.Add(Me.Button21)
        Me.SidePanel_ProjectView.Controls.Add(Me.Button22)
        Me.SidePanel_ProjectView.Controls.Add(Me.Button23)
        Me.SidePanel_ProjectView.Controls.Add(Me.TableLayoutPanel6)
        Me.SidePanel_ProjectView.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SidePanel_ProjectView.Location = New System.Drawing.Point(0, 0)
        Me.SidePanel_ProjectView.Name = "SidePanel_ProjectView"
        Me.SidePanel_ProjectView.Size = New System.Drawing.Size(300, 522)
        Me.SidePanel_ProjectView.TabIndex = 0
        '
        'Label55
        '
        Me.Label55.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Label55.AutoSize = True
        Me.Label55.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label55.Location = New System.Drawing.Point(11, 386)
        Me.Label55.Name = "Label55"
        Me.Label55.Size = New System.Drawing.Size(79, 15)
        Me.Label55.TabIndex = 14
        Me.Label55.Text = "Project Tasks"
        '
        'PrjTasks
        '
        Me.PrjTasks.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.PrjTasks.ColumnCount = 2
        Me.PrjTasks.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 32.0!))
        Me.PrjTasks.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.PrjTasks.Controls.Add(Me.LinkLabel17, 1, 2)
        Me.PrjTasks.Controls.Add(Me.PictureBox11, 0, 2)
        Me.PrjTasks.Controls.Add(Me.LinkLabel16, 1, 1)
        Me.PrjTasks.Controls.Add(Me.PictureBox10, 0, 1)
        Me.PrjTasks.Controls.Add(Me.LinkLabel15, 1, 0)
        Me.PrjTasks.Controls.Add(Me.PictureBox9, 0, 0)
        Me.PrjTasks.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.PrjTasks.Location = New System.Drawing.Point(10, 410)
        Me.PrjTasks.Name = "PrjTasks"
        Me.PrjTasks.RowCount = 3
        Me.PrjTasks.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.3333282!))
        Me.PrjTasks.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.3333282!))
        Me.PrjTasks.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.3333282!))
        Me.PrjTasks.Size = New System.Drawing.Size(283, 94)
        Me.PrjTasks.TabIndex = 13
        '
        'LinkLabel17
        '
        Me.LinkLabel17.ActiveLinkColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(151, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.LinkLabel17.AutoEllipsis = True
        Me.LinkLabel17.Cursor = System.Windows.Forms.Cursors.Arrow
        Me.LinkLabel17.Dock = System.Windows.Forms.DockStyle.Fill
        Me.LinkLabel17.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline
        Me.LinkLabel17.LinkColor = System.Drawing.Color.White
        Me.LinkLabel17.Location = New System.Drawing.Point(35, 62)
        Me.LinkLabel17.Name = "LinkLabel17"
        Me.LinkLabel17.Size = New System.Drawing.Size(245, 32)
        Me.LinkLabel17.TabIndex = 5
        Me.LinkLabel17.TabStop = True
        Me.LinkLabel17.Text = "Unload project"
        Me.LinkLabel17.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'PictureBox11
        '
        Me.PictureBox11.Dock = System.Windows.Forms.DockStyle.Fill
        Me.PictureBox11.Image = Global.DISMTools.My.Resources.Resources.prj_unload_glyph_dark
        Me.PictureBox11.Location = New System.Drawing.Point(3, 65)
        Me.PictureBox11.Name = "PictureBox11"
        Me.PictureBox11.Size = New System.Drawing.Size(26, 26)
        Me.PictureBox11.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage
        Me.PictureBox11.TabIndex = 4
        Me.PictureBox11.TabStop = False
        '
        'LinkLabel16
        '
        Me.LinkLabel16.ActiveLinkColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(151, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.LinkLabel16.AutoEllipsis = True
        Me.LinkLabel16.Cursor = System.Windows.Forms.Cursors.Arrow
        Me.LinkLabel16.Dock = System.Windows.Forms.DockStyle.Fill
        Me.LinkLabel16.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline
        Me.LinkLabel16.LinkColor = System.Drawing.Color.White
        Me.LinkLabel16.Location = New System.Drawing.Point(35, 31)
        Me.LinkLabel16.Name = "LinkLabel16"
        Me.LinkLabel16.Size = New System.Drawing.Size(245, 31)
        Me.LinkLabel16.TabIndex = 3
        Me.LinkLabel16.TabStop = True
        Me.LinkLabel16.Text = "Open in File Explorer"
        Me.LinkLabel16.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'PictureBox10
        '
        Me.PictureBox10.Dock = System.Windows.Forms.DockStyle.Fill
        Me.PictureBox10.Image = Global.DISMTools.My.Resources.Resources.explorer_view_glyph_dark
        Me.PictureBox10.Location = New System.Drawing.Point(3, 34)
        Me.PictureBox10.Name = "PictureBox10"
        Me.PictureBox10.Size = New System.Drawing.Size(26, 25)
        Me.PictureBox10.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage
        Me.PictureBox10.TabIndex = 2
        Me.PictureBox10.TabStop = False
        '
        'LinkLabel15
        '
        Me.LinkLabel15.ActiveLinkColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(151, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.LinkLabel15.AutoEllipsis = True
        Me.LinkLabel15.Cursor = System.Windows.Forms.Cursors.Arrow
        Me.LinkLabel15.Dock = System.Windows.Forms.DockStyle.Fill
        Me.LinkLabel15.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline
        Me.LinkLabel15.LinkColor = System.Drawing.Color.White
        Me.LinkLabel15.Location = New System.Drawing.Point(35, 0)
        Me.LinkLabel15.Name = "LinkLabel15"
        Me.LinkLabel15.Size = New System.Drawing.Size(245, 31)
        Me.LinkLabel15.TabIndex = 0
        Me.LinkLabel15.TabStop = True
        Me.LinkLabel15.Text = "View project properties"
        Me.LinkLabel15.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'PictureBox9
        '
        Me.PictureBox9.Dock = System.Windows.Forms.DockStyle.Fill
        Me.PictureBox9.Image = Global.DISMTools.My.Resources.Resources.info_glyph_dark
        Me.PictureBox9.Location = New System.Drawing.Point(3, 3)
        Me.PictureBox9.Name = "PictureBox9"
        Me.PictureBox9.Size = New System.Drawing.Size(26, 25)
        Me.PictureBox9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage
        Me.PictureBox9.TabIndex = 1
        Me.PictureBox9.TabStop = False
        '
        'Button21
        '
        Me.Button21.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button21.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.Button21.Location = New System.Drawing.Point(40, 481)
        Me.Button21.Name = "Button21"
        Me.Button21.Size = New System.Drawing.Size(221, 28)
        Me.Button21.TabIndex = 10
        Me.Button21.Text = "Unload project"
        Me.Button21.UseVisualStyleBackColor = True
        Me.Button21.Visible = False
        '
        'Button22
        '
        Me.Button22.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button22.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.Button22.Location = New System.Drawing.Point(40, 447)
        Me.Button22.Name = "Button22"
        Me.Button22.Size = New System.Drawing.Size(221, 28)
        Me.Button22.TabIndex = 11
        Me.Button22.Text = "View in File Explorer"
        Me.Button22.UseVisualStyleBackColor = True
        Me.Button22.Visible = False
        '
        'Button23
        '
        Me.Button23.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button23.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.Button23.Location = New System.Drawing.Point(40, 413)
        Me.Button23.Name = "Button23"
        Me.Button23.Size = New System.Drawing.Size(221, 28)
        Me.Button23.TabIndex = 12
        Me.Button23.Text = "View project properties"
        Me.Button23.UseVisualStyleBackColor = True
        Me.Button23.Visible = False
        '
        'TableLayoutPanel6
        '
        Me.TableLayoutPanel6.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TableLayoutPanel6.ColumnCount = 2
        Me.TableLayoutPanel6.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 44.4444389!))
        Me.TableLayoutPanel6.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 55.5555611!))
        Me.TableLayoutPanel6.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 163.0!))
        Me.TableLayoutPanel6.Controls.Add(Me.LinkLabel14, 1, 3)
        Me.TableLayoutPanel6.Controls.Add(Me.Label50, 1, 2)
        Me.TableLayoutPanel6.Controls.Add(Me.Label51, 0, 1)
        Me.TableLayoutPanel6.Controls.Add(Me.Label52, 1, 1)
        Me.TableLayoutPanel6.Controls.Add(Me.Label53, 0, 2)
        Me.TableLayoutPanel6.Controls.Add(Me.Panel13, 0, 0)
        Me.TableLayoutPanel6.Controls.Add(Me.Label49, 1, 0)
        Me.TableLayoutPanel6.Location = New System.Drawing.Point(4, 4)
        Me.TableLayoutPanel6.Name = "TableLayoutPanel6"
        Me.TableLayoutPanel6.RowCount = 4
        Me.TableLayoutPanel6.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 29.0!))
        Me.TableLayoutPanel6.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 102.0!))
        Me.TableLayoutPanel6.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 15.0!))
        Me.TableLayoutPanel6.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 8.0!))
        Me.TableLayoutPanel6.Size = New System.Drawing.Size(292, 369)
        Me.TableLayoutPanel6.TabIndex = 9
        '
        'LinkLabel14
        '
        Me.LinkLabel14.Dock = System.Windows.Forms.DockStyle.Fill
        Me.LinkLabel14.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline
        Me.LinkLabel14.LinkColor = System.Drawing.Color.DodgerBlue
        Me.LinkLabel14.Location = New System.Drawing.Point(132, 146)
        Me.LinkLabel14.Name = "LinkLabel14"
        Me.LinkLabel14.Size = New System.Drawing.Size(157, 223)
        Me.LinkLabel14.TabIndex = 5
        Me.LinkLabel14.TabStop = True
        Me.LinkLabel14.Text = "Click here to mount an image"
        '
        'Label50
        '
        Me.Label50.AutoEllipsis = True
        Me.Label50.AutoSize = True
        Me.Label50.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Label50.Location = New System.Drawing.Point(132, 131)
        Me.Label50.Name = "Label50"
        Me.Label50.Size = New System.Drawing.Size(157, 15)
        Me.Label50.TabIndex = 2
        Me.Label50.Text = "imgStatus"
        '
        'Label51
        '
        Me.Label51.AutoSize = True
        Me.Label51.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Label51.Location = New System.Drawing.Point(3, 29)
        Me.Label51.Name = "Label51"
        Me.Label51.Size = New System.Drawing.Size(123, 102)
        Me.Label51.TabIndex = 1
        Me.Label51.Text = "Location:"
        Me.Label51.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label52
        '
        Me.Label52.AutoEllipsis = True
        Me.Label52.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Label52.Location = New System.Drawing.Point(132, 29)
        Me.Label52.Name = "Label52"
        Me.Label52.Size = New System.Drawing.Size(157, 102)
        Me.Label52.TabIndex = 2
        Me.Label52.Text = "projPath"
        '
        'Label53
        '
        Me.Label53.AutoSize = True
        Me.Label53.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Label53.Location = New System.Drawing.Point(3, 131)
        Me.Label53.Name = "Label53"
        Me.TableLayoutPanel6.SetRowSpan(Me.Label53, 2)
        Me.Label53.Size = New System.Drawing.Size(123, 238)
        Me.Label53.TabIndex = 1
        Me.Label53.Text = "Images mounted?"
        Me.Label53.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Panel13
        '
        Me.Panel13.Controls.Add(Me.Label54)
        Me.Panel13.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel13.Location = New System.Drawing.Point(3, 3)
        Me.Panel13.Name = "Panel13"
        Me.Panel13.Size = New System.Drawing.Size(123, 23)
        Me.Panel13.TabIndex = 9
        '
        'Label54
        '
        Me.Label54.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Label54.Location = New System.Drawing.Point(0, 0)
        Me.Label54.Name = "Label54"
        Me.Label54.Size = New System.Drawing.Size(123, 23)
        Me.Label54.TabIndex = 1
        Me.Label54.Text = "Name:"
        Me.Label54.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label49
        '
        Me.Label49.AutoEllipsis = True
        Me.Label49.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Label49.Location = New System.Drawing.Point(132, 0)
        Me.Label49.Name = "Label49"
        Me.Label49.Size = New System.Drawing.Size(157, 29)
        Me.Label49.TabIndex = 2
        Me.Label49.Text = "Label49"
        Me.Label49.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'SidePanel_ImageView
        '
        Me.SidePanel_ImageView.Controls.Add(Me.ImageView_NoImage)
        Me.SidePanel_ImageView.Controls.Add(Me.ImageView_BasicInfo)
        Me.SidePanel_ImageView.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SidePanel_ImageView.Location = New System.Drawing.Point(0, 0)
        Me.SidePanel_ImageView.Name = "SidePanel_ImageView"
        Me.SidePanel_ImageView.Size = New System.Drawing.Size(300, 522)
        Me.SidePanel_ImageView.TabIndex = 1
        Me.SidePanel_ImageView.Visible = False
        '
        'ImageView_NoImage
        '
        Me.ImageView_NoImage.Controls.Add(Me.Label59)
        Me.ImageView_NoImage.Controls.Add(Me.Label58)
        Me.ImageView_NoImage.Controls.Add(Me.Label57)
        Me.ImageView_NoImage.Controls.Add(Me.TableLayoutPanel7)
        Me.ImageView_NoImage.Dock = System.Windows.Forms.DockStyle.Fill
        Me.ImageView_NoImage.Location = New System.Drawing.Point(0, 0)
        Me.ImageView_NoImage.Name = "ImageView_NoImage"
        Me.ImageView_NoImage.Size = New System.Drawing.Size(300, 522)
        Me.ImageView_NoImage.TabIndex = 0
        '
        'Label59
        '
        Me.Label59.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label59.AutoEllipsis = True
        Me.Label59.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label59.Location = New System.Drawing.Point(7, 164)
        Me.Label59.Name = "Label59"
        Me.Label59.Size = New System.Drawing.Size(285, 32)
        Me.Label59.TabIndex = 19
        Me.Label59.Text = "No image has been mounted"
        Me.Label59.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label58
        '
        Me.Label58.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label58.AutoEllipsis = True
        Me.Label58.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label58.Location = New System.Drawing.Point(7, 201)
        Me.Label58.Name = "Label58"
        Me.Label58.Size = New System.Drawing.Size(285, 71)
        Me.Label58.TabIndex = 19
        Me.Label58.Text = "You need to mount an image in order to view its information."
        Me.Label58.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'Label57
        '
        Me.Label57.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Label57.AutoSize = True
        Me.Label57.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label57.Location = New System.Drawing.Point(11, 418)
        Me.Label57.Name = "Label57"
        Me.Label57.Size = New System.Drawing.Size(49, 15)
        Me.Label57.TabIndex = 18
        Me.Label57.Text = "Choices"
        '
        'TableLayoutPanel7
        '
        Me.TableLayoutPanel7.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.TableLayoutPanel7.ColumnCount = 2
        Me.TableLayoutPanel7.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 32.0!))
        Me.TableLayoutPanel7.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel7.Controls.Add(Me.LinkLabel18, 1, 1)
        Me.TableLayoutPanel7.Controls.Add(Me.PictureBox12, 0, 1)
        Me.TableLayoutPanel7.Controls.Add(Me.LinkLabel21, 1, 0)
        Me.TableLayoutPanel7.Controls.Add(Me.PictureBox15, 0, 0)
        Me.TableLayoutPanel7.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TableLayoutPanel7.Location = New System.Drawing.Point(9, 440)
        Me.TableLayoutPanel7.Name = "TableLayoutPanel7"
        Me.TableLayoutPanel7.RowCount = 2
        Me.TableLayoutPanel7.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel7.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel7.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        Me.TableLayoutPanel7.Size = New System.Drawing.Size(283, 64)
        Me.TableLayoutPanel7.TabIndex = 17
        '
        'LinkLabel18
        '
        Me.LinkLabel18.ActiveLinkColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(151, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.LinkLabel18.AutoEllipsis = True
        Me.LinkLabel18.Cursor = System.Windows.Forms.Cursors.Arrow
        Me.LinkLabel18.Dock = System.Windows.Forms.DockStyle.Fill
        Me.LinkLabel18.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline
        Me.LinkLabel18.LinkColor = System.Drawing.Color.White
        Me.LinkLabel18.Location = New System.Drawing.Point(35, 32)
        Me.LinkLabel18.Name = "LinkLabel18"
        Me.LinkLabel18.Size = New System.Drawing.Size(245, 32)
        Me.LinkLabel18.TabIndex = 3
        Me.LinkLabel18.TabStop = True
        Me.LinkLabel18.Text = "Pick a mounted image..."
        Me.LinkLabel18.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'PictureBox12
        '
        Me.PictureBox12.Dock = System.Windows.Forms.DockStyle.Fill
        Me.PictureBox12.Location = New System.Drawing.Point(3, 35)
        Me.PictureBox12.Name = "PictureBox12"
        Me.PictureBox12.Size = New System.Drawing.Size(26, 26)
        Me.PictureBox12.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage
        Me.PictureBox12.TabIndex = 2
        Me.PictureBox12.TabStop = False
        '
        'LinkLabel21
        '
        Me.LinkLabel21.ActiveLinkColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(151, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.LinkLabel21.AutoEllipsis = True
        Me.LinkLabel21.Cursor = System.Windows.Forms.Cursors.Arrow
        Me.LinkLabel21.Dock = System.Windows.Forms.DockStyle.Fill
        Me.LinkLabel21.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline
        Me.LinkLabel21.LinkColor = System.Drawing.Color.White
        Me.LinkLabel21.Location = New System.Drawing.Point(35, 0)
        Me.LinkLabel21.Name = "LinkLabel21"
        Me.LinkLabel21.Size = New System.Drawing.Size(245, 32)
        Me.LinkLabel21.TabIndex = 0
        Me.LinkLabel21.TabStop = True
        Me.LinkLabel21.Text = "Mount an image..."
        Me.LinkLabel21.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'PictureBox15
        '
        Me.PictureBox15.Dock = System.Windows.Forms.DockStyle.Fill
        Me.PictureBox15.Image = Global.DISMTools.My.Resources.Resources.openfile_dark
        Me.PictureBox15.Location = New System.Drawing.Point(3, 3)
        Me.PictureBox15.Name = "PictureBox15"
        Me.PictureBox15.Size = New System.Drawing.Size(26, 26)
        Me.PictureBox15.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage
        Me.PictureBox15.TabIndex = 1
        Me.PictureBox15.TabStop = False
        '
        'ImageView_BasicInfo
        '
        Me.ImageView_BasicInfo.Controls.Add(Me.Label56)
        Me.ImageView_BasicInfo.Controls.Add(Me.ImgTasks)
        Me.ImageView_BasicInfo.Controls.Add(Me.TableLayoutPanel5)
        Me.ImageView_BasicInfo.Dock = System.Windows.Forms.DockStyle.Fill
        Me.ImageView_BasicInfo.Location = New System.Drawing.Point(0, 0)
        Me.ImageView_BasicInfo.Name = "ImageView_BasicInfo"
        Me.ImageView_BasicInfo.Size = New System.Drawing.Size(300, 522)
        Me.ImageView_BasicInfo.TabIndex = 1
        '
        'Label56
        '
        Me.Label56.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Label56.AutoSize = True
        Me.Label56.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label56.Location = New System.Drawing.Point(11, 417)
        Me.Label56.Name = "Label56"
        Me.Label56.Size = New System.Drawing.Size(74, 15)
        Me.Label56.TabIndex = 15
        Me.Label56.Text = "Image Tasks"
        '
        'ImgTasks
        '
        Me.ImgTasks.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.ImgTasks.ColumnCount = 2
        Me.ImgTasks.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 32.0!))
        Me.ImgTasks.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.ImgTasks.Controls.Add(Me.LinkLabel19, 1, 1)
        Me.ImgTasks.Controls.Add(Me.PictureBox13, 0, 1)
        Me.ImgTasks.Controls.Add(Me.LinkLabel20, 1, 0)
        Me.ImgTasks.Controls.Add(Me.PictureBox14, 0, 0)
        Me.ImgTasks.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ImgTasks.Location = New System.Drawing.Point(10, 440)
        Me.ImgTasks.Name = "ImgTasks"
        Me.ImgTasks.RowCount = 2
        Me.ImgTasks.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.ImgTasks.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.ImgTasks.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        Me.ImgTasks.Size = New System.Drawing.Size(283, 64)
        Me.ImgTasks.TabIndex = 16
        '
        'LinkLabel19
        '
        Me.LinkLabel19.ActiveLinkColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(151, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.LinkLabel19.AutoEllipsis = True
        Me.LinkLabel19.Cursor = System.Windows.Forms.Cursors.Arrow
        Me.LinkLabel19.Dock = System.Windows.Forms.DockStyle.Fill
        Me.LinkLabel19.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline
        Me.LinkLabel19.LinkColor = System.Drawing.Color.White
        Me.LinkLabel19.Location = New System.Drawing.Point(35, 32)
        Me.LinkLabel19.Name = "LinkLabel19"
        Me.LinkLabel19.Size = New System.Drawing.Size(245, 32)
        Me.LinkLabel19.TabIndex = 3
        Me.LinkLabel19.TabStop = True
        Me.LinkLabel19.Text = "Unmount image"
        Me.LinkLabel19.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'PictureBox13
        '
        Me.PictureBox13.Dock = System.Windows.Forms.DockStyle.Fill
        Me.PictureBox13.Location = New System.Drawing.Point(3, 35)
        Me.PictureBox13.Name = "PictureBox13"
        Me.PictureBox13.Size = New System.Drawing.Size(26, 26)
        Me.PictureBox13.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage
        Me.PictureBox13.TabIndex = 2
        Me.PictureBox13.TabStop = False
        '
        'LinkLabel20
        '
        Me.LinkLabel20.ActiveLinkColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(151, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.LinkLabel20.AutoEllipsis = True
        Me.LinkLabel20.Cursor = System.Windows.Forms.Cursors.Arrow
        Me.LinkLabel20.Dock = System.Windows.Forms.DockStyle.Fill
        Me.LinkLabel20.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline
        Me.LinkLabel20.LinkColor = System.Drawing.Color.White
        Me.LinkLabel20.Location = New System.Drawing.Point(35, 0)
        Me.LinkLabel20.Name = "LinkLabel20"
        Me.LinkLabel20.Size = New System.Drawing.Size(245, 32)
        Me.LinkLabel20.TabIndex = 0
        Me.LinkLabel20.TabStop = True
        Me.LinkLabel20.Text = "View image properties"
        Me.LinkLabel20.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'PictureBox14
        '
        Me.PictureBox14.Dock = System.Windows.Forms.DockStyle.Fill
        Me.PictureBox14.Image = Global.DISMTools.My.Resources.Resources.info_glyph_dark
        Me.PictureBox14.Location = New System.Drawing.Point(3, 3)
        Me.PictureBox14.Name = "PictureBox14"
        Me.PictureBox14.Size = New System.Drawing.Size(26, 26)
        Me.PictureBox14.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage
        Me.PictureBox14.TabIndex = 1
        Me.PictureBox14.TabStop = False
        '
        'TableLayoutPanel5
        '
        Me.TableLayoutPanel5.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TableLayoutPanel5.ColumnCount = 2
        Me.TableLayoutPanel5.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 39.2000008!))
        Me.TableLayoutPanel5.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 60.7999992!))
        Me.TableLayoutPanel5.Controls.Add(Me.Label39, 0, 0)
        Me.TableLayoutPanel5.Controls.Add(Me.Label40, 0, 4)
        Me.TableLayoutPanel5.Controls.Add(Me.Label41, 1, 0)
        Me.TableLayoutPanel5.Controls.Add(Me.Label42, 0, 3)
        Me.TableLayoutPanel5.Controls.Add(Me.Label43, 0, 1)
        Me.TableLayoutPanel5.Controls.Add(Me.Label44, 1, 1)
        Me.TableLayoutPanel5.Controls.Add(Me.Label45, 0, 2)
        Me.TableLayoutPanel5.Controls.Add(Me.Label46, 1, 3)
        Me.TableLayoutPanel5.Controls.Add(Me.Label47, 1, 4)
        Me.TableLayoutPanel5.Controls.Add(Me.Label48, 1, 2)
        Me.TableLayoutPanel5.Location = New System.Drawing.Point(7, 4)
        Me.TableLayoutPanel5.Name = "TableLayoutPanel5"
        Me.TableLayoutPanel5.RowCount = 5
        Me.TableLayoutPanel5.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 23.0!))
        Me.TableLayoutPanel5.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 74.0!))
        Me.TableLayoutPanel5.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        Me.TableLayoutPanel5.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 84.0!))
        Me.TableLayoutPanel5.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 121.0!))
        Me.TableLayoutPanel5.Size = New System.Drawing.Size(286, 379)
        Me.TableLayoutPanel5.TabIndex = 10
        '
        'Label39
        '
        Me.Label39.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Label39.Location = New System.Drawing.Point(3, 0)
        Me.Label39.Name = "Label39"
        Me.Label39.Size = New System.Drawing.Size(106, 23)
        Me.Label39.TabIndex = 4
        Me.Label39.Text = "Image index:"
        Me.Label39.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label40
        '
        Me.Label40.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Label40.Location = New System.Drawing.Point(3, 201)
        Me.Label40.Name = "Label40"
        Me.Label40.Size = New System.Drawing.Size(106, 178)
        Me.Label40.TabIndex = 3
        Me.Label40.Text = "Description:"
        Me.Label40.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label41
        '
        Me.Label41.AutoEllipsis = True
        Me.Label41.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Label41.Location = New System.Drawing.Point(115, 0)
        Me.Label41.Name = "Label41"
        Me.Label41.Size = New System.Drawing.Size(168, 23)
        Me.Label41.TabIndex = 6
        Me.Label41.Text = "imgIndex"
        Me.Label41.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label42
        '
        Me.Label42.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Label42.Location = New System.Drawing.Point(3, 117)
        Me.Label42.Name = "Label42"
        Me.Label42.Size = New System.Drawing.Size(106, 84)
        Me.Label42.TabIndex = 3
        Me.Label42.Text = "Name:"
        Me.Label42.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label43
        '
        Me.Label43.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Label43.Location = New System.Drawing.Point(3, 23)
        Me.Label43.Name = "Label43"
        Me.Label43.Size = New System.Drawing.Size(106, 74)
        Me.Label43.TabIndex = 3
        Me.Label43.Text = "Mount point:"
        Me.Label43.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label44
        '
        Me.Label44.AutoEllipsis = True
        Me.Label44.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Label44.Location = New System.Drawing.Point(115, 23)
        Me.Label44.Name = "Label44"
        Me.Label44.Size = New System.Drawing.Size(168, 74)
        Me.Label44.TabIndex = 5
        Me.Label44.Text = "mountPoint"
        '
        'Label45
        '
        Me.Label45.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Label45.Location = New System.Drawing.Point(3, 97)
        Me.Label45.Name = "Label45"
        Me.Label45.Size = New System.Drawing.Size(106, 20)
        Me.Label45.TabIndex = 3
        Me.Label45.Text = "Version:"
        Me.Label45.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label46
        '
        Me.Label46.AutoEllipsis = True
        Me.Label46.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Label46.Location = New System.Drawing.Point(115, 117)
        Me.Label46.Name = "Label46"
        Me.Label46.Size = New System.Drawing.Size(168, 84)
        Me.Label46.TabIndex = 6
        Me.Label46.Text = "imgName"
        Me.Label46.UseMnemonic = False
        '
        'Label47
        '
        Me.Label47.AutoEllipsis = True
        Me.Label47.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Label47.Location = New System.Drawing.Point(115, 201)
        Me.Label47.Name = "Label47"
        Me.Label47.Size = New System.Drawing.Size(168, 178)
        Me.Label47.TabIndex = 6
        Me.Label47.Text = "imgDesc"
        Me.Label47.UseMnemonic = False
        '
        'Label48
        '
        Me.Label48.AutoEllipsis = True
        Me.Label48.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Label48.Location = New System.Drawing.Point(115, 97)
        Me.Label48.Name = "Label48"
        Me.Label48.Size = New System.Drawing.Size(168, 20)
        Me.Label48.TabIndex = 6
        Me.Label48.Text = "imgVersion"
        Me.Label48.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Panel10
        '
        Me.Panel10.Controls.Add(Me.TableLayoutPanel4)
        Me.Panel10.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel10.Location = New System.Drawing.Point(0, 0)
        Me.Panel10.Name = "Panel10"
        Me.Panel10.Size = New System.Drawing.Size(300, 36)
        Me.Panel10.TabIndex = 0
        '
        'TableLayoutPanel4
        '
        Me.TableLayoutPanel4.ColumnCount = 2
        Me.TableLayoutPanel4.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel4.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel4.Controls.Add(Me.LinkLabel12, 0, 0)
        Me.TableLayoutPanel4.Controls.Add(Me.LinkLabel13, 1, 0)
        Me.TableLayoutPanel4.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel4.Location = New System.Drawing.Point(0, 0)
        Me.TableLayoutPanel4.Name = "TableLayoutPanel4"
        Me.TableLayoutPanel4.RowCount = 1
        Me.TableLayoutPanel4.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel4.Size = New System.Drawing.Size(300, 36)
        Me.TableLayoutPanel4.TabIndex = 0
        '
        'LinkLabel12
        '
        Me.LinkLabel12.ActiveLinkColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(123, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.LinkLabel12.AutoSize = True
        Me.LinkLabel12.Dock = System.Windows.Forms.DockStyle.Fill
        Me.LinkLabel12.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LinkLabel12.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline
        Me.LinkLabel12.LinkColor = System.Drawing.Color.White
        Me.LinkLabel12.Location = New System.Drawing.Point(3, 0)
        Me.LinkLabel12.Name = "LinkLabel12"
        Me.LinkLabel12.Size = New System.Drawing.Size(144, 36)
        Me.LinkLabel12.TabIndex = 3
        Me.LinkLabel12.TabStop = True
        Me.LinkLabel12.Text = "PROJECT"
        Me.LinkLabel12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'LinkLabel13
        '
        Me.LinkLabel13.ActiveLinkColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(123, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.LinkLabel13.AutoSize = True
        Me.LinkLabel13.Dock = System.Windows.Forms.DockStyle.Fill
        Me.LinkLabel13.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LinkLabel13.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline
        Me.LinkLabel13.LinkColor = System.Drawing.Color.White
        Me.LinkLabel13.Location = New System.Drawing.Point(153, 0)
        Me.LinkLabel13.Name = "LinkLabel13"
        Me.LinkLabel13.Size = New System.Drawing.Size(144, 36)
        Me.LinkLabel13.TabIndex = 2
        Me.LinkLabel13.TabStop = True
        Me.LinkLabel13.Text = "IMAGE"
        Me.LinkLabel13.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'ProjectViewHeader
        '
        Me.ProjectViewHeader.BackColor = System.Drawing.Color.FromArgb(CType(CType(4, Byte), Integer), CType(CType(17, Byte), Integer), CType(CType(51, Byte), Integer))
        Me.ProjectViewHeader.Controls.Add(Me.TimeLabel)
        Me.ProjectViewHeader.Controls.Add(Me.GreetingLabel)
        Me.ProjectViewHeader.Dock = System.Windows.Forms.DockStyle.Top
        Me.ProjectViewHeader.ForeColor = System.Drawing.Color.White
        Me.ProjectViewHeader.Location = New System.Drawing.Point(0, 0)
        Me.ProjectViewHeader.Name = "ProjectViewHeader"
        Me.ProjectViewHeader.Size = New System.Drawing.Size(1008, 48)
        Me.ProjectViewHeader.TabIndex = 0
        '
        'TimeLabel
        '
        Me.TimeLabel.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TimeLabel.AutoEllipsis = True
        Me.TimeLabel.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TimeLabel.Location = New System.Drawing.Point(658, 11)
        Me.TimeLabel.Name = "TimeLabel"
        Me.TimeLabel.Size = New System.Drawing.Size(340, 27)
        Me.TimeLabel.TabIndex = 1
        Me.TimeLabel.Text = "Label40"
        Me.TimeLabel.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'GreetingLabel
        '
        Me.GreetingLabel.AutoSize = True
        Me.GreetingLabel.Font = New System.Drawing.Font("Segoe UI", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GreetingLabel.Location = New System.Drawing.Point(8, 8)
        Me.GreetingLabel.Name = "GreetingLabel"
        Me.GreetingLabel.Size = New System.Drawing.Size(323, 30)
        Me.GreetingLabel.TabIndex = 0
        Me.GreetingLabel.Text = "Welcome to this servicing session"
        '
        'SplitPanels
        '
        Me.SplitPanels.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SplitPanels.FixedPanel = System.Windows.Forms.FixedPanel.Panel1
        Me.SplitPanels.Location = New System.Drawing.Point(0, 25)
        Me.SplitPanels.Name = "SplitPanels"
        '
        'SplitPanels.Panel1
        '
        Me.SplitPanels.Panel1.Controls.Add(Me.TabControl1)
        Me.SplitPanels.Panel1MinSize = 300
        '
        'SplitPanels.Panel2
        '
        Me.SplitPanels.Panel2.Controls.Add(Me.TabControl2)
        Me.SplitPanels.Panel2MinSize = 384
        Me.SplitPanels.Size = New System.Drawing.Size(1008, 606)
        Me.SplitPanels.SplitterDistance = 300
        Me.SplitPanels.SplitterWidth = 2
        Me.SplitPanels.TabIndex = 1
        Me.SplitPanels.Visible = False
        '
        'TabControl1
        '
        Me.TabControl1.Controls.Add(Me.TabPage1)
        Me.TabControl1.Controls.Add(Me.TabPage2)
        Me.TabControl1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TabControl1.Location = New System.Drawing.Point(0, 0)
        Me.TabControl1.Multiline = True
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(300, 606)
        Me.TabControl1.TabIndex = 0
        '
        'TabPage1
        '
        Me.TabPage1.Controls.Add(Me.UnloadBtn)
        Me.TabPage1.Controls.Add(Me.ExplorerView)
        Me.TabPage1.Controls.Add(Me.Button14)
        Me.TabPage1.Controls.Add(Me.TabTitleSummary1)
        Me.TabPage1.Controls.Add(Me.TableLayoutPanel2)
        Me.TabPage1.Location = New System.Drawing.Point(4, 22)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage1.Size = New System.Drawing.Size(292, 580)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "Project"
        Me.TabPage1.UseVisualStyleBackColor = True
        '
        'UnloadBtn
        '
        Me.UnloadBtn.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.UnloadBtn.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.UnloadBtn.Location = New System.Drawing.Point(36, 538)
        Me.UnloadBtn.Name = "UnloadBtn"
        Me.UnloadBtn.Size = New System.Drawing.Size(221, 28)
        Me.UnloadBtn.TabIndex = 1
        Me.UnloadBtn.Text = "Unload project"
        Me.UnloadBtn.UseVisualStyleBackColor = True
        '
        'ExplorerView
        '
        Me.ExplorerView.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.ExplorerView.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.ExplorerView.Location = New System.Drawing.Point(36, 504)
        Me.ExplorerView.Name = "ExplorerView"
        Me.ExplorerView.Size = New System.Drawing.Size(221, 28)
        Me.ExplorerView.TabIndex = 1
        Me.ExplorerView.Text = "View in File Explorer"
        Me.ExplorerView.UseVisualStyleBackColor = True
        '
        'Button14
        '
        Me.Button14.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button14.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.Button14.Location = New System.Drawing.Point(36, 470)
        Me.Button14.Name = "Button14"
        Me.Button14.Size = New System.Drawing.Size(221, 28)
        Me.Button14.TabIndex = 1
        Me.Button14.Text = "View project properties"
        Me.Button14.UseVisualStyleBackColor = True
        '
        'TabTitleSummary1
        '
        Me.TabTitleSummary1.Controls.Add(Me.TabPageIcon1)
        Me.TabTitleSummary1.Controls.Add(Me.TabPageDescription1)
        Me.TabTitleSummary1.Controls.Add(Me.TabPageTitle1)
        Me.TabTitleSummary1.Dock = System.Windows.Forms.DockStyle.Top
        Me.TabTitleSummary1.Location = New System.Drawing.Point(3, 3)
        Me.TabTitleSummary1.Name = "TabTitleSummary1"
        Me.TabTitleSummary1.Size = New System.Drawing.Size(286, 64)
        Me.TabTitleSummary1.TabIndex = 0
        '
        'TabPageIcon1
        '
        Me.TabPageIcon1.Image = CType(resources.GetObject("TabPageIcon1.Image"), System.Drawing.Image)
        Me.TabPageIcon1.Location = New System.Drawing.Point(8, 8)
        Me.TabPageIcon1.Name = "TabPageIcon1"
        Me.TabPageIcon1.Size = New System.Drawing.Size(48, 48)
        Me.TabPageIcon1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.TabPageIcon1.TabIndex = 1
        Me.TabPageIcon1.TabStop = False
        '
        'TabPageDescription1
        '
        Me.TabPageDescription1.AutoSize = True
        Me.TabPageDescription1.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TabPageDescription1.Location = New System.Drawing.Point(63, 37)
        Me.TabPageDescription1.Name = "TabPageDescription1"
        Me.TabPageDescription1.Size = New System.Drawing.Size(123, 13)
        Me.TabPageDescription1.TabIndex = 0
        Me.TabPageDescription1.Text = "View project information"
        '
        'TabPageTitle1
        '
        Me.TabPageTitle1.AutoSize = True
        Me.TabPageTitle1.Font = New System.Drawing.Font("Tahoma", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TabPageTitle1.Location = New System.Drawing.Point(62, 14)
        Me.TabPageTitle1.Name = "TabPageTitle1"
        Me.TabPageTitle1.Size = New System.Drawing.Size(67, 23)
        Me.TabPageTitle1.TabIndex = 0
        Me.TabPageTitle1.Text = "Project"
        '
        'TableLayoutPanel2
        '
        Me.TableLayoutPanel2.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TableLayoutPanel2.ColumnCount = 3
        Me.TableLayoutPanel2.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 32.4200897!))
        Me.TableLayoutPanel2.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 67.5799103!))
        Me.TableLayoutPanel2.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 140.0!))
        Me.TableLayoutPanel2.Controls.Add(Me.ProjNameEditBtn, 2, 0)
        Me.TableLayoutPanel2.Controls.Add(Me.LinkLabel1, 1, 3)
        Me.TableLayoutPanel2.Controls.Add(Me.Panel8, 1, 0)
        Me.TableLayoutPanel2.Controls.Add(Me.Label5, 1, 2)
        Me.TableLayoutPanel2.Controls.Add(Me.Label2, 0, 1)
        Me.TableLayoutPanel2.Controls.Add(Me.Label3, 1, 1)
        Me.TableLayoutPanel2.Controls.Add(Me.Label4, 0, 2)
        Me.TableLayoutPanel2.Controls.Add(Me.Panel9, 0, 0)
        Me.TableLayoutPanel2.Location = New System.Drawing.Point(0, 64)
        Me.TableLayoutPanel2.Name = "TableLayoutPanel2"
        Me.TableLayoutPanel2.RowCount = 4
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 29.0!))
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 102.0!))
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 15.0!))
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 8.0!))
        Me.TableLayoutPanel2.Size = New System.Drawing.Size(292, 400)
        Me.TableLayoutPanel2.TabIndex = 8
        '
        'ProjNameEditBtn
        '
        Me.ProjNameEditBtn.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.ProjNameEditBtn.Image = CType(resources.GetObject("ProjNameEditBtn.Image"), System.Drawing.Image)
        Me.ProjNameEditBtn.Location = New System.Drawing.Point(265, 3)
        Me.ProjNameEditBtn.Name = "ProjNameEditBtn"
        Me.ProjNameEditBtn.Size = New System.Drawing.Size(24, 23)
        Me.ProjNameEditBtn.TabIndex = 7
        Me.ProjNameEditBtn.UseVisualStyleBackColor = True
        '
        'LinkLabel1
        '
        Me.TableLayoutPanel2.SetColumnSpan(Me.LinkLabel1, 2)
        Me.LinkLabel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.LinkLabel1.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline
        Me.LinkLabel1.LinkColor = System.Drawing.Color.DodgerBlue
        Me.LinkLabel1.Location = New System.Drawing.Point(52, 146)
        Me.LinkLabel1.Name = "LinkLabel1"
        Me.LinkLabel1.Size = New System.Drawing.Size(237, 254)
        Me.LinkLabel1.TabIndex = 5
        Me.LinkLabel1.TabStop = True
        Me.LinkLabel1.Text = "Click here to mount an image"
        '
        'Panel8
        '
        Me.Panel8.Controls.Add(Me.projName)
        Me.Panel8.Controls.Add(Me.projNameText)
        Me.Panel8.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel8.Location = New System.Drawing.Point(52, 3)
        Me.Panel8.Name = "Panel8"
        Me.Panel8.Size = New System.Drawing.Size(96, 23)
        Me.Panel8.TabIndex = 8
        '
        'projName
        '
        Me.projName.AutoEllipsis = True
        Me.projName.Dock = System.Windows.Forms.DockStyle.Fill
        Me.projName.Location = New System.Drawing.Point(0, 0)
        Me.projName.Name = "projName"
        Me.projName.Size = New System.Drawing.Size(96, 23)
        Me.projName.TabIndex = 2
        Me.projName.Text = "projName"
        Me.projName.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'projNameText
        '
        Me.projNameText.Dock = System.Windows.Forms.DockStyle.Fill
        Me.projNameText.Location = New System.Drawing.Point(0, 0)
        Me.projNameText.Name = "projNameText"
        Me.projNameText.Size = New System.Drawing.Size(96, 21)
        Me.projNameText.TabIndex = 4
        Me.projNameText.Text = "projName"
        Me.projNameText.Visible = False
        '
        'Label5
        '
        Me.Label5.AutoEllipsis = True
        Me.Label5.AutoSize = True
        Me.TableLayoutPanel2.SetColumnSpan(Me.Label5, 2)
        Me.Label5.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Label5.Location = New System.Drawing.Point(52, 131)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(237, 15)
        Me.Label5.TabIndex = 2
        Me.Label5.Text = "imgStatus"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Label2.Location = New System.Drawing.Point(3, 29)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(43, 102)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Location:"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label3
        '
        Me.Label3.AutoEllipsis = True
        Me.TableLayoutPanel2.SetColumnSpan(Me.Label3, 2)
        Me.Label3.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Label3.Location = New System.Drawing.Point(52, 29)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(237, 102)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "projPath"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Label4.Location = New System.Drawing.Point(3, 131)
        Me.Label4.Name = "Label4"
        Me.TableLayoutPanel2.SetRowSpan(Me.Label4, 2)
        Me.Label4.Size = New System.Drawing.Size(43, 269)
        Me.Label4.TabIndex = 1
        Me.Label4.Text = "Images mounted?"
        Me.Label4.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Panel9
        '
        Me.Panel9.Controls.Add(Me.Label1)
        Me.Panel9.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel9.Location = New System.Drawing.Point(3, 3)
        Me.Panel9.Name = "Panel9"
        Me.Panel9.Size = New System.Drawing.Size(43, 23)
        Me.Panel9.TabIndex = 9
        '
        'Label1
        '
        Me.Label1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Label1.Location = New System.Drawing.Point(0, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(43, 23)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "Name:"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'TabPage2
        '
        Me.TabPage2.Controls.Add(Me.ImageNotMountedPanel)
        Me.TabPage2.Controls.Add(Me.ImagePanel)
        Me.TabPage2.Location = New System.Drawing.Point(4, 22)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage2.Size = New System.Drawing.Size(292, 580)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "Image"
        Me.TabPage2.UseVisualStyleBackColor = True
        '
        'ImageNotMountedPanel
        '
        Me.ImageNotMountedPanel.Controls.Add(Me.LinkLabel3)
        Me.ImageNotMountedPanel.Controls.Add(Me.LinkLabel2)
        Me.ImageNotMountedPanel.Controls.Add(Me.Label23)
        Me.ImageNotMountedPanel.Dock = System.Windows.Forms.DockStyle.Fill
        Me.ImageNotMountedPanel.Location = New System.Drawing.Point(3, 3)
        Me.ImageNotMountedPanel.Name = "ImageNotMountedPanel"
        Me.ImageNotMountedPanel.Size = New System.Drawing.Size(286, 574)
        Me.ImageNotMountedPanel.TabIndex = 0
        '
        'LinkLabel3
        '
        Me.LinkLabel3.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.LinkLabel3.LinkArea = New System.Windows.Forms.LinkArea(33, 32)
        Me.LinkLabel3.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline
        Me.LinkLabel3.LinkColor = System.Drawing.Color.DodgerBlue
        Me.LinkLabel3.Location = New System.Drawing.Point(21, 521)
        Me.LinkLabel3.Name = "LinkLabel3"
        Me.LinkLabel3.Size = New System.Drawing.Size(246, 44)
        Me.LinkLabel3.TabIndex = 2
        Me.LinkLabel3.TabStop = True
        Me.LinkLabel3.Text = "Or, if you have a mounted image, open an existing mount directory"
        Me.LinkLabel3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.LinkLabel3.UseCompatibleTextRendering = True
        '
        'LinkLabel2
        '
        Me.LinkLabel2.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.LinkLabel2.ForeColor = System.Drawing.Color.Crimson
        Me.LinkLabel2.LinkArea = New System.Windows.Forms.LinkArea(72, 4)
        Me.LinkLabel2.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline
        Me.LinkLabel2.LinkColor = System.Drawing.Color.DodgerBlue
        Me.LinkLabel2.Location = New System.Drawing.Point(39, 291)
        Me.LinkLabel2.Name = "LinkLabel2"
        Me.LinkLabel2.Size = New System.Drawing.Size(210, 44)
        Me.LinkLabel2.TabIndex = 1
        Me.LinkLabel2.TabStop = True
        Me.LinkLabel2.Text = "You need to mount an image in order to view its information here. Click here to m" & _
    "ount an image."
        Me.LinkLabel2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.LinkLabel2.UseCompatibleTextRendering = True
        '
        'Label23
        '
        Me.Label23.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label23.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label23.ForeColor = System.Drawing.Color.Crimson
        Me.Label23.Location = New System.Drawing.Point(38, 240)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(211, 51)
        Me.Label23.TabIndex = 0
        Me.Label23.Text = "No image has been mounted"
        Me.Label23.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'ImagePanel
        '
        Me.ImagePanel.Controls.Add(Me.Button16)
        Me.ImagePanel.Controls.Add(Me.TabTitleSummary2)
        Me.ImagePanel.Controls.Add(Me.Button15)
        Me.ImagePanel.Controls.Add(Me.TableLayoutPanel1)
        Me.ImagePanel.Dock = System.Windows.Forms.DockStyle.Fill
        Me.ImagePanel.Location = New System.Drawing.Point(3, 3)
        Me.ImagePanel.Name = "ImagePanel"
        Me.ImagePanel.Size = New System.Drawing.Size(286, 574)
        Me.ImagePanel.TabIndex = 9
        '
        'Button16
        '
        Me.Button16.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button16.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.Button16.Location = New System.Drawing.Point(33, 535)
        Me.Button16.Name = "Button16"
        Me.Button16.Size = New System.Drawing.Size(221, 28)
        Me.Button16.TabIndex = 8
        Me.Button16.Text = "Unmount image..."
        Me.Button16.UseVisualStyleBackColor = True
        '
        'TabTitleSummary2
        '
        Me.TabTitleSummary2.Controls.Add(Me.TabPageIcon2)
        Me.TabTitleSummary2.Controls.Add(Me.TabPageDescription2)
        Me.TabTitleSummary2.Controls.Add(Me.TabPageTitle2)
        Me.TabTitleSummary2.Dock = System.Windows.Forms.DockStyle.Top
        Me.TabTitleSummary2.Location = New System.Drawing.Point(0, 0)
        Me.TabTitleSummary2.Name = "TabTitleSummary2"
        Me.TabTitleSummary2.Size = New System.Drawing.Size(286, 64)
        Me.TabTitleSummary2.TabIndex = 1
        '
        'TabPageIcon2
        '
        Me.TabPageIcon2.Image = CType(resources.GetObject("TabPageIcon2.Image"), System.Drawing.Image)
        Me.TabPageIcon2.Location = New System.Drawing.Point(8, 8)
        Me.TabPageIcon2.Name = "TabPageIcon2"
        Me.TabPageIcon2.Size = New System.Drawing.Size(48, 48)
        Me.TabPageIcon2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.TabPageIcon2.TabIndex = 1
        Me.TabPageIcon2.TabStop = False
        '
        'TabPageDescription2
        '
        Me.TabPageDescription2.AutoSize = True
        Me.TabPageDescription2.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TabPageDescription2.Location = New System.Drawing.Point(63, 37)
        Me.TabPageDescription2.Name = "TabPageDescription2"
        Me.TabPageDescription2.Size = New System.Drawing.Size(117, 13)
        Me.TabPageDescription2.TabIndex = 0
        Me.TabPageDescription2.Text = "View image information"
        '
        'TabPageTitle2
        '
        Me.TabPageTitle2.AutoSize = True
        Me.TabPageTitle2.Font = New System.Drawing.Font("Tahoma", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TabPageTitle2.Location = New System.Drawing.Point(62, 14)
        Me.TabPageTitle2.Name = "TabPageTitle2"
        Me.TabPageTitle2.Size = New System.Drawing.Size(64, 23)
        Me.TabPageTitle2.TabIndex = 0
        Me.TabPageTitle2.Text = "Image"
        '
        'Button15
        '
        Me.Button15.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button15.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.Button15.Location = New System.Drawing.Point(33, 504)
        Me.Button15.Name = "Button15"
        Me.Button15.Size = New System.Drawing.Size(221, 28)
        Me.Button15.TabIndex = 8
        Me.Button15.Text = "View image properties"
        Me.Button15.UseVisualStyleBackColor = True
        '
        'TableLayoutPanel1
        '
        Me.TableLayoutPanel1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TableLayoutPanel1.ColumnCount = 2
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 39.2000008!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 60.7999992!))
        Me.TableLayoutPanel1.Controls.Add(Me.Label15, 0, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.Label21, 0, 4)
        Me.TableLayoutPanel1.Controls.Add(Me.Label14, 1, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.Label19, 0, 3)
        Me.TableLayoutPanel1.Controls.Add(Me.Label13, 0, 1)
        Me.TableLayoutPanel1.Controls.Add(Me.Label12, 1, 1)
        Me.TableLayoutPanel1.Controls.Add(Me.Label16, 0, 2)
        Me.TableLayoutPanel1.Controls.Add(Me.Label18, 1, 3)
        Me.TableLayoutPanel1.Controls.Add(Me.Label20, 1, 4)
        Me.TableLayoutPanel1.Controls.Add(Me.Label17, 1, 2)
        Me.TableLayoutPanel1.Location = New System.Drawing.Point(0, 64)
        Me.TableLayoutPanel1.Name = "TableLayoutPanel1"
        Me.TableLayoutPanel1.RowCount = 5
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 23.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 74.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 84.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 121.0!))
        Me.TableLayoutPanel1.Size = New System.Drawing.Size(286, 434)
        Me.TableLayoutPanel1.TabIndex = 9
        '
        'Label15
        '
        Me.Label15.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Label15.Location = New System.Drawing.Point(3, 0)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(106, 23)
        Me.Label15.TabIndex = 4
        Me.Label15.Text = "Image index:"
        Me.Label15.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label21
        '
        Me.Label21.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Label21.Location = New System.Drawing.Point(3, 201)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(106, 233)
        Me.Label21.TabIndex = 3
        Me.Label21.Text = "Description:"
        Me.Label21.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label14
        '
        Me.Label14.AutoEllipsis = True
        Me.Label14.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Label14.Location = New System.Drawing.Point(115, 0)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(168, 23)
        Me.Label14.TabIndex = 6
        Me.Label14.Text = "imgIndex"
        Me.Label14.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label19
        '
        Me.Label19.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Label19.Location = New System.Drawing.Point(3, 117)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(106, 84)
        Me.Label19.TabIndex = 3
        Me.Label19.Text = "Name:"
        Me.Label19.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label13
        '
        Me.Label13.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Label13.Location = New System.Drawing.Point(3, 23)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(106, 74)
        Me.Label13.TabIndex = 3
        Me.Label13.Text = "Mount point:"
        Me.Label13.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label12
        '
        Me.Label12.AutoEllipsis = True
        Me.Label12.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Label12.Location = New System.Drawing.Point(115, 23)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(168, 74)
        Me.Label12.TabIndex = 5
        Me.Label12.Text = "mountPoint"
        '
        'Label16
        '
        Me.Label16.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Label16.Location = New System.Drawing.Point(3, 97)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(106, 20)
        Me.Label16.TabIndex = 3
        Me.Label16.Text = "Version:"
        Me.Label16.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label18
        '
        Me.Label18.AutoEllipsis = True
        Me.Label18.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Label18.Location = New System.Drawing.Point(115, 117)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(168, 84)
        Me.Label18.TabIndex = 6
        Me.Label18.Text = "imgName"
        '
        'Label20
        '
        Me.Label20.AutoEllipsis = True
        Me.Label20.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Label20.Location = New System.Drawing.Point(115, 201)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(168, 233)
        Me.Label20.TabIndex = 6
        Me.Label20.Text = "imgDesc"
        '
        'Label17
        '
        Me.Label17.AutoEllipsis = True
        Me.Label17.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Label17.Location = New System.Drawing.Point(115, 97)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(168, 20)
        Me.Label17.TabIndex = 6
        Me.Label17.Text = "imgVersion"
        Me.Label17.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'TabControl2
        '
        Me.TabControl2.Controls.Add(Me.TabPage3)
        Me.TabControl2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TabControl2.Location = New System.Drawing.Point(0, 0)
        Me.TabControl2.Name = "TabControl2"
        Me.TabControl2.SelectedIndex = 0
        Me.TabControl2.Size = New System.Drawing.Size(706, 606)
        Me.TabControl2.TabIndex = 3
        '
        'TabPage3
        '
        Me.TabPage3.Controls.Add(Me.OldActionPanel)
        Me.TabPage3.Location = New System.Drawing.Point(4, 22)
        Me.TabPage3.Name = "TabPage3"
        Me.TabPage3.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage3.Size = New System.Drawing.Size(698, 580)
        Me.TabPage3.TabIndex = 0
        Me.TabPage3.Text = "Actions"
        Me.TabPage3.UseVisualStyleBackColor = True
        '
        'OldActionPanel
        '
        Me.OldActionPanel.Controls.Add(Me.Button19)
        Me.OldActionPanel.Controls.Add(Me.GroupBox3)
        Me.OldActionPanel.Controls.Add(Me.GroupBox1)
        Me.OldActionPanel.Controls.Add(Me.GroupBox2)
        Me.OldActionPanel.Dock = System.Windows.Forms.DockStyle.Fill
        Me.OldActionPanel.Location = New System.Drawing.Point(3, 3)
        Me.OldActionPanel.Name = "OldActionPanel"
        Me.OldActionPanel.Size = New System.Drawing.Size(692, 574)
        Me.OldActionPanel.TabIndex = 3
        '
        'Button19
        '
        Me.Button19.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button19.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.Button19.Location = New System.Drawing.Point(479, 533)
        Me.Button19.Name = "Button19"
        Me.Button19.Size = New System.Drawing.Size(188, 23)
        Me.Button19.TabIndex = 3
        Me.Button19.Text = "Preview the new design"
        Me.Button19.UseVisualStyleBackColor = True
        Me.Button19.Visible = False
        '
        'GroupBox3
        '
        Me.GroupBox3.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.GroupBox3.Controls.Add(Me.Button8)
        Me.GroupBox3.Controls.Add(Me.Button9)
        Me.GroupBox3.Controls.Add(Me.Button10)
        Me.GroupBox3.Location = New System.Drawing.Point(116, 387)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(460, 92)
        Me.GroupBox3.TabIndex = 2
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Feature operations"
        '
        'Button8
        '
        Me.Button8.Enabled = False
        Me.Button8.Image = CType(resources.GetObject("Button8.Image"), System.Drawing.Image)
        Me.Button8.Location = New System.Drawing.Point(118, 20)
        Me.Button8.Name = "Button8"
        Me.Button8.Size = New System.Drawing.Size(201, 63)
        Me.Button8.TabIndex = 1
        Me.Button8.Text = "Get feature information..."
        Me.Button8.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.Button8.UseVisualStyleBackColor = True
        '
        'Button9
        '
        Me.Button9.Enabled = False
        Me.Button9.Image = CType(resources.GetObject("Button9.Image"), System.Drawing.Image)
        Me.Button9.Location = New System.Drawing.Point(325, 20)
        Me.Button9.Name = "Button9"
        Me.Button9.Size = New System.Drawing.Size(129, 63)
        Me.Button9.TabIndex = 1
        Me.Button9.Text = "Disable feature..."
        Me.Button9.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.Button9.UseVisualStyleBackColor = True
        '
        'Button10
        '
        Me.Button10.Enabled = False
        Me.Button10.Image = CType(resources.GetObject("Button10.Image"), System.Drawing.Image)
        Me.Button10.Location = New System.Drawing.Point(6, 20)
        Me.Button10.Name = "Button10"
        Me.Button10.Size = New System.Drawing.Size(106, 63)
        Me.Button10.TabIndex = 1
        Me.Button10.Text = "Enable feature..."
        Me.Button10.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.Button10.UseVisualStyleBackColor = True
        '
        'GroupBox1
        '
        Me.GroupBox1.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.GroupBox1.Controls.Add(Me.Button13)
        Me.GroupBox1.Controls.Add(Me.Button11)
        Me.GroupBox1.Controls.Add(Me.Button1)
        Me.GroupBox1.Controls.Add(Me.Button2)
        Me.GroupBox1.Controls.Add(Me.Button3)
        Me.GroupBox1.Controls.Add(Me.Button4)
        Me.GroupBox1.Location = New System.Drawing.Point(116, 95)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(460, 159)
        Me.GroupBox1.TabIndex = 2
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Image operations"
        '
        'Button13
        '
        Me.Button13.Enabled = False
        Me.Button13.Image = CType(resources.GetObject("Button13.Image"), System.Drawing.Image)
        Me.Button13.Location = New System.Drawing.Point(233, 89)
        Me.Button13.Name = "Button13"
        Me.Button13.Size = New System.Drawing.Size(221, 63)
        Me.Button13.TabIndex = 1
        Me.Button13.Text = "Switch indexes..."
        Me.Button13.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.Button13.UseVisualStyleBackColor = True
        '
        'Button11
        '
        Me.Button11.Enabled = False
        Me.Button11.Image = CType(resources.GetObject("Button11.Image"), System.Drawing.Image)
        Me.Button11.Location = New System.Drawing.Point(6, 89)
        Me.Button11.Name = "Button11"
        Me.Button11.Size = New System.Drawing.Size(221, 63)
        Me.Button11.TabIndex = 1
        Me.Button11.Text = "Reload servicing session..."
        Me.Button11.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.Button11.UseVisualStyleBackColor = True
        '
        'Button1
        '
        Me.Button1.Image = CType(resources.GetObject("Button1.Image"), System.Drawing.Image)
        Me.Button1.Location = New System.Drawing.Point(6, 20)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(106, 63)
        Me.Button1.TabIndex = 1
        Me.Button1.Text = "Mount image..."
        Me.Button1.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Button2
        '
        Me.Button2.Enabled = False
        Me.Button2.Image = CType(resources.GetObject("Button2.Image"), System.Drawing.Image)
        Me.Button2.Location = New System.Drawing.Point(118, 20)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(145, 63)
        Me.Button2.TabIndex = 1
        Me.Button2.Text = "Commit current changes"
        Me.Button2.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.Button2.UseVisualStyleBackColor = True
        '
        'Button3
        '
        Me.Button3.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button3.Enabled = False
        Me.Button3.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.Button3.Location = New System.Drawing.Point(269, 20)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(185, 28)
        Me.Button3.TabIndex = 1
        Me.Button3.Text = "Commit and unmount image"
        Me.Button3.UseVisualStyleBackColor = True
        '
        'Button4
        '
        Me.Button4.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button4.Enabled = False
        Me.Button4.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.Button4.Location = New System.Drawing.Point(269, 54)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(185, 28)
        Me.Button4.TabIndex = 1
        Me.Button4.Text = "Unmount image discarding changes"
        Me.Button4.UseVisualStyleBackColor = True
        '
        'GroupBox2
        '
        Me.GroupBox2.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.GroupBox2.Controls.Add(Me.Button6)
        Me.GroupBox2.Controls.Add(Me.Button7)
        Me.GroupBox2.Controls.Add(Me.Button5)
        Me.GroupBox2.Controls.Add(Me.Button12)
        Me.GroupBox2.Location = New System.Drawing.Point(116, 260)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(460, 121)
        Me.GroupBox2.TabIndex = 2
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Package operations"
        '
        'Button6
        '
        Me.Button6.Enabled = False
        Me.Button6.Image = CType(resources.GetObject("Button6.Image"), System.Drawing.Image)
        Me.Button6.Location = New System.Drawing.Point(118, 20)
        Me.Button6.Name = "Button6"
        Me.Button6.Size = New System.Drawing.Size(201, 63)
        Me.Button6.TabIndex = 1
        Me.Button6.Text = "Get package information..."
        Me.Button6.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.Button6.UseVisualStyleBackColor = True
        '
        'Button7
        '
        Me.Button7.Enabled = False
        Me.Button7.Image = CType(resources.GetObject("Button7.Image"), System.Drawing.Image)
        Me.Button7.Location = New System.Drawing.Point(325, 20)
        Me.Button7.Name = "Button7"
        Me.Button7.Size = New System.Drawing.Size(129, 63)
        Me.Button7.TabIndex = 1
        Me.Button7.Text = "Remove package..."
        Me.Button7.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.Button7.UseVisualStyleBackColor = True
        '
        'Button5
        '
        Me.Button5.Enabled = False
        Me.Button5.Image = CType(resources.GetObject("Button5.Image"), System.Drawing.Image)
        Me.Button5.Location = New System.Drawing.Point(6, 20)
        Me.Button5.Name = "Button5"
        Me.Button5.Size = New System.Drawing.Size(106, 63)
        Me.Button5.TabIndex = 1
        Me.Button5.Text = "Add package..."
        Me.Button5.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.Button5.UseVisualStyleBackColor = True
        '
        'Button12
        '
        Me.Button12.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button12.Enabled = False
        Me.Button12.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.Button12.Location = New System.Drawing.Point(6, 87)
        Me.Button12.Name = "Button12"
        Me.Button12.Size = New System.Drawing.Size(448, 28)
        Me.Button12.TabIndex = 1
        Me.Button12.Text = "Perform component cleanup and/or repair..."
        Me.Button12.UseVisualStyleBackColor = True
        '
        'ToolStrip1
        '
        Me.ToolStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripButton1, Me.ToolStripButton2, Me.ToolStripSeparator14, Me.ToolStripButton3, Me.ToolStripSeparator15, Me.ToolStripButton4})
        Me.ToolStrip1.Location = New System.Drawing.Point(0, 0)
        Me.ToolStrip1.Name = "ToolStrip1"
        Me.ToolStrip1.Size = New System.Drawing.Size(1008, 25)
        Me.ToolStrip1.TabIndex = 2
        Me.ToolStrip1.Text = "ToolStrip1"
        '
        'ToolStripButton1
        '
        Me.ToolStripButton1.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right
        Me.ToolStripButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ToolStripButton1.Enabled = False
        Me.ToolStripButton1.Image = CType(resources.GetObject("ToolStripButton1.Image"), System.Drawing.Image)
        Me.ToolStripButton1.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripButton1.Name = "ToolStripButton1"
        Me.ToolStripButton1.Size = New System.Drawing.Size(23, 22)
        Me.ToolStripButton1.Text = "Close tab"
        '
        'ToolStripButton2
        '
        Me.ToolStripButton2.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ToolStripButton2.Image = CType(resources.GetObject("ToolStripButton2.Image"), System.Drawing.Image)
        Me.ToolStripButton2.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripButton2.Name = "ToolStripButton2"
        Me.ToolStripButton2.Size = New System.Drawing.Size(23, 22)
        Me.ToolStripButton2.Text = "Save project"
        '
        'ToolStripSeparator14
        '
        Me.ToolStripSeparator14.Name = "ToolStripSeparator14"
        Me.ToolStripSeparator14.Size = New System.Drawing.Size(6, 25)
        '
        'ToolStripButton3
        '
        Me.ToolStripButton3.Image = CType(resources.GetObject("ToolStripButton3.Image"), System.Drawing.Image)
        Me.ToolStripButton3.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripButton3.Name = "ToolStripButton3"
        Me.ToolStripButton3.Size = New System.Drawing.Size(105, 22)
        Me.ToolStripButton3.Text = "Unload project"
        Me.ToolStripButton3.ToolTipText = "Unload project from this program"
        '
        'ToolStripSeparator15
        '
        Me.ToolStripSeparator15.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right
        Me.ToolStripSeparator15.Name = "ToolStripSeparator15"
        Me.ToolStripSeparator15.Size = New System.Drawing.Size(6, 25)
        '
        'ToolStripButton4
        '
        Me.ToolStripButton4.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right
        Me.ToolStripButton4.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ToolStripButton4.Image = CType(resources.GetObject("ToolStripButton4.Image"), System.Drawing.Image)
        Me.ToolStripButton4.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripButton4.Name = "ToolStripButton4"
        Me.ToolStripButton4.Size = New System.Drawing.Size(23, 22)
        Me.ToolStripButton4.Text = "Show progress window"
        Me.ToolStripButton4.Visible = False
        '
        'Panel2
        '
        Me.Panel2.Controls.Add(Me.prjTreeView)
        Me.Panel2.Controls.Add(Me.ToolStrip2)
        Me.Panel2.Controls.Add(Me.prjTreeStatus)
        Me.Panel2.Dock = System.Windows.Forms.DockStyle.Right
        Me.Panel2.Location = New System.Drawing.Point(1008, 0)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(256, 631)
        Me.Panel2.TabIndex = 1
        '
        'prjTreeView
        '
        Me.prjTreeView.Dock = System.Windows.Forms.DockStyle.Fill
        Me.prjTreeView.Location = New System.Drawing.Point(0, 25)
        Me.prjTreeView.Name = "prjTreeView"
        Me.prjTreeView.Size = New System.Drawing.Size(256, 606)
        Me.prjTreeView.TabIndex = 3
        '
        'ToolStrip2
        '
        Me.ToolStrip2.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden
        Me.ToolStrip2.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.RefreshViewTSB, Me.ToolStripSeparator17, Me.ExpandCollapseTSB})
        Me.ToolStrip2.Location = New System.Drawing.Point(0, 0)
        Me.ToolStrip2.Name = "ToolStrip2"
        Me.ToolStrip2.Size = New System.Drawing.Size(256, 25)
        Me.ToolStrip2.TabIndex = 1
        Me.ToolStrip2.Text = "ToolStrip2"
        '
        'RefreshViewTSB
        '
        Me.RefreshViewTSB.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.RefreshViewTSB.Image = CType(resources.GetObject("RefreshViewTSB.Image"), System.Drawing.Image)
        Me.RefreshViewTSB.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.RefreshViewTSB.Name = "RefreshViewTSB"
        Me.RefreshViewTSB.Size = New System.Drawing.Size(23, 22)
        Me.RefreshViewTSB.Text = "Refresh view"
        '
        'ToolStripSeparator17
        '
        Me.ToolStripSeparator17.Name = "ToolStripSeparator17"
        Me.ToolStripSeparator17.Size = New System.Drawing.Size(6, 25)
        '
        'ExpandCollapseTSB
        '
        Me.ExpandCollapseTSB.Image = CType(resources.GetObject("ExpandCollapseTSB.Image"), System.Drawing.Image)
        Me.ExpandCollapseTSB.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ExpandCollapseTSB.Name = "ExpandCollapseTSB"
        Me.ExpandCollapseTSB.Size = New System.Drawing.Size(66, 22)
        Me.ExpandCollapseTSB.Text = "Expand"
        '
        'prjTreeStatus
        '
        Me.prjTreeStatus.BackColor = System.Drawing.SystemColors.Control
        Me.prjTreeStatus.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.prjTreeStatus.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripStatusLabel2, Me.ToolStripProgressBar1})
        Me.prjTreeStatus.Location = New System.Drawing.Point(0, 608)
        Me.prjTreeStatus.Name = "prjTreeStatus"
        Me.prjTreeStatus.Size = New System.Drawing.Size(256, 22)
        Me.prjTreeStatus.SizingGrip = False
        Me.prjTreeStatus.TabIndex = 0
        Me.prjTreeStatus.Text = "StatusStrip1"
        Me.prjTreeStatus.Visible = False
        '
        'ToolStripStatusLabel2
        '
        Me.ToolStripStatusLabel2.Name = "ToolStripStatusLabel2"
        Me.ToolStripStatusLabel2.Size = New System.Drawing.Size(125, 17)
        Me.ToolStripStatusLabel2.Text = "Preparing project tree..."
        '
        'ToolStripProgressBar1
        '
        Me.ToolStripProgressBar1.Name = "ToolStripProgressBar1"
        Me.ToolStripProgressBar1.Size = New System.Drawing.Size(100, 16)
        '
        'StatusStrip
        '
        Me.StatusStrip.AutoSize = False
        Me.StatusStrip.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.StatusStrip.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.BackgroundProcessesButton, Me.MenuDesc})
        Me.StatusStrip.Location = New System.Drawing.Point(0, 631)
        Me.StatusStrip.Name = "StatusStrip"
        Me.StatusStrip.Size = New System.Drawing.Size(1264, 26)
        Me.StatusStrip.TabIndex = 0
        Me.StatusStrip.Text = "Status"
        '
        'BackgroundProcessesButton
        '
        Me.BackgroundProcessesButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BackgroundProcessesButton.DropDownButtonWidth = 0
        Me.BackgroundProcessesButton.Image = CType(resources.GetObject("BackgroundProcessesButton.Image"), System.Drawing.Image)
        Me.BackgroundProcessesButton.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.BackgroundProcessesButton.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.BackgroundProcessesButton.Name = "BackgroundProcessesButton"
        Me.BackgroundProcessesButton.Size = New System.Drawing.Size(25, 24)
        Me.BackgroundProcessesButton.ToolTipText = "View background processes"
        '
        'MenuDesc
        '
        Me.MenuDesc.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.MenuDesc.Name = "MenuDesc"
        Me.MenuDesc.Size = New System.Drawing.Size(39, 21)
        Me.MenuDesc.Text = "Ready"
        '
        'OpenFileDialog1
        '
        Me.OpenFileDialog1.Filter = "DISMTools project files|*.dtproj"
        Me.OpenFileDialog1.RestoreDirectory = True
        Me.OpenFileDialog1.SupportMultiDottedExtensions = True
        Me.OpenFileDialog1.Title = "Specify the project file to load"
        '
        'PkgInfoCMS
        '
        Me.PkgInfoCMS.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.PkgInfoCMS.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.PkgBasicInfo, Me.PkgDetailedInfo})
        Me.PkgInfoCMS.Name = "PkgInfoCMS"
        Me.PkgInfoCMS.ShowImageMargin = False
        Me.PkgInfoCMS.Size = New System.Drawing.Size(277, 48)
        '
        'PkgBasicInfo
        '
        Me.PkgBasicInfo.Name = "PkgBasicInfo"
        Me.PkgBasicInfo.Size = New System.Drawing.Size(276, 22)
        Me.PkgBasicInfo.Text = "Get basic information (all packages)"
        '
        'PkgDetailedInfo
        '
        Me.PkgDetailedInfo.Name = "PkgDetailedInfo"
        Me.PkgDetailedInfo.Size = New System.Drawing.Size(276, 22)
        Me.PkgDetailedInfo.Text = "Get detailed information (specific package)"
        '
        'ImgBW
        '
        Me.ImgBW.WorkerReportsProgress = True
        Me.ImgBW.WorkerSupportsCancellation = True
        '
        'ImgProcesses
        '
        Me.ImgProcesses.StartInfo.Domain = ""
        Me.ImgProcesses.StartInfo.LoadUserProfile = False
        Me.ImgProcesses.StartInfo.Password = Nothing
        Me.ImgProcesses.StartInfo.StandardErrorEncoding = Nothing
        Me.ImgProcesses.StartInfo.StandardOutputEncoding = Nothing
        Me.ImgProcesses.StartInfo.UserName = ""
        Me.ImgProcesses.SynchronizingObject = Me
        '
        'LocalMountDirFBD
        '
        Me.LocalMountDirFBD.Description = "Please specify the mount directory you want to load into this project:"
        Me.LocalMountDirFBD.RootFolder = System.Environment.SpecialFolder.MyComputer
        Me.LocalMountDirFBD.ShowNewFolderButton = False
        '
        'MountedImageDetectorBW
        '
        Me.MountedImageDetectorBW.WorkerSupportsCancellation = True
        '
        'ImgUMountPopupCMS
        '
        Me.ImgUMountPopupCMS.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.CommitAndUnmountTSMI, Me.DiscardAndUnmountTSMI, Me.ToolStripSeparator20, Me.UnmountSettingsToolStripMenuItem})
        Me.ImgUMountPopupCMS.Name = "ImgUMountPopupCMS"
        Me.ImgUMountPopupCMS.ShowImageMargin = False
        Me.ImgUMountPopupCMS.Size = New System.Drawing.Size(253, 76)
        '
        'CommitAndUnmountTSMI
        '
        Me.CommitAndUnmountTSMI.Name = "CommitAndUnmountTSMI"
        Me.CommitAndUnmountTSMI.Size = New System.Drawing.Size(252, 22)
        Me.CommitAndUnmountTSMI.Text = "Commit changes and unmount image"
        '
        'DiscardAndUnmountTSMI
        '
        Me.DiscardAndUnmountTSMI.Name = "DiscardAndUnmountTSMI"
        Me.DiscardAndUnmountTSMI.Size = New System.Drawing.Size(252, 22)
        Me.DiscardAndUnmountTSMI.Text = "Discard changes and unmount image"
        '
        'ToolStripSeparator20
        '
        Me.ToolStripSeparator20.Name = "ToolStripSeparator20"
        Me.ToolStripSeparator20.Size = New System.Drawing.Size(249, 6)
        '
        'UnmountSettingsToolStripMenuItem
        '
        Me.UnmountSettingsToolStripMenuItem.Name = "UnmountSettingsToolStripMenuItem"
        Me.UnmountSettingsToolStripMenuItem.Size = New System.Drawing.Size(252, 22)
        Me.UnmountSettingsToolStripMenuItem.Text = "Unmount settings..."
        '
        'AppxPackagePopupCMS
        '
        Me.AppxPackagePopupCMS.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ViewPackageDirectoryToolStripMenuItem, Me.ResViewTSMI})
        Me.AppxPackagePopupCMS.Name = "AppxPackagePopupCMS"
        Me.AppxPackagePopupCMS.Size = New System.Drawing.Size(197, 48)
        '
        'ViewPackageDirectoryToolStripMenuItem
        '
        Me.ViewPackageDirectoryToolStripMenuItem.Image = Global.DISMTools.My.Resources.Resources.openfile
        Me.ViewPackageDirectoryToolStripMenuItem.Name = "ViewPackageDirectoryToolStripMenuItem"
        Me.ViewPackageDirectoryToolStripMenuItem.Size = New System.Drawing.Size(196, 22)
        Me.ViewPackageDirectoryToolStripMenuItem.Text = "View package directory"
        '
        'ResViewTSMI
        '
        Me.ResViewTSMI.Name = "ResViewTSMI"
        Me.ResViewTSMI.Size = New System.Drawing.Size(196, 22)
        Me.ResViewTSMI.Text = "View resources for "
        '
        'TreeViewCMS
        '
        Me.TreeViewCMS.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ExpandToolStripMenuItem, Me.AccessDirectoryToolStripMenuItem, Me.ToolStripSeparator23, Me.UnloadProjectToolStripMenuItem1, Me.ToolStripSeparator24, Me.CopyDeploymentToolsToolStripMenuItem, Me.ToolStripSeparator27, Me.ImageOperationsToolStripMenuItem, Me.ToolStripSeparator30, Me.UnattendedAnswerFilesToolStripMenuItem1, Me.ToolStripSeparator31, Me.ScratchDirectorySettingsToolStripMenuItem, Me.ToolStripSeparator32, Me.ManageReportsToolStripMenuItem, Me.ToolStripSeparator33, Me.AddToolStripMenuItem})
        Me.TreeViewCMS.Name = "TreeViewCMS"
        Me.TreeViewCMS.Size = New System.Drawing.Size(219, 266)
        '
        'ExpandToolStripMenuItem
        '
        Me.ExpandToolStripMenuItem.Name = "ExpandToolStripMenuItem"
        Me.ExpandToolStripMenuItem.Size = New System.Drawing.Size(218, 22)
        Me.ExpandToolStripMenuItem.Text = "Expand item"
        '
        'AccessDirectoryToolStripMenuItem
        '
        Me.AccessDirectoryToolStripMenuItem.Name = "AccessDirectoryToolStripMenuItem"
        Me.AccessDirectoryToolStripMenuItem.Size = New System.Drawing.Size(218, 22)
        Me.AccessDirectoryToolStripMenuItem.Text = "Access directory"
        '
        'ToolStripSeparator23
        '
        Me.ToolStripSeparator23.Name = "ToolStripSeparator23"
        Me.ToolStripSeparator23.Size = New System.Drawing.Size(215, 6)
        '
        'UnloadProjectToolStripMenuItem1
        '
        Me.UnloadProjectToolStripMenuItem1.Name = "UnloadProjectToolStripMenuItem1"
        Me.UnloadProjectToolStripMenuItem1.Size = New System.Drawing.Size(218, 22)
        Me.UnloadProjectToolStripMenuItem1.Text = "Unload project"
        '
        'ToolStripSeparator24
        '
        Me.ToolStripSeparator24.Name = "ToolStripSeparator24"
        Me.ToolStripSeparator24.Size = New System.Drawing.Size(215, 6)
        '
        'CopyDeploymentToolsToolStripMenuItem
        '
        Me.CopyDeploymentToolsToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.OfAllArchitecturesToolStripMenuItem, Me.OfSelectedArchitectureToolStripMenuItem, Me.ToolStripSeparator25, Me.ForX86ArchitectureToolStripMenuItem, Me.ForAmd64ArchitectureToolStripMenuItem, Me.ForARMArchitectureToolStripMenuItem, Me.ForARM64ArchitectureToolStripMenuItem})
        Me.CopyDeploymentToolsToolStripMenuItem.Name = "CopyDeploymentToolsToolStripMenuItem"
        Me.CopyDeploymentToolsToolStripMenuItem.Size = New System.Drawing.Size(218, 22)
        Me.CopyDeploymentToolsToolStripMenuItem.Text = "Copy deployment tools"
        '
        'OfAllArchitecturesToolStripMenuItem
        '
        Me.OfAllArchitecturesToolStripMenuItem.Name = "OfAllArchitecturesToolStripMenuItem"
        Me.OfAllArchitecturesToolStripMenuItem.Size = New System.Drawing.Size(199, 22)
        Me.OfAllArchitecturesToolStripMenuItem.Text = "Of all architectures"
        '
        'OfSelectedArchitectureToolStripMenuItem
        '
        Me.OfSelectedArchitectureToolStripMenuItem.Name = "OfSelectedArchitectureToolStripMenuItem"
        Me.OfSelectedArchitectureToolStripMenuItem.Size = New System.Drawing.Size(199, 22)
        Me.OfSelectedArchitectureToolStripMenuItem.Text = "Of selected architecture"
        '
        'ToolStripSeparator25
        '
        Me.ToolStripSeparator25.Name = "ToolStripSeparator25"
        Me.ToolStripSeparator25.Size = New System.Drawing.Size(196, 6)
        '
        'ForX86ArchitectureToolStripMenuItem
        '
        Me.ForX86ArchitectureToolStripMenuItem.Name = "ForX86ArchitectureToolStripMenuItem"
        Me.ForX86ArchitectureToolStripMenuItem.Size = New System.Drawing.Size(199, 22)
        Me.ForX86ArchitectureToolStripMenuItem.Text = "For x86 architecture"
        '
        'ForAmd64ArchitectureToolStripMenuItem
        '
        Me.ForAmd64ArchitectureToolStripMenuItem.Name = "ForAmd64ArchitectureToolStripMenuItem"
        Me.ForAmd64ArchitectureToolStripMenuItem.Size = New System.Drawing.Size(199, 22)
        Me.ForAmd64ArchitectureToolStripMenuItem.Text = "For AMD64 architecture"
        '
        'ForARMArchitectureToolStripMenuItem
        '
        Me.ForARMArchitectureToolStripMenuItem.Name = "ForARMArchitectureToolStripMenuItem"
        Me.ForARMArchitectureToolStripMenuItem.Size = New System.Drawing.Size(199, 22)
        Me.ForARMArchitectureToolStripMenuItem.Text = "For ARM architecture"
        '
        'ForARM64ArchitectureToolStripMenuItem
        '
        Me.ForARM64ArchitectureToolStripMenuItem.Name = "ForARM64ArchitectureToolStripMenuItem"
        Me.ForARM64ArchitectureToolStripMenuItem.Size = New System.Drawing.Size(199, 22)
        Me.ForARM64ArchitectureToolStripMenuItem.Text = "For ARM64 architecture"
        '
        'ToolStripSeparator27
        '
        Me.ToolStripSeparator27.Name = "ToolStripSeparator27"
        Me.ToolStripSeparator27.Size = New System.Drawing.Size(215, 6)
        '
        'ImageOperationsToolStripMenuItem
        '
        Me.ImageOperationsToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.MountImageToolStripMenuItem, Me.UnmountImageToolStripMenuItem, Me.ToolStripSeparator29, Me.RemoveVolumeImagesToolStripMenuItem, Me.SwitchImageIndexesToolStripMenuItem1})
        Me.ImageOperationsToolStripMenuItem.Name = "ImageOperationsToolStripMenuItem"
        Me.ImageOperationsToolStripMenuItem.Size = New System.Drawing.Size(218, 22)
        Me.ImageOperationsToolStripMenuItem.Text = "Image operations"
        '
        'MountImageToolStripMenuItem
        '
        Me.MountImageToolStripMenuItem.Name = "MountImageToolStripMenuItem"
        Me.MountImageToolStripMenuItem.Size = New System.Drawing.Size(210, 22)
        Me.MountImageToolStripMenuItem.Text = "Mount image..."
        '
        'UnmountImageToolStripMenuItem
        '
        Me.UnmountImageToolStripMenuItem.Name = "UnmountImageToolStripMenuItem"
        Me.UnmountImageToolStripMenuItem.Size = New System.Drawing.Size(210, 22)
        Me.UnmountImageToolStripMenuItem.Text = "Unmount image..."
        '
        'ToolStripSeparator29
        '
        Me.ToolStripSeparator29.Name = "ToolStripSeparator29"
        Me.ToolStripSeparator29.Size = New System.Drawing.Size(207, 6)
        '
        'RemoveVolumeImagesToolStripMenuItem
        '
        Me.RemoveVolumeImagesToolStripMenuItem.Name = "RemoveVolumeImagesToolStripMenuItem"
        Me.RemoveVolumeImagesToolStripMenuItem.Size = New System.Drawing.Size(210, 22)
        Me.RemoveVolumeImagesToolStripMenuItem.Text = "Remove volume images..."
        '
        'SwitchImageIndexesToolStripMenuItem1
        '
        Me.SwitchImageIndexesToolStripMenuItem1.Name = "SwitchImageIndexesToolStripMenuItem1"
        Me.SwitchImageIndexesToolStripMenuItem1.Size = New System.Drawing.Size(210, 22)
        Me.SwitchImageIndexesToolStripMenuItem1.Text = "Switch image indexes..."
        '
        'ToolStripSeparator30
        '
        Me.ToolStripSeparator30.Name = "ToolStripSeparator30"
        Me.ToolStripSeparator30.Size = New System.Drawing.Size(215, 6)
        '
        'UnattendedAnswerFilesToolStripMenuItem1
        '
        Me.UnattendedAnswerFilesToolStripMenuItem1.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ManageToolStripMenuItem, Me.CreationWizardToolStripMenuItem})
        Me.UnattendedAnswerFilesToolStripMenuItem1.Name = "UnattendedAnswerFilesToolStripMenuItem1"
        Me.UnattendedAnswerFilesToolStripMenuItem1.Size = New System.Drawing.Size(218, 22)
        Me.UnattendedAnswerFilesToolStripMenuItem1.Text = "Unattended answer files"
        '
        'ManageToolStripMenuItem
        '
        Me.ManageToolStripMenuItem.Name = "ManageToolStripMenuItem"
        Me.ManageToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.ManageToolStripMenuItem.Text = "Manage"
        '
        'CreationWizardToolStripMenuItem
        '
        Me.CreationWizardToolStripMenuItem.Name = "CreationWizardToolStripMenuItem"
        Me.CreationWizardToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.CreationWizardToolStripMenuItem.Text = "Create"
        '
        'ToolStripSeparator31
        '
        Me.ToolStripSeparator31.Name = "ToolStripSeparator31"
        Me.ToolStripSeparator31.Size = New System.Drawing.Size(215, 6)
        '
        'ScratchDirectorySettingsToolStripMenuItem
        '
        Me.ScratchDirectorySettingsToolStripMenuItem.Name = "ScratchDirectorySettingsToolStripMenuItem"
        Me.ScratchDirectorySettingsToolStripMenuItem.Size = New System.Drawing.Size(218, 22)
        Me.ScratchDirectorySettingsToolStripMenuItem.Text = "Configure scratch directory"
        '
        'ToolStripSeparator32
        '
        Me.ToolStripSeparator32.Name = "ToolStripSeparator32"
        Me.ToolStripSeparator32.Size = New System.Drawing.Size(215, 6)
        '
        'ManageReportsToolStripMenuItem
        '
        Me.ManageReportsToolStripMenuItem.Name = "ManageReportsToolStripMenuItem"
        Me.ManageReportsToolStripMenuItem.Size = New System.Drawing.Size(218, 22)
        Me.ManageReportsToolStripMenuItem.Text = "Manage reports"
        '
        'ToolStripSeparator33
        '
        Me.ToolStripSeparator33.Name = "ToolStripSeparator33"
        Me.ToolStripSeparator33.Size = New System.Drawing.Size(215, 6)
        '
        'AddToolStripMenuItem
        '
        Me.AddToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.NewFileToolStripMenuItem, Me.ExistingFileToolStripMenuItem})
        Me.AddToolStripMenuItem.Name = "AddToolStripMenuItem"
        Me.AddToolStripMenuItem.Size = New System.Drawing.Size(218, 22)
        Me.AddToolStripMenuItem.Text = "Add"
        '
        'NewFileToolStripMenuItem
        '
        Me.NewFileToolStripMenuItem.Name = "NewFileToolStripMenuItem"
        Me.NewFileToolStripMenuItem.Size = New System.Drawing.Size(143, 22)
        Me.NewFileToolStripMenuItem.Text = "New file..."
        '
        'ExistingFileToolStripMenuItem
        '
        Me.ExistingFileToolStripMenuItem.Name = "ExistingFileToolStripMenuItem"
        Me.ExistingFileToolStripMenuItem.Size = New System.Drawing.Size(143, 22)
        Me.ExistingFileToolStripMenuItem.Text = "Existing file..."
        '
        'ADKCopierBW
        '
        Me.ADKCopierBW.WorkerReportsProgress = True
        Me.ADKCopierBW.WorkerSupportsCancellation = True
        '
        'UpdCheckerBW
        '
        Me.UpdCheckerBW.WorkerReportsProgress = True
        Me.UpdCheckerBW.WorkerSupportsCancellation = True
        '
        'AppxResCMS
        '
        Me.AppxResCMS.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.SaveResourceToolStripMenuItem, Me.CopyToolStripMenuItem})
        Me.AppxResCMS.Name = "ContextMenuStrip1"
        Me.AppxResCMS.ShowImageMargin = False
        Me.AppxResCMS.Size = New System.Drawing.Size(131, 48)
        '
        'SaveResourceToolStripMenuItem
        '
        Me.SaveResourceToolStripMenuItem.Name = "SaveResourceToolStripMenuItem"
        Me.SaveResourceToolStripMenuItem.Size = New System.Drawing.Size(130, 22)
        Me.SaveResourceToolStripMenuItem.Text = "Save resource..."
        '
        'CopyToolStripMenuItem
        '
        Me.CopyToolStripMenuItem.Name = "CopyToolStripMenuItem"
        Me.CopyToolStripMenuItem.Size = New System.Drawing.Size(130, 22)
        Me.CopyToolStripMenuItem.Text = "Copy resource"
        '
        'AppxResSFD
        '
        Me.AppxResSFD.Filter = "PNG files|*.png"
        '
        'Notifications
        '
        '
        'AppxRelatedLinksCMS
        '
        Me.AppxRelatedLinksCMS.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.MicrosoftAppsToolStripMenuItem, Me.MicrosoftStoreGenerationProjectToolStripMenuItem, Me.ToolStripSeparator36, Me.AppxDownloadHelpToolStripMenuItem})
        Me.AppxRelatedLinksCMS.Name = "AppxRelatedLinksCMS"
        Me.AppxRelatedLinksCMS.ShowImageMargin = False
        Me.AppxRelatedLinksCMS.Size = New System.Drawing.Size(320, 76)
        '
        'MicrosoftAppsToolStripMenuItem
        '
        Me.MicrosoftAppsToolStripMenuItem.Name = "MicrosoftAppsToolStripMenuItem"
        Me.MicrosoftAppsToolStripMenuItem.Size = New System.Drawing.Size(319, 22)
        Me.MicrosoftAppsToolStripMenuItem.Text = "Visit the Microsoft Apps website"
        '
        'MicrosoftStoreGenerationProjectToolStripMenuItem
        '
        Me.MicrosoftStoreGenerationProjectToolStripMenuItem.Name = "MicrosoftStoreGenerationProjectToolStripMenuItem"
        Me.MicrosoftStoreGenerationProjectToolStripMenuItem.Size = New System.Drawing.Size(319, 22)
        Me.MicrosoftStoreGenerationProjectToolStripMenuItem.Text = "Visit the Microsoft Store Generation Project website"
        '
        'ToolStripSeparator36
        '
        Me.ToolStripSeparator36.Name = "ToolStripSeparator36"
        Me.ToolStripSeparator36.Size = New System.Drawing.Size(316, 6)
        '
        'AppxDownloadHelpToolStripMenuItem
        '
        Me.AppxDownloadHelpToolStripMenuItem.Name = "AppxDownloadHelpToolStripMenuItem"
        Me.AppxDownloadHelpToolStripMenuItem.Size = New System.Drawing.Size(319, 22)
        Me.AppxDownloadHelpToolStripMenuItem.Text = "How do I get applications?"
        '
        'ImgInfoSFD
        '
        Me.ImgInfoSFD.Filter = "Text files|*.txt"
        '
        'Timer1
        '
        Me.Timer1.Interval = 1
        '
        'FeedWorker
        '
        Me.FeedWorker.WorkerReportsProgress = True
        Me.FeedWorker.WorkerSupportsCancellation = True
        '
        'Timer2
        '
        Me.Timer2.Interval = 900000
        '
        'WatcherBW
        '
        Me.WatcherBW.WorkerSupportsCancellation = True
        '
        'WatcherTimer
        '
        Me.WatcherTimer.Interval = 1000
        '
        'ImgSpecialToolsCMS
        '
        Me.ImgSpecialToolsCMS.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.GetImageFileInformationToolStripMenuItem, Me.ToolStripSeparator39, Me.SaveCompleteImageInformationToolStripMenuItem, Me.ToolStripSeparator40, Me.CreateDiscImageWithThisFileToolStripMenuItem})
        Me.ImgSpecialToolsCMS.Name = "ImgSpecialToolsCMS"
        Me.ImgSpecialToolsCMS.ShowImageMargin = False
        Me.ImgSpecialToolsCMS.Size = New System.Drawing.Size(238, 82)
        '
        'GetImageFileInformationToolStripMenuItem
        '
        Me.GetImageFileInformationToolStripMenuItem.Name = "GetImageFileInformationToolStripMenuItem"
        Me.GetImageFileInformationToolStripMenuItem.Size = New System.Drawing.Size(237, 22)
        Me.GetImageFileInformationToolStripMenuItem.Text = "Get image file information..."
        '
        'ToolStripSeparator39
        '
        Me.ToolStripSeparator39.Name = "ToolStripSeparator39"
        Me.ToolStripSeparator39.Size = New System.Drawing.Size(234, 6)
        '
        'SaveCompleteImageInformationToolStripMenuItem
        '
        Me.SaveCompleteImageInformationToolStripMenuItem.Name = "SaveCompleteImageInformationToolStripMenuItem"
        Me.SaveCompleteImageInformationToolStripMenuItem.Size = New System.Drawing.Size(237, 22)
        Me.SaveCompleteImageInformationToolStripMenuItem.Text = "Save complete image information..."
        '
        'ToolStripSeparator40
        '
        Me.ToolStripSeparator40.Name = "ToolStripSeparator40"
        Me.ToolStripSeparator40.Size = New System.Drawing.Size(234, 6)
        '
        'CreateDiscImageWithThisFileToolStripMenuItem
        '
        Me.CreateDiscImageWithThisFileToolStripMenuItem.Name = "CreateDiscImageWithThisFileToolStripMenuItem"
        Me.CreateDiscImageWithThisFileToolStripMenuItem.Size = New System.Drawing.Size(237, 22)
        Me.CreateDiscImageWithThisFileToolStripMenuItem.Text = "Create disc image with this file..."
        '
        'WIEDownloaderBW
        '
        '
        'VideoGetterBW
        '
        Me.VideoGetterBW.WorkerReportsProgress = True
        Me.VideoGetterBW.WorkerSupportsCancellation = True
        '
        'MountedImageDetectorBWRestarterTimer
        '
        Me.MountedImageDetectorBWRestarterTimer.Interval = 2000
        '
        'MainForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1264, 681)
        Me.Controls.Add(Me.HomePanel)
        Me.Controls.Add(Me.PrjPanel)
        Me.Controls.Add(Me.MenuStrip1)
        Me.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.KeyPreview = True
        Me.MaximumSize = New System.Drawing.Size(4096, 4096)
        Me.MinimumSize = New System.Drawing.Size(1280, 718)
        Me.Name = "MainForm"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.Manual
        Me.Text = "DISMTools"
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.HomePanel.ResumeLayout(False)
        Me.WelcomePanel.ResumeLayout(False)
        Me.StartPanel.ResumeLayout(False)
        Me.StartPanelPContainer.ResumeLayout(False)
        Me.GetStartedPanel.ResumeLayout(False)
        Me.GetStartedContainer.ResumeLayout(False)
        Me.Panel6.ResumeLayout(False)
        Me.Panel6.PerformLayout()
        CType(Me.PictureBox8, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox7, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox6, System.ComponentModel.ISupportInitialize).EndInit()
        Me.LatestNewsPanel.ResumeLayout(False)
        Me.FeedContainer.ResumeLayout(False)
        Me.FeedsPanel.ResumeLayout(False)
        Me.FeedErrorPanel.ResumeLayout(False)
        Me.FeedErrorPanel.PerformLayout()
        Me.Panel4.ResumeLayout(False)
        Me.TutorialVideoPanel.ResumeLayout(False)
        Me.VideoContainer.ResumeLayout(False)
        Me.VideosPanel.ResumeLayout(False)
        Me.VideoErrorPanel.ResumeLayout(False)
        Me.VideoErrorPanel.PerformLayout()
        Me.Panel1.ResumeLayout(False)
        Me.FlowLayoutPanel2.ResumeLayout(False)
        Me.FlowLayoutPanel2.PerformLayout()
        Me.SidePanel.ResumeLayout(False)
        Me.SidePanel.PerformLayout()
        Me.UpdatePanel.ResumeLayout(False)
        Me.Panel3.ResumeLayout(False)
        Me.Panel3.PerformLayout()
        CType(Me.PictureBox5, System.ComponentModel.ISupportInitialize).EndInit()
        Me.PrjPanel.ResumeLayout(False)
        Me.PrjPanel.PerformLayout()
        Me.ProjectView.ResumeLayout(False)
        Me.Panel11.ResumeLayout(False)
        Me.FlowLayoutPanel1.ResumeLayout(False)
        Me.GroupBox4.ResumeLayout(False)
        Me.GroupBox5.ResumeLayout(False)
        Me.GroupBox6.ResumeLayout(False)
        Me.GroupBox7.ResumeLayout(False)
        Me.GroupBox8.ResumeLayout(False)
        Me.GroupBox9.ResumeLayout(False)
        Me.GroupBox10.ResumeLayout(False)
        Me.ProjectSidePanel.ResumeLayout(False)
        Me.ProjectSidePanelContainer.ResumeLayout(False)
        Me.SidePanel_ProjectView.ResumeLayout(False)
        Me.SidePanel_ProjectView.PerformLayout()
        Me.PrjTasks.ResumeLayout(False)
        CType(Me.PictureBox11, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox10, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox9, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TableLayoutPanel6.ResumeLayout(False)
        Me.TableLayoutPanel6.PerformLayout()
        Me.Panel13.ResumeLayout(False)
        Me.SidePanel_ImageView.ResumeLayout(False)
        Me.ImageView_NoImage.ResumeLayout(False)
        Me.ImageView_NoImage.PerformLayout()
        Me.TableLayoutPanel7.ResumeLayout(False)
        CType(Me.PictureBox12, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox15, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ImageView_BasicInfo.ResumeLayout(False)
        Me.ImageView_BasicInfo.PerformLayout()
        Me.ImgTasks.ResumeLayout(False)
        CType(Me.PictureBox13, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox14, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TableLayoutPanel5.ResumeLayout(False)
        Me.Panel10.ResumeLayout(False)
        Me.TableLayoutPanel4.ResumeLayout(False)
        Me.TableLayoutPanel4.PerformLayout()
        Me.ProjectViewHeader.ResumeLayout(False)
        Me.ProjectViewHeader.PerformLayout()
        Me.SplitPanels.Panel1.ResumeLayout(False)
        Me.SplitPanels.Panel2.ResumeLayout(False)
        CType(Me.SplitPanels, System.ComponentModel.ISupportInitialize).EndInit()
        Me.SplitPanels.ResumeLayout(False)
        Me.TabControl1.ResumeLayout(False)
        Me.TabPage1.ResumeLayout(False)
        Me.TabTitleSummary1.ResumeLayout(False)
        Me.TabTitleSummary1.PerformLayout()
        CType(Me.TabPageIcon1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TableLayoutPanel2.ResumeLayout(False)
        Me.TableLayoutPanel2.PerformLayout()
        Me.Panel8.ResumeLayout(False)
        Me.Panel8.PerformLayout()
        Me.Panel9.ResumeLayout(False)
        Me.TabPage2.ResumeLayout(False)
        Me.ImageNotMountedPanel.ResumeLayout(False)
        Me.ImagePanel.ResumeLayout(False)
        Me.TabTitleSummary2.ResumeLayout(False)
        Me.TabTitleSummary2.PerformLayout()
        CType(Me.TabPageIcon2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TableLayoutPanel1.ResumeLayout(False)
        Me.TabControl2.ResumeLayout(False)
        Me.TabPage3.ResumeLayout(False)
        Me.OldActionPanel.ResumeLayout(False)
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox2.ResumeLayout(False)
        Me.ToolStrip1.ResumeLayout(False)
        Me.ToolStrip1.PerformLayout()
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        Me.ToolStrip2.ResumeLayout(False)
        Me.ToolStrip2.PerformLayout()
        Me.prjTreeStatus.ResumeLayout(False)
        Me.prjTreeStatus.PerformLayout()
        Me.StatusStrip.ResumeLayout(False)
        Me.StatusStrip.PerformLayout()
        Me.PkgInfoCMS.ResumeLayout(False)
        Me.ImgUMountPopupCMS.ResumeLayout(False)
        Me.AppxPackagePopupCMS.ResumeLayout(False)
        Me.TreeViewCMS.ResumeLayout(False)
        Me.AppxResCMS.ResumeLayout(False)
        Me.AppxRelatedLinksCMS.ResumeLayout(False)
        Me.ImgSpecialToolsCMS.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents MenuStrip1 As System.Windows.Forms.MenuStrip
    Friend WithEvents FileToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents NewProjectToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents OpenExistingProjectToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator1 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents SaveProjectToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SaveProjectasToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator2 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ExitToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ProjectToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ViewProjectFilesInFileExplorerToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents UnloadProjectToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator3 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents SwitchImageIndexesToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ProjectPropertiesToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CommandsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ImageManagementToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AppendImage As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ApplyFFU As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ApplyImage As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CaptureCustomImage As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CaptureFFU As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CaptureImage As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CleanupMountpoints As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CommitImage As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DeleteImage As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ExportImage As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents GetImageInfo As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents GetWIMBootEntry As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ListImage As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents MountImage As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents OptimizeFFU As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents OptimizeImage As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents RemountImage As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SplitFFU As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SplitImage As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents UnmountImage As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents UpdateWIMBootEntry As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ApplySiloedPackage As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents OSPackagesToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents GetPackages As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AddPackage As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents RemovePackage As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents GetFeatures As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents EnableFeature As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DisableFeature As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator4 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents CleanupImage As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ProvisioningPackagesToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AddProvisioningPackage As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents GetProvisioningPackageInfo As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ApplyCustomDataImage As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AppPackagesToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents GetProvisionedAppxPackages As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AddProvisionedAppxPackage As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents RemoveProvisionedAppxPackage As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents OptimizeProvisionedAppxPackages As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SetProvisionedAppxDataFile As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AppPatchesToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CheckAppPatch As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents GetAppPatchInfo As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents GetAppPatches As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents GetAppInfo As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents GetApps As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DefaultAppAssociationsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ExportDefaultAppAssociations As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents GetDefaultAppAssociations As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ImportDefaultAppAssociations As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents RemoveDefaultAppAssociations As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents LanguagesAndRegionSettingsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents GetIntl As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SetUILang As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SetUILangFallback As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SetSysUILang As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SetSysLocale As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SetUserLocale As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SetInputLocale As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator5 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents SetAllIntl As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator6 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents SetTimeZone As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator7 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents SetSKUIntlDefaults As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator8 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents SetLayeredDriver As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents GenLangINI As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SetSetupUILang As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CapabilitiesToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AddCapability As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ExportSource As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents GetCapabilities As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents RemoveCapability As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents WindowsEditionsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents GetCurrentEdition As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents GetTargetEditions As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SetEdition As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SetProductKey As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DriversToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents GetDrivers As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AddDriver As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents RemoveDriver As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ExportDriver As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents UnattendedAnswerFilesToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ApplyUnattend As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents WindowsPEServicingToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents GetPESettings As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SetScratchSpace As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SetTargetPath As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents OSUninstallToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents GetOSUninstallWindow As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents InitiateOSUninstall As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents RemoveOSUninstall As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SetOSUninstallWindow As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ReservedStorageToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SetReservedStorageState As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents GetReservedStorageState As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents OptionsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents HelpToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents HelpTopicsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents GlossaryToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CommandHelpToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator10 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents AboutDISMToolsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents HomePanel As System.Windows.Forms.Panel
    Friend WithEvents WelcomePanel As System.Windows.Forms.Panel
    Friend WithEvents SidePanel As System.Windows.Forms.Panel
    Friend WithEvents ExistingProjLink As System.Windows.Forms.LinkLabel
    Friend WithEvents NewProjLink As System.Windows.Forms.LinkLabel
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents LabelHeader1 As System.Windows.Forms.Label
    Friend WithEvents Panel3 As System.Windows.Forms.Panel
    Friend WithEvents PrjPanel As System.Windows.Forms.Panel
    Friend WithEvents SplitPanels As System.Windows.Forms.SplitContainer
    Friend WithEvents TabControl1 As System.Windows.Forms.TabControl
    Friend WithEvents TabPage1 As System.Windows.Forms.TabPage
    Friend WithEvents ProjNameEditBtn As System.Windows.Forms.Button
    Friend WithEvents UnloadBtn As System.Windows.Forms.Button
    Friend WithEvents ExplorerView As System.Windows.Forms.Button
    Friend WithEvents LinkLabel1 As System.Windows.Forms.LinkLabel
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents projName As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents TabTitleSummary1 As System.Windows.Forms.Panel
    Friend WithEvents TabPageIcon1 As System.Windows.Forms.PictureBox
    Friend WithEvents TabPageDescription1 As System.Windows.Forms.Label
    Friend WithEvents TabPageTitle1 As System.Windows.Forms.Label
    Friend WithEvents projNameText As System.Windows.Forms.TextBox
    Friend WithEvents TabPage2 As System.Windows.Forms.TabPage
    Friend WithEvents TabTitleSummary2 As System.Windows.Forms.Panel
    Friend WithEvents TabPageIcon2 As System.Windows.Forms.PictureBox
    Friend WithEvents TabPageDescription2 As System.Windows.Forms.Label
    Friend WithEvents TabPageTitle2 As System.Windows.Forms.Label
    Friend WithEvents TabControl2 As System.Windows.Forms.TabControl
    Friend WithEvents TabPage3 As System.Windows.Forms.TabPage
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents Button8 As System.Windows.Forms.Button
    Friend WithEvents Button9 As System.Windows.Forms.Button
    Friend WithEvents Button10 As System.Windows.Forms.Button
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents Button6 As System.Windows.Forms.Button
    Friend WithEvents Button7 As System.Windows.Forms.Button
    Friend WithEvents Button5 As System.Windows.Forms.Button
    Friend WithEvents Button12 As System.Windows.Forms.Button
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents Button13 As System.Windows.Forms.Button
    Friend WithEvents Button11 As System.Windows.Forms.Button
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents Button3 As System.Windows.Forms.Button
    Friend WithEvents Button4 As System.Windows.Forms.Button
    Friend WithEvents ToolStrip1 As System.Windows.Forms.ToolStrip
    Friend WithEvents ToolStripButton1 As System.Windows.Forms.ToolStripButton
    Friend WithEvents StatusStrip As System.Windows.Forms.StatusStrip
    Friend WithEvents MenuDesc As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents ToolStripSeparator11 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ImagePropertiesToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Label21 As System.Windows.Forms.Label
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents prjTreeStatus As System.Windows.Forms.StatusStrip
    Friend WithEvents ToolStripStatusLabel2 As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents ToolStripProgressBar1 As System.Windows.Forms.ToolStripProgressBar
    Friend WithEvents ToolStripButton2 As System.Windows.Forms.ToolStripButton
    Friend WithEvents Button14 As System.Windows.Forms.Button
    Friend WithEvents Button15 As System.Windows.Forms.Button
    Friend WithEvents ImageConversionToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents WIMESDToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator12 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents OpenFileDialog1 As System.Windows.Forms.OpenFileDialog
    Friend WithEvents ImageNotMountedPanel As System.Windows.Forms.Panel
    Friend WithEvents LinkLabel2 As System.Windows.Forms.LinkLabel
    Friend WithEvents Label23 As System.Windows.Forms.Label
    Friend WithEvents ImagePanel As System.Windows.Forms.Panel
    Friend WithEvents PkgInfoCMS As System.Windows.Forms.ContextMenuStrip
    Friend WithEvents PkgBasicInfo As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PkgDetailedInfo As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PictureBox5 As System.Windows.Forms.PictureBox
    Friend WithEvents RemountImageWithWritePermissionsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator13 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ToolStripSeparator14 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ToolStripButton3 As System.Windows.Forms.ToolStripButton
    Friend WithEvents CommandShellToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator16 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents Button16 As System.Windows.Forms.Button
    Friend WithEvents UnattendedAnswerFileManagerToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator9 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents MicrosoftEdgeToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AddEdge As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AddEdgeBrowser As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AddEdgeWebView As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ReportManagerToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents prjTreeView As System.Windows.Forms.TreeView
    Friend WithEvents ToolStrip2 As System.Windows.Forms.ToolStrip
    Friend WithEvents RefreshViewTSB As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripSeparator17 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ExpandCollapseTSB As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripSeparator15 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ToolStripButton4 As System.Windows.Forms.ToolStripButton
    Friend WithEvents MergeSWM As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator18 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents VersionTSMI As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents InvalidSettingsTSMI As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ISFix As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator19 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ISHelp As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents BranchTSMI As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ImgBW As System.ComponentModel.BackgroundWorker
    Friend WithEvents ImgProcesses As Process
    Friend WithEvents BackgroundProcessesButton As System.Windows.Forms.ToolStripSplitButton
    Friend WithEvents OldActionPanel As System.Windows.Forms.Panel
    Friend WithEvents LinkLabel3 As System.Windows.Forms.LinkLabel
    Friend WithEvents LocalMountDirFBD As System.Windows.Forms.FolderBrowserDialog
    Friend WithEvents MountedImageDetectorBW As System.ComponentModel.BackgroundWorker
    Friend WithEvents MountedImageManagerTSMI As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ImgUMountPopupCMS As System.Windows.Forms.ContextMenuStrip
    Friend WithEvents CommitAndUnmountTSMI As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DiscardAndUnmountTSMI As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator20 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents UnmountSettingsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents StartPanel As System.Windows.Forms.Panel
    Friend WithEvents StartPanelPContainer As System.Windows.Forms.Panel
    Friend WithEvents GetStartedPanel As System.Windows.Forms.Panel
    Friend WithEvents GetStartedContainer As System.Windows.Forms.Panel
    Friend WithEvents Panel6 As System.Windows.Forms.Panel
    Friend WithEvents LinkLabel11 As System.Windows.Forms.LinkLabel
    Friend WithEvents LinkLabel8 As System.Windows.Forms.LinkLabel
    Friend WithEvents LinkLabel10 As System.Windows.Forms.LinkLabel
    Friend WithEvents LinkLabel7 As System.Windows.Forms.LinkLabel
    Friend WithEvents LinkLabel9 As System.Windows.Forms.LinkLabel
    Friend WithEvents LinkLabel6 As System.Windows.Forms.LinkLabel
    Friend WithEvents Label38 As System.Windows.Forms.Label
    Friend WithEvents Label37 As System.Windows.Forms.Label
    Friend WithEvents Label36 As System.Windows.Forms.Label
    Friend WithEvents PictureBox8 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox7 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox6 As System.Windows.Forms.PictureBox
    Friend WithEvents TutorialVideoPanel As System.Windows.Forms.Panel
    Friend WithEvents LatestNewsPanel As System.Windows.Forms.Panel
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents TableLayoutPanel1 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents TableLayoutPanel2 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents Panel8 As System.Windows.Forms.Panel
    Friend WithEvents Panel9 As System.Windows.Forms.Panel
    Friend WithEvents ReportFeedbackToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator21 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ActionEditorToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator22 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents OnlineInstMgmt As System.Windows.Forms.LinkLabel
    Friend WithEvents AppxPackagePopupCMS As System.Windows.Forms.ContextMenuStrip
    Friend WithEvents ViewPackageDirectoryToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ResViewTSMI As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents UpdatePanel As System.Windows.Forms.Panel
    Friend WithEvents UpdateLink As System.Windows.Forms.LinkLabel
    Friend WithEvents TreeViewCMS As System.Windows.Forms.ContextMenuStrip
    Friend WithEvents ExpandToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AccessDirectoryToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator23 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents UnloadProjectToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator24 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents CopyDeploymentToolsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents OfAllArchitecturesToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents OfSelectedArchitectureToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator25 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ForX86ArchitectureToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ForAmd64ArchitectureToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ForARMArchitectureToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ForARM64ArchitectureToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator27 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ImageOperationsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents MountImageToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents UnmountImageToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator29 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents RemoveVolumeImagesToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SwitchImageIndexesToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator30 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents UnattendedAnswerFilesToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ManageToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CreationWizardToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator31 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ScratchDirectorySettingsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator32 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ManageReportsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator33 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents AddToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents NewFileToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ExistingFileToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ADKCopierBW As System.ComponentModel.BackgroundWorker
    Friend WithEvents ToolStripSeparator26 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ManageOnlineInstallationToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents UpdCheckerBW As System.ComponentModel.BackgroundWorker
    Friend WithEvents ToolStripSeparator28 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents WimScriptEditorCommand As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AppxResCMS As System.Windows.Forms.ContextMenuStrip
    Friend WithEvents SaveResourceToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CopyToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AppxResSFD As System.Windows.Forms.SaveFileDialog
    Friend WithEvents Notifications As System.Windows.Forms.NotifyIcon
    Friend WithEvents AppxRelatedLinksCMS As System.Windows.Forms.ContextMenuStrip
    Friend WithEvents MicrosoftAppsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents MicrosoftStoreGenerationProjectToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator34 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents SaveImageInformationToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ImgInfoSFD As System.Windows.Forms.SaveFileDialog
    Friend WithEvents OfflineInstMgmt As System.Windows.Forms.LinkLabel
    Friend WithEvents ManageOfflineInstallationToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator35 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ContributeToTheHelpSystemToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ProjectView As System.Windows.Forms.Panel
    Friend WithEvents ProjectViewHeader As System.Windows.Forms.Panel
    Friend WithEvents GreetingLabel As System.Windows.Forms.Label
    Friend WithEvents TimeLabel As System.Windows.Forms.Label
    Friend WithEvents ProjectSidePanel As System.Windows.Forms.Panel
    Friend WithEvents Panel10 As System.Windows.Forms.Panel
    Friend WithEvents TableLayoutPanel4 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents Panel11 As System.Windows.Forms.Panel
    Friend WithEvents Button20 As System.Windows.Forms.Button
    Friend WithEvents LinkLabel12 As System.Windows.Forms.LinkLabel
    Friend WithEvents LinkLabel13 As System.Windows.Forms.LinkLabel
    Friend WithEvents Button19 As System.Windows.Forms.Button
    Friend WithEvents Timer1 As System.Windows.Forms.Timer
    Friend WithEvents ProjectSidePanelContainer As System.Windows.Forms.Panel
    Friend WithEvents SidePanel_ProjectView As System.Windows.Forms.Panel
    Friend WithEvents TableLayoutPanel6 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents LinkLabel14 As System.Windows.Forms.LinkLabel
    Friend WithEvents Label50 As System.Windows.Forms.Label
    Friend WithEvents Label51 As System.Windows.Forms.Label
    Friend WithEvents Label52 As System.Windows.Forms.Label
    Friend WithEvents Label53 As System.Windows.Forms.Label
    Friend WithEvents Panel13 As System.Windows.Forms.Panel
    Friend WithEvents Label54 As System.Windows.Forms.Label
    Friend WithEvents Label49 As System.Windows.Forms.Label
    Friend WithEvents SidePanel_ImageView As System.Windows.Forms.Panel
    Friend WithEvents ImageView_NoImage As System.Windows.Forms.Panel
    Friend WithEvents ImageView_BasicInfo As System.Windows.Forms.Panel
    Friend WithEvents TableLayoutPanel5 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents Label39 As System.Windows.Forms.Label
    Friend WithEvents Label40 As System.Windows.Forms.Label
    Friend WithEvents Label41 As System.Windows.Forms.Label
    Friend WithEvents Label42 As System.Windows.Forms.Label
    Friend WithEvents Label43 As System.Windows.Forms.Label
    Friend WithEvents Label44 As System.Windows.Forms.Label
    Friend WithEvents Label45 As System.Windows.Forms.Label
    Friend WithEvents Label46 As System.Windows.Forms.Label
    Friend WithEvents Label47 As System.Windows.Forms.Label
    Friend WithEvents Label48 As System.Windows.Forms.Label
    Friend WithEvents Button21 As System.Windows.Forms.Button
    Friend WithEvents Button22 As System.Windows.Forms.Button
    Friend WithEvents Button23 As System.Windows.Forms.Button
    Friend WithEvents FlowLayoutPanel1 As System.Windows.Forms.FlowLayoutPanel
    Friend WithEvents GroupBox4 As System.Windows.Forms.GroupBox
    Friend WithEvents Button24 As System.Windows.Forms.Button
    Friend WithEvents Button31 As System.Windows.Forms.Button
    Friend WithEvents Button30 As System.Windows.Forms.Button
    Friend WithEvents Button33 As System.Windows.Forms.Button
    Friend WithEvents Button32 As System.Windows.Forms.Button
    Friend WithEvents Button26 As System.Windows.Forms.Button
    Friend WithEvents Button25 As System.Windows.Forms.Button
    Friend WithEvents Button29 As System.Windows.Forms.Button
    Friend WithEvents Button28 As System.Windows.Forms.Button
    Friend WithEvents Button27 As System.Windows.Forms.Button
    Friend WithEvents GroupBox5 As System.Windows.Forms.GroupBox
    Friend WithEvents Button35 As System.Windows.Forms.Button
    Friend WithEvents Button34 As System.Windows.Forms.Button
    Friend WithEvents Button36 As System.Windows.Forms.Button
    Friend WithEvents GroupBox6 As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox7 As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox8 As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox9 As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox10 As System.Windows.Forms.GroupBox
    Friend WithEvents Button38 As System.Windows.Forms.Button
    Friend WithEvents Button37 As System.Windows.Forms.Button
    Friend WithEvents Button42 As System.Windows.Forms.Button
    Friend WithEvents Button39 As System.Windows.Forms.Button
    Friend WithEvents Button41 As System.Windows.Forms.Button
    Friend WithEvents Button40 As System.Windows.Forms.Button
    Friend WithEvents Button46 As System.Windows.Forms.Button
    Friend WithEvents Button44 As System.Windows.Forms.Button
    Friend WithEvents Button45 As System.Windows.Forms.Button
    Friend WithEvents Button43 As System.Windows.Forms.Button
    Friend WithEvents Button50 As System.Windows.Forms.Button
    Friend WithEvents Button48 As System.Windows.Forms.Button
    Friend WithEvents Button49 As System.Windows.Forms.Button
    Friend WithEvents Button47 As System.Windows.Forms.Button
    Friend WithEvents Button54 As System.Windows.Forms.Button
    Friend WithEvents Button53 As System.Windows.Forms.Button
    Friend WithEvents Button51 As System.Windows.Forms.Button
    Friend WithEvents Button52 As System.Windows.Forms.Button
    Friend WithEvents Button58 As System.Windows.Forms.Button
    Friend WithEvents Button57 As System.Windows.Forms.Button
    Friend WithEvents Button56 As System.Windows.Forms.Button
    Friend WithEvents Button55 As System.Windows.Forms.Button
    Friend WithEvents SpaceLabel As System.Windows.Forms.Label
    Friend WithEvents PrjTasks As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents LinkLabel17 As System.Windows.Forms.LinkLabel
    Friend WithEvents PictureBox11 As System.Windows.Forms.PictureBox
    Friend WithEvents LinkLabel16 As System.Windows.Forms.LinkLabel
    Friend WithEvents PictureBox10 As System.Windows.Forms.PictureBox
    Friend WithEvents LinkLabel15 As System.Windows.Forms.LinkLabel
    Friend WithEvents PictureBox9 As System.Windows.Forms.PictureBox
    Friend WithEvents Label55 As System.Windows.Forms.Label
    Friend WithEvents Label59 As System.Windows.Forms.Label
    Friend WithEvents Label58 As System.Windows.Forms.Label
    Friend WithEvents Label57 As System.Windows.Forms.Label
    Friend WithEvents TableLayoutPanel7 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents LinkLabel18 As System.Windows.Forms.LinkLabel
    Friend WithEvents PictureBox12 As System.Windows.Forms.PictureBox
    Friend WithEvents LinkLabel21 As System.Windows.Forms.LinkLabel
    Friend WithEvents PictureBox15 As System.Windows.Forms.PictureBox
    Friend WithEvents Label56 As System.Windows.Forms.Label
    Friend WithEvents ImgTasks As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents LinkLabel19 As System.Windows.Forms.LinkLabel
    Friend WithEvents PictureBox13 As System.Windows.Forms.PictureBox
    Friend WithEvents LinkLabel20 As System.Windows.Forms.LinkLabel
    Friend WithEvents PictureBox14 As System.Windows.Forms.PictureBox
    Friend WithEvents FlowLayoutPanel2 As System.Windows.Forms.FlowLayoutPanel
    Friend WithEvents LinkLabel22 As System.Windows.Forms.LinkLabel
    Friend WithEvents LinkLabel23 As System.Windows.Forms.LinkLabel
    Friend WithEvents LinkLabel24 As System.Windows.Forms.LinkLabel
    Friend WithEvents FeedContainer As System.Windows.Forms.Panel
    Friend WithEvents FeedsPanel As System.Windows.Forms.Panel
    Friend WithEvents ListView1 As System.Windows.Forms.ListView
    Friend WithEvents ColumnHeader1 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader2 As System.Windows.Forms.ColumnHeader
    Friend WithEvents FeedErrorPanel As System.Windows.Forms.Panel
    Friend WithEvents Button59 As System.Windows.Forms.Button
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
    Friend WithEvents Label34 As System.Windows.Forms.Label
    Friend WithEvents Label22 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents FeedWorker As System.ComponentModel.BackgroundWorker
    Friend WithEvents Label35 As System.Windows.Forms.Label
    Friend WithEvents Timer2 As System.Windows.Forms.Timer
    Friend WithEvents LinkLabel5 As System.Windows.Forms.LinkLabel
    Friend WithEvents LinkLabel4 As System.Windows.Forms.LinkLabel
    Friend WithEvents Panel4 As System.Windows.Forms.Panel
    Friend WithEvents LinkLabel25 As System.Windows.Forms.LinkLabel
    Friend WithEvents WatcherBW As System.ComponentModel.BackgroundWorker
    Friend WithEvents WatcherTimer As System.Windows.Forms.Timer
    Friend WithEvents ImportDriver As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator36 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents AppxDownloadHelpToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents RecentsLV As System.Windows.Forms.ListView
    Friend WithEvents ColumnHeader3 As System.Windows.Forms.ColumnHeader
    Friend WithEvents RecentRemoveLink As System.Windows.Forms.LinkLabel
    Friend WithEvents VideoContainer As System.Windows.Forms.Panel
    Friend WithEvents VideosPanel As System.Windows.Forms.Panel
    Friend WithEvents ListView2 As System.Windows.Forms.ListView
    Friend WithEvents ColumnHeader4 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader5 As System.Windows.Forms.ColumnHeader
    Friend WithEvents VideoErrorPanel As System.Windows.Forms.Panel
    Friend WithEvents Button17 As System.Windows.Forms.Button
    Friend WithEvents TextBox2 As System.Windows.Forms.TextBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents ToolStripSeparator37 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents RecentProjectsListMenu As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents RecentProject1ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents RecentProject2ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents RecentProject3ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents RecentProject4ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents RecentProject5ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents RecentProject6ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents RecentProject7ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents RecentProject8ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents RecentProject9ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents RecentProject10ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator38 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ImgSpecialToolsCMS As System.Windows.Forms.ContextMenuStrip
    Friend WithEvents GetImageFileInformationToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator39 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents SaveCompleteImageInformationToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator40 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents CreateDiscImageWithThisFileToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CreateDiscImageToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CreateTestingEnvironmentToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents WIEDownloaderBW As System.ComponentModel.BackgroundWorker
    Friend WithEvents UnattendedAnswerFileCreatorToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator41 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents VideoGetterBW As System.ComponentModel.BackgroundWorker
    Friend WithEvents MountedImageDetectorBWRestarterTimer As System.Windows.Forms.Timer
End Class
